--
-- PostgreSQL database dump
--

\restrict fKRdkBzwZeVziStD3cfIVdMUqzxBgkmIVI0Fqz1bVpApSzm26tHyr0tmozHpU50

-- Dumped from database version 18.1
-- Dumped by pg_dump version 18.1

-- Started on 2025-12-02 10:54:58

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 219 (class 1259 OID 17263)
-- Name: dashboard_performance_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dashboard_performance_log (
    log_id integer NOT NULL,
    session_id character varying(100),
    "timestamp" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    load_time_seconds numeric(5,2),
    query_time_seconds numeric(5,2),
    render_time_seconds numeric(5,2),
    page_views integer,
    interactions_count integer,
    dwell_time_seconds integer,
    error_occurred boolean DEFAULT false,
    error_message text,
    user_agent text,
    screen_width integer,
    screen_height integer,
    filters_applied jsonb,
    status character varying(20) DEFAULT 'success'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 220 (class 1259 OID 17273)
-- Name: dashboard_performance_log_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.dashboard_performance_log_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 5151 (class 0 OID 0)
-- Dependencies: 220
-- Name: dashboard_performance_log_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.dashboard_performance_log_log_id_seq OWNED BY public.dashboard_performance_log.log_id;


--
-- TOC entry 221 (class 1259 OID 17274)
-- Name: dim_objek_wisata; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dim_objek_wisata (
    objek_wisata_id integer NOT NULL,
    nama_objek character varying(200) NOT NULL,
    alamat text,
    longitude numeric(10,7),
    latitude numeric(10,7),
    wilayah character varying(100),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 222 (class 1259 OID 17283)
-- Name: dim_objek_wisata_objek_wisata_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.dim_objek_wisata_objek_wisata_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 5152 (class 0 OID 0)
-- Dependencies: 222
-- Name: dim_objek_wisata_objek_wisata_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.dim_objek_wisata_objek_wisata_id_seq OWNED BY public.dim_objek_wisata.objek_wisata_id;


--
-- TOC entry 223 (class 1259 OID 17284)
-- Name: dim_price; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dim_price (
    price_id integer NOT NULL,
    objek_wisata_id integer NOT NULL,
    harga_tiket_dewasa integer DEFAULT 0,
    harga_tiket_anak integer DEFAULT 0,
    mata_uang character varying(10) DEFAULT 'IDR'::character varying,
    sumber_platform character varying(100),
    tanggal_update date,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 5153 (class 0 OID 0)
-- Dependencies: 223
-- Name: TABLE dim_price; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.dim_price IS 'Dimension table untuk harga tiket objek wisata';


--
-- TOC entry 5154 (class 0 OID 0)
-- Dependencies: 223
-- Name: COLUMN dim_price.harga_tiket_dewasa; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.dim_price.harga_tiket_dewasa IS 'Harga tiket untuk dewasa (sama untuk WNI & WNA)';


--
-- TOC entry 5155 (class 0 OID 0)
-- Dependencies: 223
-- Name: COLUMN dim_price.harga_tiket_anak; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.dim_price.harga_tiket_anak IS 'Harga tiket untuk anak (sama untuk WNI & WNA)';


--
-- TOC entry 5156 (class 0 OID 0)
-- Dependencies: 223
-- Name: COLUMN dim_price.sumber_platform; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.dim_price.sumber_platform IS 'Sumber data harga (Website Resmi, Survey Manual, dll)';


--
-- TOC entry 224 (class 1259 OID 17293)
-- Name: dim_price_price_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.dim_price_price_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 5157 (class 0 OID 0)
-- Dependencies: 224
-- Name: dim_price_price_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.dim_price_price_id_seq OWNED BY public.dim_price.price_id;


--
-- TOC entry 225 (class 1259 OID 17294)
-- Name: dim_time; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dim_time (
    time_id integer NOT NULL,
    periode_data character varying(6) NOT NULL,
    bulan integer NOT NULL,
    tahun integer NOT NULL,
    kuartal integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 226 (class 1259 OID 17302)
-- Name: dim_time_time_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.dim_time_time_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 5158 (class 0 OID 0)
-- Dependencies: 226
-- Name: dim_time_time_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.dim_time_time_id_seq OWNED BY public.dim_time.time_id;


--
-- TOC entry 227 (class 1259 OID 17303)
-- Name: dim_wisatawan; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dim_wisatawan (
    wisatawan_id integer NOT NULL,
    jenis_wisatawan character varying(50),
    kode_jenis character varying(5),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 228 (class 1259 OID 17308)
-- Name: dim_wisatawan_wisatawan_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.dim_wisatawan_wisatawan_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 5159 (class 0 OID 0)
-- Dependencies: 228
-- Name: dim_wisatawan_wisatawan_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.dim_wisatawan_wisatawan_id_seq OWNED BY public.dim_wisatawan.wisatawan_id;


--
-- TOC entry 229 (class 1259 OID 17309)
-- Name: fact_kunjungan; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fact_kunjungan (
    kunjungan_id integer NOT NULL,
    time_id integer NOT NULL,
    objek_wisata_id integer NOT NULL,
    wisatawan_id integer NOT NULL,
    price_id integer,
    jumlah_kunjungan integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 230 (class 1259 OID 17319)
-- Name: fact_kunjungan_kunjungan_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fact_kunjungan_kunjungan_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 5160 (class 0 OID 0)
-- Dependencies: 230
-- Name: fact_kunjungan_kunjungan_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fact_kunjungan_kunjungan_id_seq OWNED BY public.fact_kunjungan.kunjungan_id;


--
-- TOC entry 231 (class 1259 OID 17320)
-- Name: staging_harga_tiket_raw; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.staging_harga_tiket_raw (
    id integer NOT NULL,
    nama_objek_wisata character varying(200),
    harga_dewasa integer,
    harga_anak integer,
    gratis character varying(10),
    tanggal_update date,
    raw_data jsonb,
    is_processed boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 232 (class 1259 OID 17328)
-- Name: staging_harga_tiket_raw_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.staging_harga_tiket_raw_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 5161 (class 0 OID 0)
-- Dependencies: 232
-- Name: staging_harga_tiket_raw_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.staging_harga_tiket_raw_id_seq OWNED BY public.staging_harga_tiket_raw.id;


--
-- TOC entry 233 (class 1259 OID 17329)
-- Name: staging_kunjungan_raw; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.staging_kunjungan_raw (
    id integer NOT NULL,
    periode_data integer,
    nama_objek_wisata character varying(200),
    alamat text,
    longitude numeric(10,7),
    latitude numeric(10,7),
    jenis_wisatawan character varying(50),
    jumlah_pengunjung integer,
    raw_data jsonb,
    is_processed boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 234 (class 1259 OID 17337)
-- Name: staging_kunjungan_raw_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.staging_kunjungan_raw_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 5162 (class 0 OID 0)
-- Dependencies: 234
-- Name: staging_kunjungan_raw_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.staging_kunjungan_raw_id_seq OWNED BY public.staging_kunjungan_raw.id;


--
-- TOC entry 235 (class 1259 OID 17338)
-- Name: user_journey_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_journey_log (
    journey_id integer NOT NULL,
    session_id character varying(100),
    stage character varying(50),
    "timestamp" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    duration_seconds integer,
    completed boolean DEFAULT true
);


--
-- TOC entry 236 (class 1259 OID 17344)
-- Name: user_journey_log_journey_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_journey_log_journey_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 5163 (class 0 OID 0)
-- Dependencies: 236
-- Name: user_journey_log_journey_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_journey_log_journey_id_seq OWNED BY public.user_journey_log.journey_id;


--
-- TOC entry 237 (class 1259 OID 17345)
-- Name: v_dashboard_performance_daily; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_dashboard_performance_daily AS
 SELECT date("timestamp") AS date,
    count(*) AS total_sessions,
    avg(load_time_seconds) AS avg_load_time,
    max(load_time_seconds) AS max_load_time,
    avg(query_time_seconds) AS avg_query_time,
    sum(
        CASE
            WHEN error_occurred THEN 1
            ELSE 0
        END) AS error_count,
    round((((sum(
        CASE
            WHEN error_occurred THEN 1
            ELSE 0
        END))::numeric / (count(*))::numeric) * (100)::numeric), 2) AS error_rate_pct,
    avg(dwell_time_seconds) AS avg_dwell_time,
    avg(interactions_count) AS avg_interactions
   FROM public.dashboard_performance_log
  WHERE ("timestamp" >= (CURRENT_DATE - '30 days'::interval))
  GROUP BY (date("timestamp"))
  ORDER BY (date("timestamp")) DESC;


--
-- TOC entry 238 (class 1259 OID 17350)
-- Name: v_funnel_analysis; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_funnel_analysis AS
 WITH stage_counts AS (
         SELECT user_journey_log.stage,
            count(DISTINCT user_journey_log.session_id) AS users,
                CASE user_journey_log.stage
                    WHEN 'landing'::text THEN 1
                    WHEN 'view_kpis'::text THEN 2
                    WHEN 'apply_filters'::text THEN 3
                    WHEN 'analyze_charts'::text THEN 4
                    WHEN 'download_data'::text THEN 5
                    ELSE NULL::integer
                END AS stage_order
           FROM public.user_journey_log
          WHERE (user_journey_log."timestamp" >= (CURRENT_DATE - '30 days'::interval))
          GROUP BY user_journey_log.stage
        ), total_users AS (
         SELECT stage_counts.users AS total
           FROM stage_counts
          WHERE ((stage_counts.stage)::text = 'landing'::text)
        )
 SELECT sc.stage,
    sc.users,
    round((((sc.users)::numeric / (tu.total)::numeric) * (100)::numeric), 2) AS conversion_rate
   FROM (stage_counts sc
     CROSS JOIN total_users tu)
  ORDER BY sc.stage_order;


--
-- TOC entry 239 (class 1259 OID 17355)
-- Name: v_kunjungan_summary; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_kunjungan_summary AS
 SELECT dt.tahun,
    dt.bulan,
    dt.periode_data,
    obj.nama_objek,
    obj.wilayah,
    dw.jenis_wisatawan,
    sum(f.jumlah_kunjungan) AS total_kunjungan
   FROM (((public.fact_kunjungan f
     JOIN public.dim_time dt ON ((f.time_id = dt.time_id)))
     JOIN public.dim_objek_wisata obj ON ((f.objek_wisata_id = obj.objek_wisata_id)))
     JOIN public.dim_wisatawan dw ON ((f.wisatawan_id = dw.wisatawan_id)))
  GROUP BY dt.tahun, dt.bulan, dt.periode_data, obj.nama_objek, obj.wilayah, dw.jenis_wisatawan;


--
-- TOC entry 4908 (class 2604 OID 17360)
-- Name: dashboard_performance_log log_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard_performance_log ALTER COLUMN log_id SET DEFAULT nextval('public.dashboard_performance_log_log_id_seq'::regclass);


--
-- TOC entry 4913 (class 2604 OID 17361)
-- Name: dim_objek_wisata objek_wisata_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dim_objek_wisata ALTER COLUMN objek_wisata_id SET DEFAULT nextval('public.dim_objek_wisata_objek_wisata_id_seq'::regclass);


--
-- TOC entry 4916 (class 2604 OID 17362)
-- Name: dim_price price_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dim_price ALTER COLUMN price_id SET DEFAULT nextval('public.dim_price_price_id_seq'::regclass);


--
-- TOC entry 4921 (class 2604 OID 17363)
-- Name: dim_time time_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dim_time ALTER COLUMN time_id SET DEFAULT nextval('public.dim_time_time_id_seq'::regclass);


--
-- TOC entry 4923 (class 2604 OID 17364)
-- Name: dim_wisatawan wisatawan_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dim_wisatawan ALTER COLUMN wisatawan_id SET DEFAULT nextval('public.dim_wisatawan_wisatawan_id_seq'::regclass);


--
-- TOC entry 4925 (class 2604 OID 17365)
-- Name: fact_kunjungan kunjungan_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fact_kunjungan ALTER COLUMN kunjungan_id SET DEFAULT nextval('public.fact_kunjungan_kunjungan_id_seq'::regclass);


--
-- TOC entry 4928 (class 2604 OID 17366)
-- Name: staging_harga_tiket_raw id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staging_harga_tiket_raw ALTER COLUMN id SET DEFAULT nextval('public.staging_harga_tiket_raw_id_seq'::regclass);


--
-- TOC entry 4931 (class 2604 OID 17367)
-- Name: staging_kunjungan_raw id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staging_kunjungan_raw ALTER COLUMN id SET DEFAULT nextval('public.staging_kunjungan_raw_id_seq'::regclass);


--
-- TOC entry 4934 (class 2604 OID 17368)
-- Name: user_journey_log journey_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_journey_log ALTER COLUMN journey_id SET DEFAULT nextval('public.user_journey_log_journey_id_seq'::regclass);


--
-- TOC entry 5128 (class 0 OID 17263)
-- Dependencies: 219
-- Data for Name: dashboard_performance_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dashboard_performance_log (log_id, session_id, "timestamp", load_time_seconds, query_time_seconds, render_time_seconds, page_views, interactions_count, dwell_time_seconds, error_occurred, error_message, user_agent, screen_width, screen_height, filters_applied, status, created_at) FROM stdin;
1	b29ef3ac-1f25-4cce-8dba-e432f4c6aa6a	2025-11-25 21:40:45.326531	0.44	0.43	0.52	1	1	1	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 21:40:45.326531
2	ac70d3e3-c9ee-4e00-9a29-a95bb9a99b8f	2025-11-25 21:40:49.545864	0.00	0.43	0.04	1	1	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 21:40:49.545864
3	ac70d3e3-c9ee-4e00-9a29-a95bb9a99b8f	2025-11-25 21:41:54.589053	0.00	0.43	0.03	2	3	65	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 21:41:54.589053
4	ac70d3e3-c9ee-4e00-9a29-a95bb9a99b8f	2025-11-25 21:41:58.009368	0.00	0.43	0.04	3	5	68	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 21:41:58.009368
5	ac70d3e3-c9ee-4e00-9a29-a95bb9a99b8f	2025-11-25 21:42:05.661423	0.00	0.43	0.05	4	7	76	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 21:42:05.661423
6	ac70d3e3-c9ee-4e00-9a29-a95bb9a99b8f	2025-11-25 21:42:09.333283	0.00	0.43	0.04	5	9	79	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara"]}	success	2025-11-25 21:42:09.333283
7	7aa6bf6f-e215-44d0-ac08-d440fd32cbb1	2025-11-25 21:49:02.884114	0.00	0.43	0.05	1	1	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 21:49:02.884114
8	a27b428e-04c9-4171-8279-3a9d3ece87ac	2025-11-25 21:50:48.093939	0.03	0.02	0.11	1	1	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 21:50:48.093939
9	a27b428e-04c9-4171-8279-3a9d3ece87ac	2025-11-25 21:52:06.151301	0.00	0.02	0.04	2	2	78	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 21:52:06.151301
10	a27b428e-04c9-4171-8279-3a9d3ece87ac	2025-11-25 21:52:09.177859	0.00	0.02	0.03	3	3	81	f	\N	\N	\N	\N	{"year": "Semua", "months": [3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 21:52:09.177859
11	a27b428e-04c9-4171-8279-3a9d3ece87ac	2025-11-25 21:52:09.907817	0.00	0.02	0.05	4	4	81	f	\N	\N	\N	\N	{"year": "Semua", "months": [4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 21:52:09.907817
12	a27b428e-04c9-4171-8279-3a9d3ece87ac	2025-11-25 21:52:10.534256	0.00	0.02	0.06	5	5	82	f	\N	\N	\N	\N	{"year": "Semua", "months": [5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 21:52:10.534256
13	a27b428e-04c9-4171-8279-3a9d3ece87ac	2025-11-25 21:52:12.010729	0.00	0.02	0.03	6	6	84	f	\N	\N	\N	\N	{"year": "Semua", "months": [6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 21:52:12.010729
14	a27b428e-04c9-4171-8279-3a9d3ece87ac	2025-11-25 21:52:18.817073	0.00	0.02	0.03	7	7	90	f	\N	\N	\N	\N	{"year": "Semua", "months": [], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 21:52:18.817073
15	a27b428e-04c9-4171-8279-3a9d3ece87ac	2025-11-25 21:52:20.623024	0.00	0.02	0.04	8	8	92	f	\N	\N	\N	\N	{"year": "Semua", "months": [2], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 21:52:20.623024
16	a27b428e-04c9-4171-8279-3a9d3ece87ac	2025-11-25 21:52:23.074591	0.00	0.02	0.04	9	9	95	f	\N	\N	\N	\N	{"year": "Semua", "months": [2, 7], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 21:52:23.074591
17	a27b428e-04c9-4171-8279-3a9d3ece87ac	2025-11-25 21:52:23.985774	0.00	0.02	0.03	10	10	96	f	\N	\N	\N	\N	{"year": "Semua", "months": [2, 7, 3], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 21:52:23.985774
18	a27b428e-04c9-4171-8279-3a9d3ece87ac	2025-11-25 21:52:27.360137	0.00	0.02	0.04	11	11	99	f	\N	\N	\N	\N	{"year": "Semua", "months": [2, 7, 3], "wilayah": ["Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 21:52:27.360137
19	a27b428e-04c9-4171-8279-3a9d3ece87ac	2025-11-25 21:52:31.564135	0.00	0.02	0.04	12	12	103	f	\N	\N	\N	\N	{"year": "Semua", "months": [2, 7, 3], "wilayah": ["Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 21:52:31.564135
20	a27b428e-04c9-4171-8279-3a9d3ece87ac	2025-11-25 21:52:32.865092	0.00	0.02	0.04	13	13	104	f	\N	\N	\N	\N	{"year": "Semua", "months": [2, 7, 3], "wilayah": ["Jakarta Selatan", "Jakarta Timur", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 21:52:32.865092
21	a27b428e-04c9-4171-8279-3a9d3ece87ac	2025-11-25 21:57:45.145972	0.00	0.02	0.04	14	14	417	f	\N	\N	\N	\N	{"year": "2025", "months": [2, 7, 3], "wilayah": ["Jakarta Selatan", "Jakarta Timur", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 21:57:45.145972
22	a27b428e-04c9-4171-8279-3a9d3ece87ac	2025-11-25 21:57:54.328533	0.00	0.02	0.03	15	15	426	f	\N	\N	\N	\N	{"year": "2025", "months": [2, 7, 3], "wilayah": ["Jakarta Selatan", "Jakarta Timur", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 21:57:54.328533
23	a27b428e-04c9-4171-8279-3a9d3ece87ac	2025-11-25 21:58:12.630938	0.00	0.02	0.04	16	16	444	f	\N	\N	\N	\N	{"year": "2025", "months": [2, 7, 3], "wilayah": ["Jakarta Selatan", "Jakarta Timur", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 21:58:12.630938
24	07bd79b4-21e7-4040-a316-44690e8c95dc	2025-11-25 21:58:19.241475	0.00	0.02	0.05	1	1	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 21:58:19.241475
25	cf22800d-5ee4-48a5-9aca-02cf99cd4e0b	2025-11-25 21:58:24.412459	0.00	0.02	0.06	1	1	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 21:58:24.412459
26	b35a4ae0-9c69-4376-aeb1-a08a82c50a0b	2025-11-25 21:59:46.858373	0.00	0.02	0.05	1	1	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 21:59:46.858373
27	07bd6758-da30-49a4-a46c-ae0d105eff99	2025-11-25 21:59:53.304749	0.00	0.02	0.05	1	1	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 21:59:53.304749
28	54f80cfe-8a42-4b42-9f80-2628b0e10822	2025-11-25 22:00:15.350694	0.00	0.02	0.05	1	1	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:00:15.350694
29	fa7f1b55-5178-4ef1-8cee-60fb89041b09	2025-11-25 22:01:08.685258	0.02	0.01	0.06	1	1	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:01:08.685258
30	fa7f1b55-5178-4ef1-8cee-60fb89041b09	2025-11-25 22:01:35.891628	0.00	0.01	0.04	2	2	27	f	\N	\N	\N	\N	{"year": "Semua", "months": [], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:01:35.891628
31	fa7f1b55-5178-4ef1-8cee-60fb89041b09	2025-11-25 22:01:41.519383	0.00	0.01	0.03	3	3	32	f	\N	\N	\N	\N	{"year": "Semua", "months": [2], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:01:41.519383
32	fa7f1b55-5178-4ef1-8cee-60fb89041b09	2025-11-25 22:01:44.164546	0.00	0.01	0.05	4	4	35	f	\N	\N	\N	\N	{"year": "Semua", "months": [2, 4], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:01:44.164546
33	fa7f1b55-5178-4ef1-8cee-60fb89041b09	2025-11-25 22:01:44.991623	0.00	0.01	0.05	5	5	36	f	\N	\N	\N	\N	{"year": "Semua", "months": [2, 4, 6], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:01:44.991623
34	fa7f1b55-5178-4ef1-8cee-60fb89041b09	2025-11-25 22:01:45.956066	0.00	0.01	0.03	6	6	37	f	\N	\N	\N	\N	{"year": "Semua", "months": [2, 4, 6, 7], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:01:45.956066
35	fa7f1b55-5178-4ef1-8cee-60fb89041b09	2025-11-25 22:01:46.847816	0.00	0.01	0.07	7	7	38	f	\N	\N	\N	\N	{"year": "Semua", "months": [2, 4, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:01:46.847816
36	fa7f1b55-5178-4ef1-8cee-60fb89041b09	2025-11-25 22:01:47.266836	0.00	0.01	0.06	8	8	38	f	\N	\N	\N	\N	{"year": "Semua", "months": [2, 4, 6, 7, 8, 3], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:01:47.266836
37	fa7f1b55-5178-4ef1-8cee-60fb89041b09	2025-11-25 22:01:47.832529	0.00	0.01	0.05	9	9	39	f	\N	\N	\N	\N	{"year": "Semua", "months": [2, 4, 6, 7, 8, 3, 5], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:01:47.832529
38	fa7f1b55-5178-4ef1-8cee-60fb89041b09	2025-11-25 22:01:48.5853	0.00	0.01	0.04	10	10	39	f	\N	\N	\N	\N	{"year": "Semua", "months": [2, 4, 6, 7, 8, 3, 5, 1], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:01:48.5853
39	6d99802a-25e2-4136-b983-c194ccce5178	2025-11-25 22:01:50.676053	0.00	0.01	0.05	1	1	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:01:50.676053
40	6d99802a-25e2-4136-b983-c194ccce5178	2025-11-25 22:03:03.642239	0.00	0.01	0.04	2	2	73	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": [], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:03:03.642239
41	6d99802a-25e2-4136-b983-c194ccce5178	2025-11-25 22:03:06.603627	0.00	0.01	0.04	3	3	75	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Pusat"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:03:06.603627
42	6d99802a-25e2-4136-b983-c194ccce5178	2025-11-25 22:03:33.428032	0.00	0.01	0.04	4	4	102	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Pusat", "Jakarta Selatan"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:03:33.428032
43	6d99802a-25e2-4136-b983-c194ccce5178	2025-11-25 22:03:34.500792	0.00	0.01	0.05	5	5	103	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Pusat", "Jakarta Selatan", "Jakarta Barat"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:03:34.500792
44	6d99802a-25e2-4136-b983-c194ccce5178	2025-11-25 22:03:35.237657	0.00	0.01	0.04	6	6	104	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Pusat", "Jakarta Selatan", "Jakarta Barat", "Jakarta Timur"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:03:35.237657
45	b0db5e26-0d50-4eed-879a-5c714e744444	2025-11-25 22:03:53.026735	0.00	0.01	0.05	1	1	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:03:53.026735
46	05662ac3-569c-48b1-9b18-597b8ca64240	2025-11-25 22:06:08.026769	0.00	0.01	0.06	1	1	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:06:08.026769
47	bd642457-0e39-4907-a860-5ebf82bfa5c0	2025-11-25 22:06:51.570788	0.08	0.06	0.38	1	1	1	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:06:51.570788
48	459c6aa9-99da-4f87-a4a6-7983843fb6dc	2025-11-25 22:21:08.946275	0.05	0.04	0.32	1	1	1	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:21:08.946275
49	459c6aa9-99da-4f87-a4a6-7983843fb6dc	2025-11-25 22:21:21.528666	0.00	0.04	0.04	2	2	13	f	\N	\N	\N	\N	{"year": "Semua", "months": [2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:21:21.528666
50	459c6aa9-99da-4f87-a4a6-7983843fb6dc	2025-11-25 22:21:28.023237	0.00	0.04	0.04	3	3	20	f	\N	\N	\N	\N	{"year": "Semua", "months": [2, 3, 4, 5, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:21:28.023237
51	459c6aa9-99da-4f87-a4a6-7983843fb6dc	2025-11-25 22:21:35.347099	0.00	0.04	0.03	4	4	27	f	\N	\N	\N	\N	{"year": "2025", "months": [2, 3, 4, 5, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:21:35.347099
52	25bad5bf-5380-46fa-b3e0-6bc10192c3b1	2025-11-25 22:21:49.171046	0.00	0.04	0.04	1	1	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:21:49.171046
53	25bad5bf-5380-46fa-b3e0-6bc10192c3b1	2025-11-25 22:22:16.707802	0.00	0.04	0.04	2	2	27	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:22:16.707802
54	25bad5bf-5380-46fa-b3e0-6bc10192c3b1	2025-11-25 22:22:20.963011	0.00	0.04	0.04	3	4	31	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:22:20.963011
55	25bad5bf-5380-46fa-b3e0-6bc10192c3b1	2025-11-25 22:22:24.978966	0.00	0.04	0.05	4	5	35	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:22:24.978966
56	25bad5bf-5380-46fa-b3e0-6bc10192c3b1	2025-11-25 22:22:44.719899	0.00	0.04	0.06	5	6	55	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 7, 8], "wilayah": ["Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:22:44.719899
57	25bad5bf-5380-46fa-b3e0-6bc10192c3b1	2025-11-25 22:22:51.758974	0.00	0.04	0.04	6	7	62	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 7, 8], "wilayah": ["Jakarta Pusat", "Jakarta Timur", "Jakarta Utara"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:22:51.758974
58	25bad5bf-5380-46fa-b3e0-6bc10192c3b1	2025-11-25 22:22:57.056811	0.00	0.04	0.04	7	8	67	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 7, 8], "wilayah": ["Jakarta Pusat", "Jakarta Timur", "Jakarta Utara"], "wisatawan": ["Wisatawan Nusantara"]}	success	2025-11-25 22:22:57.056811
59	25bad5bf-5380-46fa-b3e0-6bc10192c3b1	2025-11-25 22:27:08.825901	0.00	0.04	0.06	8	9	319	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 7, 8], "wilayah": ["Jakarta Pusat", "Jakarta Timur", "Jakarta Utara"], "wisatawan": []}	success	2025-11-25 22:27:08.825901
60	25bad5bf-5380-46fa-b3e0-6bc10192c3b1	2025-11-25 22:27:54.099111	0.00	0.04	0.05	9	10	364	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 7, 8], "wilayah": ["Jakarta Timur", "Jakarta Utara"], "wisatawan": []}	success	2025-11-25 22:27:54.099111
61	3e5bfb74-65f4-446e-a954-ef47465b2d52	2025-11-25 22:28:13.369836	0.00	0.04	0.05	1	1	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:28:13.369836
62	7ec80fe8-941f-47d0-b4ae-d43e1b63f0d7	2025-11-25 22:29:42.188855	0.00	0.04	0.07	1	1	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:29:42.188855
63	7ec80fe8-941f-47d0-b4ae-d43e1b63f0d7	2025-11-25 22:29:55.785877	0.00	0.04	0.04	2	2	13	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:29:55.785877
64	45069881-b7f6-4344-ba36-65a9ddf48fe9	2025-11-25 22:30:00.352033	0.00	0.04	0.05	1	1	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:30:00.352033
65	1a516357-b9f4-4233-a767-d35d86e44aa9	2025-11-25 22:31:10.48464	0.03	0.02	0.10	1	1	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:31:10.48464
66	dfface28-549c-4a01-93dd-500fd0a077a9	2025-11-25 22:31:43.241456	0.00	0.02	0.04	1	1	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:31:43.241456
67	dfface28-549c-4a01-93dd-500fd0a077a9	2025-11-25 22:31:50.661472	0.00	0.02	0.05	2	2	7	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:31:50.661472
68	01941dee-8db4-4f28-902f-c92dc2efa457	2025-11-25 22:31:54.483368	0.00	0.02	0.05	1	1	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:31:54.483368
69	45069881-b7f6-4344-ba36-65a9ddf48fe9	2025-11-25 22:32:36.624846	0.00	0.02	0.04	2	2	156	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:32:36.624846
70	45069881-b7f6-4344-ba36-65a9ddf48fe9	2025-11-25 22:32:43.620951	0.00	0.02	0.04	3	3	163	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7], "wilayah": ["Jakarta Barat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:32:43.620951
71	45069881-b7f6-4344-ba36-65a9ddf48fe9	2025-11-25 22:32:45.885024	0.00	0.02	0.03	4	4	165	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6], "wilayah": ["Jakarta Barat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:32:45.885024
72	45069881-b7f6-4344-ba36-65a9ddf48fe9	2025-11-25 22:32:47.529573	0.00	0.02	0.03	5	5	167	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 4, 5, 6], "wilayah": ["Jakarta Barat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:32:47.529573
73	45069881-b7f6-4344-ba36-65a9ddf48fe9	2025-11-25 22:32:52.040062	0.00	0.02	0.05	6	6	171	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 4, 6], "wilayah": ["Jakarta Barat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:32:52.040062
74	d500f22e-c8c5-40fb-94d8-cf3661d711e3	2025-11-25 22:32:56.853224	0.00	0.02	0.06	1	1	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:32:56.853224
75	d500f22e-c8c5-40fb-94d8-cf3661d711e3	2025-11-25 22:33:08.098582	0.00	0.02	0.04	2	2	11	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:33:08.098582
76	d500f22e-c8c5-40fb-94d8-cf3661d711e3	2025-11-25 22:33:09.176442	0.00	0.02	0.05	3	3	12	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 7], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:33:09.176442
77	d500f22e-c8c5-40fb-94d8-cf3661d711e3	2025-11-25 22:33:11.868399	0.00	0.02	0.05	4	4	15	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:33:11.868399
78	d500f22e-c8c5-40fb-94d8-cf3661d711e3	2025-11-25 22:33:15.124701	0.00	0.02	0.06	5	5	18	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 5], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:33:15.124701
79	d500f22e-c8c5-40fb-94d8-cf3661d711e3	2025-11-25 22:33:18.816173	0.00	0.02	0.04	6	6	22	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 5], "wilayah": ["Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:33:18.816173
80	d4b63ea4-8624-4f1a-bc36-ab0d4937e85d	2025-11-25 22:33:21.308422	0.00	0.02	0.04	1	1	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:33:21.308422
81	d4b63ea4-8624-4f1a-bc36-ab0d4937e85d	2025-11-25 22:33:39.386757	0.00	0.02	0.04	2	2	18	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:33:39.386757
82	d4b63ea4-8624-4f1a-bc36-ab0d4937e85d	2025-11-25 22:33:41.947302	0.00	0.02	0.04	3	3	20	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara"]}	success	2025-11-25 22:33:41.947302
83	d4b63ea4-8624-4f1a-bc36-ab0d4937e85d	2025-11-25 22:33:58.097361	0.00	0.02	0.04	4	4	36	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu", "Jakarta Barat"], "wisatawan": ["Wisatawan Mancanegara"]}	success	2025-11-25 22:33:58.097361
84	490bc1ae-f4b5-463b-8392-79da7a170aac	2025-11-25 22:34:02.465203	0.00	0.02	0.04	1	1	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:34:02.465203
85	490bc1ae-f4b5-463b-8392-79da7a170aac	2025-11-25 22:34:22.124392	0.00	0.02	0.04	2	2	19	f	\N	\N	\N	\N	{"year": "Semua", "months": [], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:34:22.124392
86	490bc1ae-f4b5-463b-8392-79da7a170aac	2025-11-25 22:34:27.055844	0.00	0.02	0.04	3	3	24	f	\N	\N	\N	\N	{"year": "Semua", "months": [1], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:34:27.055844
87	490bc1ae-f4b5-463b-8392-79da7a170aac	2025-11-25 22:34:30.055519	0.00	0.02	0.04	4	4	27	f	\N	\N	\N	\N	{"year": "Semua", "months": [], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:34:30.055519
88	490bc1ae-f4b5-463b-8392-79da7a170aac	2025-11-25 22:34:35.861076	0.00	0.02	0.04	5	5	33	f	\N	\N	\N	\N	{"year": "Semua", "months": [2], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:34:35.861076
89	490bc1ae-f4b5-463b-8392-79da7a170aac	2025-11-25 22:34:36.934735	0.00	0.02	0.04	6	6	34	f	\N	\N	\N	\N	{"year": "Semua", "months": [2, 3], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:34:36.934735
90	490bc1ae-f4b5-463b-8392-79da7a170aac	2025-11-25 22:34:37.474505	0.00	0.02	0.04	7	7	35	f	\N	\N	\N	\N	{"year": "Semua", "months": [2, 3, 5], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:34:37.474505
91	84e0b91f-f4db-415e-985f-6f76cc31b000	2025-11-25 22:35:00.611868	0.00	0.02	0.05	1	1	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:35:00.611868
92	84e0b91f-f4db-415e-985f-6f76cc31b000	2025-11-25 22:35:06.301175	0.00	0.02	0.03	2	2	5	f	\N	\N	\N	\N	{"year": "Semua", "months": [], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:35:06.301175
93	84e0b91f-f4db-415e-985f-6f76cc31b000	2025-11-25 22:35:08.72895	0.00	0.02	0.04	3	3	8	f	\N	\N	\N	\N	{"year": "Semua", "months": [], "wilayah": [], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:35:08.72895
94	84e0b91f-f4db-415e-985f-6f76cc31b000	2025-11-25 22:35:10.811366	0.00	0.02	0.03	4	4	10	f	\N	\N	\N	\N	{"year": "Semua", "months": [], "wilayah": [], "wisatawan": []}	success	2025-11-25 22:35:10.811366
95	84e0b91f-f4db-415e-985f-6f76cc31b000	2025-11-25 22:35:13.502476	0.00	0.02	0.05	5	5	12	f	\N	\N	\N	\N	{"year": "Semua", "months": [2], "wilayah": [], "wisatawan": []}	success	2025-11-25 22:35:13.502476
96	84e0b91f-f4db-415e-985f-6f76cc31b000	2025-11-25 22:35:14.309833	0.00	0.02	0.04	6	6	13	f	\N	\N	\N	\N	{"year": "Semua", "months": [2, 3], "wilayah": [], "wisatawan": []}	success	2025-11-25 22:35:14.309833
97	84e0b91f-f4db-415e-985f-6f76cc31b000	2025-11-25 22:36:20.242823	0.00	0.02	0.15	7	7	79	f	\N	\N	\N	\N	{"year": "Semua", "months": [2, 3], "wilayah": [], "wisatawan": []}	success	2025-11-25 22:36:20.242823
98	84e0b91f-f4db-415e-985f-6f76cc31b000	2025-11-25 22:36:24.479087	0.00	0.02	0.05	8	8	83	f	\N	\N	\N	\N	{"year": "Semua", "months": [], "wilayah": [], "wisatawan": []}	success	2025-11-25 22:36:24.479087
99	84e0b91f-f4db-415e-985f-6f76cc31b000	2025-11-25 22:36:28.960485	0.00	0.02	0.06	9	9	88	f	\N	\N	\N	\N	{"year": "Semua", "months": [2], "wilayah": [], "wisatawan": []}	success	2025-11-25 22:36:28.960485
100	84e0b91f-f4db-415e-985f-6f76cc31b000	2025-11-25 22:36:30.638117	0.00	0.02	0.04	10	10	90	f	\N	\N	\N	\N	{"year": "Semua", "months": [], "wilayah": [], "wisatawan": []}	success	2025-11-25 22:36:30.638117
101	84e0b91f-f4db-415e-985f-6f76cc31b000	2025-11-25 22:36:34.916267	0.00	0.02	0.03	11	11	94	f	\N	\N	\N	\N	{"year": "Semua", "months": [], "wilayah": [], "wisatawan": []}	success	2025-11-25 22:36:34.916267
102	dfb158f1-bf95-49eb-b195-34f0cfa6cd9e	2025-11-25 22:37:10.586118	0.04	0.03	0.16	1	1	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:37:10.586118
103	dfb158f1-bf95-49eb-b195-34f0cfa6cd9e	2025-11-25 22:37:14.86312	0.00	0.03	0.06	2	2	4	f	\N	\N	\N	\N	{"year": "Semua", "months": [], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:37:14.86312
104	3c8bfe38-3b2c-402d-bc6a-776985ab8226	2025-11-25 22:42:45.407906	0.00	0.03	0.04	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:42:45.407906
105	fd42b57a-bebf-4e10-85c5-c0656fc4be69	2025-11-25 22:44:58.21429	0.00	0.03	0.07	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:44:58.21429
106	fd42b57a-bebf-4e10-85c5-c0656fc4be69	2025-11-25 22:45:07.031425	0.00	0.03	0.04	2	1	8	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:45:07.031425
107	fd42b57a-bebf-4e10-85c5-c0656fc4be69	2025-11-25 22:45:14.539146	0.00	0.03	0.05	3	2	16	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7], "wilayah": ["Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:45:14.539146
108	fd42b57a-bebf-4e10-85c5-c0656fc4be69	2025-11-25 22:45:17.17297	0.00	0.03	0.04	4	3	19	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7], "wilayah": ["Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:45:17.17297
109	fd42b57a-bebf-4e10-85c5-c0656fc4be69	2025-11-25 22:45:19.647647	0.00	0.03	0.04	5	4	21	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 7], "wilayah": ["Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:45:19.647647
110	fd42b57a-bebf-4e10-85c5-c0656fc4be69	2025-11-25 22:45:20.945214	0.00	0.03	0.04	6	5	22	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5], "wilayah": ["Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:45:20.945214
111	d232db0d-bac5-4924-8e66-810cf650394d	2025-11-25 22:45:22.706404	0.00	0.03	0.04	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:45:22.706404
112	d232db0d-bac5-4924-8e66-810cf650394d	2025-11-25 22:45:28.717008	0.00	0.03	0.05	2	1	6	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:45:28.717008
113	d232db0d-bac5-4924-8e66-810cf650394d	2025-11-25 22:45:31.071	0.00	0.03	0.05	3	2	8	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 7, 8], "wilayah": ["Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:45:31.071
114	d232db0d-bac5-4924-8e66-810cf650394d	2025-11-25 22:45:36.291191	0.00	0.03	0.06	4	3	13	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 7, 8], "wilayah": ["Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:45:36.291191
115	d232db0d-bac5-4924-8e66-810cf650394d	2025-11-25 22:45:40.360266	0.00	0.03	0.06	5	4	17	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 7, 8], "wilayah": ["Jakarta Selatan", "Jakarta Timur", "Jakarta Utara"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:45:40.360266
116	d232db0d-bac5-4924-8e66-810cf650394d	2025-11-25 22:45:42.196652	0.00	0.03	0.04	6	5	19	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 7, 8], "wilayah": ["Jakarta Timur", "Jakarta Utara"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:45:42.196652
117	d232db0d-bac5-4924-8e66-810cf650394d	2025-11-25 22:45:43.162149	0.00	0.03	0.08	7	6	20	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 7, 8], "wilayah": ["Jakarta Utara"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:45:43.162149
118	d232db0d-bac5-4924-8e66-810cf650394d	2025-11-25 22:45:43.867759	0.00	0.03	0.07	8	7	21	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 7, 8], "wilayah": [], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:45:43.867759
119	d232db0d-bac5-4924-8e66-810cf650394d	2025-11-25 22:45:45.896827	0.00	0.03	0.05	9	8	23	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 7, 8], "wilayah": [], "wisatawan": ["Wisatawan Mancanegara"]}	success	2025-11-25 22:45:45.896827
120	d232db0d-bac5-4924-8e66-810cf650394d	2025-11-25 22:45:46.679106	0.00	0.03	0.22	10	9	24	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 7, 8], "wilayah": [], "wisatawan": []}	success	2025-11-25 22:45:46.679106
121	d232db0d-bac5-4924-8e66-810cf650394d	2025-11-25 22:45:48.060062	0.00	0.03	0.05	11	10	25	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 8], "wilayah": [], "wisatawan": []}	success	2025-11-25 22:45:48.060062
122	d232db0d-bac5-4924-8e66-810cf650394d	2025-11-25 22:45:49.835363	0.00	0.03	0.06	12	11	27	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5], "wilayah": [], "wisatawan": []}	success	2025-11-25 22:45:49.835363
123	672b224b-754c-4409-9ad0-88739520f7fd	2025-11-25 22:45:54.078967	0.00	0.03	0.04	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:45:54.078967
124	672b224b-754c-4409-9ad0-88739520f7fd	2025-11-25 22:45:57.941793	0.00	0.03	0.04	2	1	3	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:45:57.941793
125	672b224b-754c-4409-9ad0-88739520f7fd	2025-11-25 22:46:03.213609	0.00	0.03	0.05	3	2	9	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:46:03.213609
126	5ed07629-1275-4dfe-a51c-49fb0a5eef92	2025-11-25 22:46:33.709862	0.00	0.03	0.07	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:46:33.709862
127	5ed07629-1275-4dfe-a51c-49fb0a5eef92	2025-11-25 22:46:37.148559	0.00	0.03	0.05	2	1	3	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:46:37.148559
128	5ed07629-1275-4dfe-a51c-49fb0a5eef92	2025-11-25 22:46:38.776031	0.00	0.03	0.05	3	2	5	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 7, 8], "wilayah": ["Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:46:38.776031
129	5ed07629-1275-4dfe-a51c-49fb0a5eef92	2025-11-25 22:46:40.937447	0.00	0.03	0.04	4	3	7	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 7, 8], "wilayah": ["Jakarta Pusat", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:46:40.937447
130	5ed07629-1275-4dfe-a51c-49fb0a5eef92	2025-11-25 22:46:46.150671	0.00	0.03	0.05	5	4	12	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 7, 8], "wilayah": ["Jakarta Pusat", "Jakarta Timur", "Jakarta Utara"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:46:46.150671
131	6a5a7c66-0b0d-4490-bf76-7956e2be0dd9	2025-11-25 22:52:24.040269	0.03	0.02	0.07	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:52:24.040269
132	6a5a7c66-0b0d-4490-bf76-7956e2be0dd9	2025-11-25 22:52:28.315833	0.00	0.02	0.04	2	1	4	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:52:28.315833
274	748095dc-bca7-47af-993d-5441a4960de6	2025-12-01 22:32:53.697832	0.00	0.01	0.07	5	2	17	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-01 22:32:53.697832
133	6a5a7c66-0b0d-4490-bf76-7956e2be0dd9	2025-11-25 22:52:31.375071	0.00	0.02	0.04	3	2	7	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7], "wilayah": ["Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:52:31.375071
134	6a5a7c66-0b0d-4490-bf76-7956e2be0dd9	2025-11-25 22:52:36.20025	0.00	0.02	0.05	4	3	12	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7], "wilayah": ["Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:52:36.20025
135	6a5a7c66-0b0d-4490-bf76-7956e2be0dd9	2025-11-25 22:52:38.285914	0.00	0.02	0.05	5	4	14	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7], "wilayah": ["Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:52:38.285914
136	6a5a7c66-0b0d-4490-bf76-7956e2be0dd9	2025-11-25 22:52:39.329169	0.00	0.02	0.05	6	5	15	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7], "wilayah": ["Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:52:39.329169
137	6a5a7c66-0b0d-4490-bf76-7956e2be0dd9	2025-11-25 22:52:40.62301	0.00	0.02	0.04	7	6	16	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7], "wilayah": ["Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:52:40.62301
138	6a5a7c66-0b0d-4490-bf76-7956e2be0dd9	2025-11-25 22:52:41.360367	0.00	0.02	0.05	8	7	17	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7], "wilayah": [], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:52:41.360367
139	bdf35fc2-aa86-473c-b9d0-76928d8d2b26	2025-11-25 22:52:44.19963	0.00	0.02	0.04	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:52:44.19963
140	bdf35fc2-aa86-473c-b9d0-76928d8d2b26	2025-11-25 22:52:50.50858	0.00	0.02	0.04	2	1	6	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:52:50.50858
141	bdf35fc2-aa86-473c-b9d0-76928d8d2b26	2025-11-25 22:52:51.679029	0.00	0.02	0.06	3	2	7	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:52:51.679029
142	bdf35fc2-aa86-473c-b9d0-76928d8d2b26	2025-11-25 22:52:53.002555	0.00	0.02	0.04	4	3	8	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:52:53.002555
143	bdf35fc2-aa86-473c-b9d0-76928d8d2b26	2025-11-25 22:52:54.961593	0.00	0.02	0.06	5	4	10	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Utara"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:52:54.961593
144	bdf35fc2-aa86-473c-b9d0-76928d8d2b26	2025-11-25 22:52:57.17054	0.00	0.02	0.05	6	5	13	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Utara"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:52:57.17054
145	bdf35fc2-aa86-473c-b9d0-76928d8d2b26	2025-11-25 22:52:57.894256	0.00	0.02	0.06	7	6	13	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 7], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Utara"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:52:57.894256
146	bdf35fc2-aa86-473c-b9d0-76928d8d2b26	2025-11-25 22:52:59.507135	0.00	0.02	0.05	8	7	15	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Utara"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:52:59.507135
147	bdf35fc2-aa86-473c-b9d0-76928d8d2b26	2025-11-25 22:53:08.529556	0.00	0.02	0.05	9	8	24	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 7, 8], "wilayah": ["Jakarta Pusat", "Jakarta Selatan", "Jakarta Utara"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:53:08.529556
148	21cd727c-cffb-4e98-a34c-b5bcaa6baf30	2025-11-25 22:57:29.344612	0.00	0.02	0.05	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:57:29.344612
149	21cd727c-cffb-4e98-a34c-b5bcaa6baf30	2025-11-25 22:57:43.208607	0.00	0.02	0.04	2	1	13	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:57:43.208607
150	21cd727c-cffb-4e98-a34c-b5bcaa6baf30	2025-11-25 22:57:46.12124	0.00	0.02	0.05	3	2	16	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:57:46.12124
151	21cd727c-cffb-4e98-a34c-b5bcaa6baf30	2025-11-25 22:57:48.302021	0.00	0.02	0.05	4	3	19	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 8], "wilayah": ["Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:57:48.302021
152	21cd727c-cffb-4e98-a34c-b5bcaa6baf30	2025-11-25 22:57:51.631524	0.00	0.02	0.06	5	4	22	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 8], "wilayah": ["Jakarta Pusat", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:57:51.631524
153	21cd727c-cffb-4e98-a34c-b5bcaa6baf30	2025-11-25 22:57:52.974517	0.00	0.02	0.05	6	5	23	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 8], "wilayah": ["Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:57:52.974517
154	21cd727c-cffb-4e98-a34c-b5bcaa6baf30	2025-11-25 22:57:53.501241	0.00	0.02	0.06	7	6	24	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 8], "wilayah": ["Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:57:53.501241
155	21cd727c-cffb-4e98-a34c-b5bcaa6baf30	2025-11-25 22:57:53.998609	0.00	0.02	0.19	8	7	24	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 8], "wilayah": ["Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:57:53.998609
156	21cd727c-cffb-4e98-a34c-b5bcaa6baf30	2025-11-25 22:57:54.869693	0.00	0.02	0.04	9	8	25	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 8], "wilayah": [], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:57:54.869693
157	51931684-d6f8-413f-8075-79c17ef2f4b4	2025-11-25 22:57:56.404287	0.00	0.02	0.05	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:57:56.404287
158	51931684-d6f8-413f-8075-79c17ef2f4b4	2025-11-25 22:58:01.664743	0.00	0.02	0.05	2	1	5	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:58:01.664743
159	51931684-d6f8-413f-8075-79c17ef2f4b4	2025-11-25 22:58:03.233723	0.00	0.02	0.04	3	2	6	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:58:03.233723
160	51931684-d6f8-413f-8075-79c17ef2f4b4	2025-11-25 22:58:05.773704	0.00	0.02	0.04	4	3	9	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 5, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:58:05.773704
161	51931684-d6f8-413f-8075-79c17ef2f4b4	2025-11-25 22:58:08.243942	0.00	0.02	0.04	5	4	11	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 5, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:58:08.243942
162	51931684-d6f8-413f-8075-79c17ef2f4b4	2025-11-25 22:58:38.82247	0.00	0.02	0.04	6	4	42	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 5, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:58:38.82247
163	c1a4261f-929e-48af-95c5-dbb1331de456	2025-11-25 22:58:48.051829	0.01	0.02	0.14	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:58:48.051829
164	c1a4261f-929e-48af-95c5-dbb1331de456	2025-11-25 22:58:58.619327	0.00	0.02	0.05	2	0	10	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:58:58.619327
165	cf415d4f-2e19-440f-afe3-4886d57aa1f1	2025-11-25 22:59:06.308475	0.00	0.02	0.04	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:59:06.308475
166	25629465-4e08-4f0d-9235-38b370805dfc	2025-11-25 22:59:15.955755	0.00	0.02	0.04	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:59:15.955755
167	25629465-4e08-4f0d-9235-38b370805dfc	2025-11-25 22:59:38.736058	0.00	0.02	0.04	2	0	22	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:59:38.736058
168	25629465-4e08-4f0d-9235-38b370805dfc	2025-11-25 22:59:42.506414	0.00	0.02	0.06	3	1	26	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:59:42.506414
169	25629465-4e08-4f0d-9235-38b370805dfc	2025-11-25 22:59:44.599168	0.00	0.02	0.06	4	3	28	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:59:44.599168
170	25629465-4e08-4f0d-9235-38b370805dfc	2025-11-25 22:59:46.638593	0.00	0.02	0.04	5	4	30	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7], "wilayah": ["Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 22:59:46.638593
171	a3050833-695c-469a-864f-82be7145ee01	2025-11-25 23:00:15.194061	0.00	0.02	0.05	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 23:00:15.194061
172	e28d49af-3b3a-4691-9e08-9bb60dc1b9e3	2025-11-25 23:01:05.079788	0.00	0.02	0.04	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 23:01:05.079788
173	e28d49af-3b3a-4691-9e08-9bb60dc1b9e3	2025-11-25 23:01:46.751467	0.00	0.02	0.04	2	1	41	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 23:01:46.751467
174	a67cad4c-9ffc-47c9-9ca4-7fb2b8e7ccc9	2025-11-25 23:05:47.510222	0.03	0.02	0.09	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 23:05:47.510222
175	a67cad4c-9ffc-47c9-9ca4-7fb2b8e7ccc9	2025-11-25 23:06:01.604225	0.00	0.02	0.04	2	1	14	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 23:06:01.604225
176	a67cad4c-9ffc-47c9-9ca4-7fb2b8e7ccc9	2025-11-25 23:06:07.736751	0.00	0.02	0.06	3	2	20	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara"]}	success	2025-11-25 23:06:07.736751
177	a67cad4c-9ffc-47c9-9ca4-7fb2b8e7ccc9	2025-11-25 23:06:14.82519	0.00	0.02	0.06	4	3	27	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-11-25 23:06:14.82519
178	a67cad4c-9ffc-47c9-9ca4-7fb2b8e7ccc9	2025-11-25 23:06:42.092263	0.00	0.02	0.04	5	4	54	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-11-25 23:06:42.092263
179	a67cad4c-9ffc-47c9-9ca4-7fb2b8e7ccc9	2025-11-25 23:06:45.115235	0.00	0.02	0.04	6	5	57	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-11-25 23:06:45.115235
180	a67cad4c-9ffc-47c9-9ca4-7fb2b8e7ccc9	2025-11-25 23:06:47.504734	0.00	0.02	0.04	7	6	60	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 7, 8], "wilayah": ["Jakarta Pusat", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-11-25 23:06:47.504734
181	a67cad4c-9ffc-47c9-9ca4-7fb2b8e7ccc9	2025-11-25 23:06:51.879772	0.00	0.02	0.03	8	7	64	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 7, 8], "wilayah": ["Jakarta Pusat", "Jakarta Utara", "Kepulauan Seribu", "Jakarta Selatan"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-11-25 23:06:51.879772
182	a67cad4c-9ffc-47c9-9ca4-7fb2b8e7ccc9	2025-11-25 23:06:55.642303	0.00	0.02	0.04	9	8	68	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 7, 8, 6], "wilayah": ["Jakarta Pusat", "Jakarta Utara", "Kepulauan Seribu", "Jakarta Selatan"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-11-25 23:06:55.642303
183	a67cad4c-9ffc-47c9-9ca4-7fb2b8e7ccc9	2025-11-25 23:06:59.042413	0.00	0.02	0.04	10	9	71	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 7, 8], "wilayah": ["Jakarta Pusat", "Jakarta Utara", "Kepulauan Seribu", "Jakarta Selatan"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-11-25 23:06:59.042413
184	a67cad4c-9ffc-47c9-9ca4-7fb2b8e7ccc9	2025-11-25 23:09:38.154912	0.00	0.02	0.07	11	10	230	f	\N	\N	\N	\N	{"year": "2025", "months": [1, 2, 3, 4, 5, 7, 8], "wilayah": ["Jakarta Pusat", "Jakarta Utara", "Kepulauan Seribu", "Jakarta Selatan"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-11-25 23:09:38.154912
185	a67cad4c-9ffc-47c9-9ca4-7fb2b8e7ccc9	2025-11-25 23:09:44.601595	0.00	0.02	0.04	12	11	237	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 7, 8], "wilayah": ["Jakarta Pusat", "Jakarta Utara", "Kepulauan Seribu", "Jakarta Selatan"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-11-25 23:09:44.601595
186	a67cad4c-9ffc-47c9-9ca4-7fb2b8e7ccc9	2025-11-25 23:09:46.479397	0.00	0.02	0.04	13	12	239	f	\N	\N	\N	\N	{"year": "2025", "months": [1, 2, 3, 4, 5, 7, 8], "wilayah": ["Jakarta Pusat", "Jakarta Utara", "Kepulauan Seribu", "Jakarta Selatan"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-11-25 23:09:46.479397
187	59fc3512-14c9-42ff-a5af-bc7d647f2ca7	2025-11-25 23:13:28.664829	0.00	0.02	0.05	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 23:13:28.664829
188	c45d3d79-55ba-4ffa-b48c-8bf594fee42b	2025-11-25 23:13:50.098906	0.00	0.02	0.05	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 23:13:50.098906
189	c45d3d79-55ba-4ffa-b48c-8bf594fee42b	2025-11-25 23:13:55.812251	0.00	0.02	0.05	2	1	5	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 23:13:55.812251
190	c45d3d79-55ba-4ffa-b48c-8bf594fee42b	2025-11-25 23:13:58.324102	0.00	0.02	0.04	3	2	8	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 23:13:58.324102
191	c45d3d79-55ba-4ffa-b48c-8bf594fee42b	2025-11-25 23:14:01.15643	0.00	0.02	0.04	4	3	11	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu", "Jakarta Barat"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-25 23:14:01.15643
192	f1dd29cf-2322-4dbb-ae52-89c992e1be71	2025-11-26 03:07:20.750683	0.07	0.05	0.24	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-26 03:07:20.750683
193	f1dd29cf-2322-4dbb-ae52-89c992e1be71	2025-11-26 03:07:44.03457	0.00	0.05	0.05	2	1	23	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-26 03:07:44.03457
194	f1dd29cf-2322-4dbb-ae52-89c992e1be71	2025-11-26 03:07:53.907686	0.00	0.05	0.06	3	2	33	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7], "wilayah": [], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-26 03:07:53.907686
195	f1dd29cf-2322-4dbb-ae52-89c992e1be71	2025-11-26 03:07:56.001222	0.00	0.05	0.05	4	3	35	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7], "wilayah": ["Jakarta Barat"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-26 03:07:56.001222
196	f1dd29cf-2322-4dbb-ae52-89c992e1be71	2025-11-26 03:07:56.97735	0.00	0.05	0.04	5	4	36	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7], "wilayah": ["Jakarta Barat", "Jakarta Pusat"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-26 03:07:56.97735
197	f1dd29cf-2322-4dbb-ae52-89c992e1be71	2025-11-26 03:07:58.976607	0.00	0.05	0.04	6	5	38	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Timur"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-26 03:07:58.976607
198	f1dd29cf-2322-4dbb-ae52-89c992e1be71	2025-11-26 03:08:01.084949	0.00	0.05	0.07	7	6	40	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Timur", "Jakarta Utara"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-26 03:08:01.084949
199	1f8d4edf-5bdb-4879-8983-7aeba415413e	2025-11-26 04:25:26.205906	0.07	0.05	0.37	1	0	1	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-26 04:25:26.205906
200	1f8d4edf-5bdb-4879-8983-7aeba415413e	2025-11-26 04:26:00.60088	0.00	0.05	0.05	2	1	35	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-26 04:26:00.60088
201	1f8d4edf-5bdb-4879-8983-7aeba415413e	2025-11-26 04:28:19.816729	0.00	0.05	0.04	3	2	174	f	\N	\N	\N	\N	{"year": "Semua", "months": [], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-26 04:28:19.816729
202	1f8d4edf-5bdb-4879-8983-7aeba415413e	2025-11-26 04:28:21.677413	0.00	0.05	0.05	4	3	176	f	\N	\N	\N	\N	{"year": "Semua", "months": [2], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-26 04:28:21.677413
203	1f8d4edf-5bdb-4879-8983-7aeba415413e	2025-11-26 04:28:52.171881	0.00	0.05	0.05	5	4	207	f	\N	\N	\N	\N	{"year": "Semua", "months": [], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-26 04:28:52.171881
204	1f8d4edf-5bdb-4879-8983-7aeba415413e	2025-11-26 06:23:25.853316	0.02	0.01	0.06	6	5	7080	f	\N	\N	\N	\N	{"year": "Semua", "months": [], "wilayah": ["Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-26 06:23:25.853316
222	9cb0dea0-8259-433d-b717-bcad0feabe5a	2025-11-26 13:58:59.82959	0.00	0.03	0.04	5	4	113	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 7], "wilayah": ["Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara"]}	success	2025-11-26 13:58:59.82959
205	0cf99808-e90d-47db-bad0-9753a066b78c	2025-11-26 07:55:54.148053	0.03	0.01	0.07	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-26 07:55:54.148053
206	2712291e-0391-469e-a2ef-f3ac866f345a	2025-11-26 07:58:00.614935	0.00	0.01	0.06	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-26 07:58:00.614935
207	f891b3d8-3ab8-4eba-940f-281288036ebb	2025-11-26 07:59:37.654312	0.02	0.01	0.07	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-26 07:59:37.654312
208	9b7b7ba8-fb5b-433d-9960-c68d6556cba8	2025-11-26 08:01:52.067023	0.00	0.01	0.06	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-26 08:01:52.067023
209	9b7b7ba8-fb5b-433d-9960-c68d6556cba8	2025-11-26 08:03:03.49114	0.00	0.01	0.04	2	1	71	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-26 08:03:03.49114
210	9b7b7ba8-fb5b-433d-9960-c68d6556cba8	2025-11-26 08:03:06.322837	0.00	0.01	0.04	3	2	74	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 5, 6, 7, 8], "wilayah": ["Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-26 08:03:06.322837
211	9b7b7ba8-fb5b-433d-9960-c68d6556cba8	2025-11-26 08:03:08.669102	0.00	0.01	0.05	4	3	76	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 5, 6, 7, 8, 4], "wilayah": ["Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-26 08:03:08.669102
212	9b7b7ba8-fb5b-433d-9960-c68d6556cba8	2025-11-26 08:03:11.789886	0.00	0.01	0.04	5	4	79	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 5, 6, 7, 8, 4], "wilayah": ["Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu", "Jakarta Barat"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-26 08:03:11.789886
213	90da418e-63c3-4525-8958-dbb31c85ca91	2025-11-26 08:08:16.209829	0.01	0.01	0.05	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-26 08:08:16.209829
214	001cccf2-5956-419f-9f5a-dc078e75e5b0	2025-11-26 08:09:35.943777	0.00	0.01	0.04	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-26 08:09:35.943777
215	75fc45a3-34a9-4650-bcad-7c538f5c6086	2025-11-26 08:13:55.843573	0.02	0.01	0.06	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-26 08:13:55.843573
216	75fc45a3-34a9-4650-bcad-7c538f5c6086	2025-11-26 08:14:57.315473	0.00	0.01	0.05	2	1	61	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara"]}	success	2025-11-26 08:14:57.315473
217	75fc45a3-34a9-4650-bcad-7c538f5c6086	2025-11-26 08:15:01.39297	0.00	0.01	0.04	3	2	65	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-11-26 08:15:01.39297
218	9cb0dea0-8259-433d-b717-bcad0feabe5a	2025-11-26 13:57:06.69453	0.03	0.03	0.26	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-26 13:57:06.69453
219	9cb0dea0-8259-433d-b717-bcad0feabe5a	2025-11-26 13:57:28.820178	0.00	0.03	0.05	2	1	22	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-26 13:57:28.820178
220	9cb0dea0-8259-433d-b717-bcad0feabe5a	2025-11-26 13:57:34.293963	0.00	0.03	0.04	3	2	28	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7], "wilayah": ["Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-26 13:57:34.293963
221	9cb0dea0-8259-433d-b717-bcad0feabe5a	2025-11-26 13:58:55.319436	0.00	0.03	0.05	4	3	109	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7], "wilayah": ["Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara"]}	success	2025-11-26 13:58:55.319436
223	9cb0dea0-8259-433d-b717-bcad0feabe5a	2025-11-26 14:00:24.395505	0.00	0.03	0.05	6	5	198	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 7], "wilayah": ["Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-11-26 14:00:24.395505
224	9cb0dea0-8259-433d-b717-bcad0feabe5a	2025-11-26 14:00:37.916507	0.00	0.03	0.03	7	6	211	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 7], "wilayah": ["Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu", "Jakarta Barat"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-11-26 14:00:37.916507
225	ebdf9cff-2fa2-481e-87b3-06d2b29614d3	2025-11-26 14:03:35.329262	0.06	0.04	0.34	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-26 14:03:35.329262
226	ebdf9cff-2fa2-481e-87b3-06d2b29614d3	2025-11-26 14:04:50.058353	0.00	0.04	0.05	2	1	75	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-26 14:04:50.058353
227	ebdf9cff-2fa2-481e-87b3-06d2b29614d3	2025-11-26 14:05:03.908146	0.00	0.04	0.04	3	2	89	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-26 14:05:03.908146
228	ebdf9cff-2fa2-481e-87b3-06d2b29614d3	2025-11-26 14:05:32.794251	0.00	0.04	0.03	4	3	118	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu", "Jakarta Pusat"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-26 14:05:32.794251
229	ebdf9cff-2fa2-481e-87b3-06d2b29614d3	2025-11-26 14:05:35.667839	0.00	0.04	0.04	5	4	121	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 5, 6, 7, 8, 4], "wilayah": ["Jakarta Barat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu", "Jakarta Pusat"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-26 14:05:35.667839
230	ebdf9cff-2fa2-481e-87b3-06d2b29614d3	2025-11-26 14:06:44.14052	0.00	0.04	0.05	6	4	189	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 5, 6, 7, 8, 4], "wilayah": ["Jakarta Barat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu", "Jakarta Pusat"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-26 14:06:44.14052
231	7c90068b-9d26-4afc-b92f-1ec48ad3dbbb	2025-11-26 14:06:48.821309	0.00	0.04	0.05	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-26 14:06:48.821309
232	953df163-1ba8-4cc1-8f6b-186c81f3b10b	2025-11-26 14:24:59.706586	0.02	0.02	0.07	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-26 14:24:59.706586
233	953df163-1ba8-4cc1-8f6b-186c81f3b10b	2025-11-26 14:25:35.628138	0.00	0.02	0.04	2	1	35	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-26 14:25:35.628138
234	953df163-1ba8-4cc1-8f6b-186c81f3b10b	2025-11-26 14:25:43.346193	0.00	0.02	0.04	3	1	43	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-26 14:25:43.346193
235	e4ebbec8-7355-4b32-ada8-7c19074713cc	2025-11-26 14:25:47.355128	0.00	0.02	0.04	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-26 14:25:47.355128
236	e4ebbec8-7355-4b32-ada8-7c19074713cc	2025-11-26 14:25:55.882159	0.00	0.02	0.06	2	0	8	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-26 14:25:55.882159
237	144384b2-24b0-431c-8899-6e6149291ca4	2025-11-26 14:25:59.709227	0.00	0.02	0.04	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-26 14:25:59.709227
238	f0f4d6a8-3605-4ff0-8154-7ed12e6f0efb	2025-11-26 14:30:41.054245	0.00	0.02	0.04	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-26 14:30:41.054245
239	f0f4d6a8-3605-4ff0-8154-7ed12e6f0efb	2025-11-26 14:30:57.132235	0.00	0.02	0.03	2	1	16	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-26 14:30:57.132235
240	5658a3b6-ae93-44d4-a81e-dfb15257a572	2025-11-26 14:31:05.710274	0.00	0.02	0.05	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-26 14:31:05.710274
241	5658a3b6-ae93-44d4-a81e-dfb15257a572	2025-11-26 14:31:13.491679	0.00	0.02	0.08	2	1	7	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-26 14:31:13.491679
242	5658a3b6-ae93-44d4-a81e-dfb15257a572	2025-11-26 14:31:23.2051	0.00	0.02	0.04	3	3	17	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-26 14:31:23.2051
243	e62ee2a6-3dc9-4a05-bc33-5b81a488ef1f	2025-11-26 14:31:26.820883	0.00	0.02	0.06	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-26 14:31:26.820883
244	e62ee2a6-3dc9-4a05-bc33-5b81a488ef1f	2025-11-26 14:31:33.352484	0.00	0.02	0.25	2	1	6	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-26 14:31:33.352484
245	240fd587-b85f-4b1a-8d00-7ffd44bd246e	2025-11-26 15:05:22.449695	0.02	0.01	0.06	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-26 15:05:22.449695
246	fa414813-f230-4b8b-bbcf-a7631d430721	2025-11-26 15:15:23.238637	0.03	0.02	0.10	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-26 15:15:23.238637
247	4910394d-7c6c-4f80-a9de-7741d19118d6	2025-11-26 15:15:28.314568	0.00	0.02	0.05	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-26 15:15:28.314568
248	160ad7e8-ef8a-4c64-972e-42eb6af9d140	2025-11-26 15:15:31.263795	0.00	0.02	0.07	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-26 15:15:31.263795
249	b3ea3bfa-0dba-41c2-bdf5-e14d679cb6fb	2025-11-27 22:25:35.866962	0.09	0.07	0.82	1	0	1	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-27 22:25:35.866962
250	cf6ae4f3-e9b1-4771-abf7-872d8268a56f	2025-11-28 06:57:11.377166	0.06	0.05	0.72	1	0	1	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-11-28 06:57:11.377166
251	07944def-bb1d-4f0c-b343-aca02ff03e85	2025-12-01 01:35:57.557997	0.09	0.07	0.72	1	0	1	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-01 01:35:57.557997
252	07944def-bb1d-4f0c-b343-aca02ff03e85	2025-12-01 02:36:18.903342	0.15	0.13	0.21	2	2	3623	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-01 02:36:18.903342
253	642597ea-f606-4e8e-992d-8e86ec015854	2025-12-01 02:58:47.610694	0.07	0.02	0.13	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-01 02:58:47.610694
254	ad2279e3-212f-4c3b-bfd2-eb9de6209a28	2025-12-01 03:02:35.720449	0.00	0.02	0.04	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-01 03:02:35.720449
255	09d3a87f-7b7d-44c9-bda1-91140191a74f	2025-12-01 03:02:41.490117	0.00	0.02	0.05	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-01 03:02:41.490117
256	89a7a344-f348-446a-a59a-a5dab46ff85c	2025-12-01 03:04:53.957666	0.00	0.02	0.05	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-01 03:04:53.957666
257	90bfc721-c76c-4d0e-9db3-991ef11fdc39	2025-12-01 03:05:17.195341	0.00	0.02	0.07	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-01 03:05:17.195341
258	7ee23c88-1585-4448-9131-2ecd7c4778ff	2025-12-01 03:11:01.545778	0.02	0.01	0.07	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-01 03:11:01.545778
259	0e762549-eedb-46e7-b88c-37998e07945a	2025-12-01 03:11:31.830625	0.00	0.01	0.04	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-01 03:11:31.830625
260	14e923df-5604-485f-97a8-61456a68bb61	2025-12-01 03:11:59.805078	0.00	0.01	0.04	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-01 03:11:59.805078
261	2518ef08-0b8d-4af7-af28-cd43363221e8	2025-12-01 03:12:20.85082	0.00	0.01	0.06	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-01 03:12:20.85082
262	8293cc48-8a9a-40d6-84b5-078eb9868a1a	2025-12-01 20:10:23.44648	0.06	0.05	0.60	1	0	1	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-01 20:10:23.44648
263	8f69a9d8-a1bc-4bf6-b065-66a4ccd36dd1	2025-12-01 21:05:29.577769	0.02	0.01	0.08	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-01 21:05:29.577769
264	8f69a9d8-a1bc-4bf6-b065-66a4ccd36dd1	2025-12-01 21:05:39.312121	0.00	0.01	0.06	2	2	9	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-01 21:05:39.312121
265	8f69a9d8-a1bc-4bf6-b065-66a4ccd36dd1	2025-12-01 21:05:43.073332	0.00	0.01	0.06	3	4	13	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-01 21:05:43.073332
266	fbea683a-483a-4902-8ece-7c533db5d1b0	2025-12-01 21:11:47.275597	0.00	0.01	0.08	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-01 21:11:47.275597
267	4ecba3d0-f914-41c0-a398-0f021fabed0d	2025-12-01 21:12:38.806691	0.01	0.01	0.10	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-01 21:12:38.806691
268	47e61d98-7ea4-474e-b4ce-4c182e66885d	2025-12-01 21:13:25.999146	0.00	0.01	0.06	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-01 21:13:25.999146
269	db2d05bd-b196-46f2-a036-6f05882404ee	2025-12-01 21:13:42.7593	0.00	0.01	0.06	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-01 21:13:42.7593
270	db2d05bd-b196-46f2-a036-6f05882404ee	2025-12-01 22:19:33.167147	0.29	0.25	0.73	2	2	3950	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara"]}	success	2025-12-01 22:19:33.167147
271	db2d05bd-b196-46f2-a036-6f05882404ee	2025-12-01 22:19:36.428332	0.00	0.25	0.08	3	4	3953	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-01 22:19:36.428332
272	748095dc-bca7-47af-993d-5441a4960de6	2025-12-01 22:32:36.496653	0.02	0.01	0.11	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-01 22:32:36.496653
273	748095dc-bca7-47af-993d-5441a4960de6	2025-12-01 22:32:49.204327	0.00	0.01	0.04	3	1	12	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": [], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-01 22:32:49.204327
275	1781a831-9e12-44bc-8b54-08bf5902ca63	2025-12-01 22:33:08.665906	0.02	0.01	0.06	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-01 22:33:08.665906
276	1781a831-9e12-44bc-8b54-08bf5902ca63	2025-12-01 22:33:16.184793	0.00	0.01	0.08	2	2	7	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara"]}	success	2025-12-01 22:33:16.184793
277	1781a831-9e12-44bc-8b54-08bf5902ca63	2025-12-01 22:33:17.695652	0.00	0.01	0.04	3	4	9	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-01 22:33:17.695652
278	1781a831-9e12-44bc-8b54-08bf5902ca63	2025-12-01 22:33:30.978623	0.00	0.01	0.05	4	5	22	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-01 22:33:30.978623
279	2b7d7982-a099-4a28-9ec6-56805aa838b3	2025-12-01 22:37:51.066589	0.00	0.01	0.03	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-01 22:37:51.066589
280	2b7d7982-a099-4a28-9ec6-56805aa838b3	2025-12-01 23:21:03.235171	0.02	0.01	0.07	2	2	2592	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-01 23:21:03.235171
281	2b7d7982-a099-4a28-9ec6-56805aa838b3	2025-12-01 23:21:06.909134	0.00	0.01	0.04	3	4	2595	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-01 23:21:06.909134
282	2b7d7982-a099-4a28-9ec6-56805aa838b3	2025-12-01 23:21:15.177175	0.00	0.01	0.04	4	6	2604	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-01 23:21:15.177175
283	2b7d7982-a099-4a28-9ec6-56805aa838b3	2025-12-01 23:21:17.753421	0.00	0.01	0.03	5	8	2606	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu", "Jakarta Pusat"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-01 23:21:17.753421
284	2b7d7982-a099-4a28-9ec6-56805aa838b3	2025-12-01 23:21:26.61996	0.00	0.01	0.04	6	10	2615	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu", "Jakarta Pusat"], "wisatawan": ["Wisatawan Mancanegara"]}	success	2025-12-01 23:21:26.61996
285	2b7d7982-a099-4a28-9ec6-56805aa838b3	2025-12-01 23:21:27.414252	0.00	0.01	0.04	7	11	2616	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu", "Jakarta Pusat"], "wisatawan": []}	success	2025-12-01 23:21:27.414252
286	2b7d7982-a099-4a28-9ec6-56805aa838b3	2025-12-01 23:21:28.470455	0.00	0.01	0.05	8	13	2617	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu", "Jakarta Pusat"], "wisatawan": ["Wisatawan Nusantara"]}	success	2025-12-01 23:21:28.470455
287	2b7d7982-a099-4a28-9ec6-56805aa838b3	2025-12-01 23:21:29.791221	0.00	0.01	0.05	9	15	2618	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu", "Jakarta Pusat"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-01 23:21:29.791221
288	2b7d7982-a099-4a28-9ec6-56805aa838b3	2025-12-01 23:26:39.622222	0.00	0.01	0.07	10	16	2928	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu", "Jakarta Pusat"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-01 23:26:39.622222
289	6c8849a6-f305-4ee3-8ff3-dcd963012436	2025-12-01 23:48:33.259776	0.05	0.04	0.14	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-01 23:48:33.259776
290	175624e7-0881-484c-9e39-80324b836fb7	2025-12-01 23:50:48.194773	0.00	0.04	0.06	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-01 23:50:48.194773
291	f04d04a3-93ab-4b18-9ddd-3bac5f034120	2025-12-01 23:56:55.838667	0.00	0.04	0.06	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-01 23:56:55.838667
292	54682119-41ff-4c10-b9fa-1f43d7ee327d	2025-12-02 00:01:36.68293	0.02	0.01	0.07	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-02 00:01:36.68293
293	878db2c8-6c06-4508-ac69-53c71fed8319	2025-12-02 00:07:21.267762	0.00	0.01	0.04	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-02 00:07:21.267762
294	1f41c0cf-5336-4b5c-9367-c277826108d2	2025-12-02 00:13:32.421173	0.03	0.02	0.08	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-02 00:13:32.421173
295	4869d041-69de-40a2-8d0c-f89b327964bf	2025-12-02 00:14:50.519753	0.00	0.02	0.06	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-02 00:14:50.519753
296	c4ef630f-ac87-4dfb-b63b-20775489d046	2025-12-02 00:15:20.375976	0.00	0.02	0.04	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-02 00:15:20.375976
297	0a6c587a-22fa-47dc-8e01-2822d7c041e8	2025-12-02 00:18:43.138381	0.00	0.02	0.04	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-02 00:18:43.138381
298	fae49036-d1f2-4a76-a164-003ea6b4bbaf	2025-12-02 00:19:41.431931	0.00	0.02	0.03	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-02 00:19:41.431931
299	714929df-6aa9-41ae-af2b-0848c1dcbe9a	2025-12-02 00:20:13.726778	0.00	0.02	0.06	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-02 00:20:13.726778
300	51bfd1e0-4976-4e74-b56a-2504dfe5ed9e	2025-12-02 00:21:46.714754	0.00	0.02	0.04	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-02 00:21:46.714754
301	1e51b506-d328-4314-97a1-22bf8947cae4	2025-12-02 00:26:07.880018	0.02	0.01	0.06	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-02 00:26:07.880018
302	a99924d6-ce04-4ea9-9898-69bcbf34ea03	2025-12-02 00:26:59.544227	0.00	0.01	0.05	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-02 00:26:59.544227
303	95abaa3a-e8e2-48bf-9610-1ce9d46d6db3	2025-12-02 00:29:25.932338	0.00	0.01	0.06	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-02 00:29:25.932338
304	5aacee66-50c8-46c8-8d9a-f1be60722f87	2025-12-02 00:30:56.514157	0.00	0.01	0.05	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-02 00:30:56.514157
305	706821bb-5e5c-47a8-aec6-8a591b658845	2025-12-02 00:31:15.83705	0.00	0.01	0.04	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-02 00:31:15.83705
306	e41982b6-96ab-4519-9685-ae056ca93052	2025-12-02 00:31:41.653852	0.00	0.01	0.05	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-02 00:31:41.653852
307	de57a20d-d9cf-47fc-8ca6-79d79ad8dd8b	2025-12-02 00:32:18.988761	0.00	0.01	0.05	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-02 00:32:18.988761
308	08d35c9d-1ef5-4b80-984f-4024bf1850cf	2025-12-02 00:33:17.604256	0.00	0.01	0.09	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-02 00:33:17.604256
309	d2444149-b80c-4f12-8e3e-7bb4a79d5d16	2025-12-02 00:33:30.676706	0.00	0.01	0.05	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-02 00:33:30.676706
310	bb6ccab2-3823-4db4-b969-3c1e8eccdd41	2025-12-02 00:34:23.929572	0.00	0.01	0.06	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-02 00:34:23.929572
311	8287ecdb-2108-4ef3-8ff4-9737f28dc0c4	2025-12-02 00:35:02.780009	0.00	0.01	0.05	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-02 00:35:02.780009
312	dab9d67c-3142-4e82-972f-d0e7f9a8d9bc	2025-12-02 00:39:42.964653	0.02	0.01	0.06	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-02 00:39:42.964653
313	dab9d67c-3142-4e82-972f-d0e7f9a8d9bc	2025-12-02 01:20:54.282929	0.02	0.01	0.06	2	2	2471	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-02 01:20:54.282929
314	dab9d67c-3142-4e82-972f-d0e7f9a8d9bc	2025-12-02 02:59:36.743084	0.24	0.21	0.34	3	4	8393	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-02 02:59:36.743084
315	dab9d67c-3142-4e82-972f-d0e7f9a8d9bc	2025-12-02 02:59:39.852107	0.01	0.21	0.03	4	6	8396	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Kepulauan Seribu", "Jakarta Timur"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-02 02:59:39.852107
316	dab9d67c-3142-4e82-972f-d0e7f9a8d9bc	2025-12-02 02:59:42.407431	0.00	0.21	0.03	5	8	8399	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Kepulauan Seribu", "Jakarta Timur", "Jakarta Utara"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-02 02:59:42.407431
317	b5f13916-5893-417b-82ec-2c8ee29fa795	2025-12-02 05:46:44.194775	0.05	0.04	0.31	1	0	1	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-02 05:46:44.194775
\.


--
-- TOC entry 5130 (class 0 OID 17274)
-- Dependencies: 221
-- Data for Name: dim_objek_wisata; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dim_objek_wisata (objek_wisata_id, nama_objek, alamat, longitude, latitude, wilayah, created_at, updated_at) FROM stdin;
1	Museum Joang '45	Jl. Menteng Raya No.31 1, RT.1/RW.10, Kebon Sirih, Kec. Menteng, Kota Jakarta Pusat, Daerah Khusus Ibukota Jakarta 10340	-6.1857868	106.8370903	Jakarta Pusat	2025-11-25 18:50:09.458563	2025-11-25 18:50:09.458563
2	Museum Nasional	Jl. Medan Merdeka Barat No.12, Gambir, Kecamatan Gambir, Kota Jakarta Pusat, Daerah Khusus Ibukota Jakarta 10110	-6.1761728	106.8215150	Jakarta Pusat	2025-11-25 18:50:09.458563	2025-11-25 18:50:09.458563
3	Museum Basoeki Abdullah	Jl. Keuangan Raya No.19, Cilandak Barat, Kec. Cilandak, Kota Jakarta Selatan, Daerah Khusus Ibukota Jakarta 12430	-6.2897189	106.7936438	Jakarta Selatan	2025-11-25 18:50:09.458563	2025-11-25 18:50:09.458563
4	Kawasan Kota Tua	Kawasan Kota Tua, Taman Fatahillah No.1 7, RT.7/RW.7, Pinangsia, Kec. Taman Sari, Kota Jakarta Barat, Daerah Khusus Ibukota Jakarta 11110	-6.1349514	106.8146451	Jakarta Barat	2025-11-25 18:50:09.458563	2025-11-25 18:50:09.458563
5	Museum Perumusan Naskah Proklamasi	Jl. Imam Bonjol No.1, RT.9/RW.4, Menteng, Kec. Menteng, Kota Jakarta Pusat, Daerah Khusus Ibukota Jakarta 10310	-6.2002139	106.8310637	Jakarta Pusat	2025-11-25 18:50:09.458563	2025-11-25 18:50:09.458563
6	Taman Lapangan Banteng	RRJM+4W5, Pasar Baru, Kecamatan Sawah Besar, Kota Jakarta Pusat, Daerah Khusus Ibukota Jakarta 10710	-6.1703843	106.8354348	Jakarta Pusat	2025-11-25 18:50:09.458563	2025-11-25 18:50:09.458563
7	Taman Mini Indonesia Indah	Jl. Taman Mini Indonesia Indah, Ceger, Kec. Cipayung, Kota Jakarta Timur, Daerah Khusus Ibukota Jakarta 13820	-6.3019000	106.8904181	Jakarta Timur	2025-11-25 18:50:09.458563	2025-11-25 18:50:09.458563
8	Rumah Si Pitung (Situs Marunda)	Jl. Kampung Marunda Pulo, 2, RT.2/RW.7, Marunda, Kec. Cilincing, Jakarta Utara, Daerah Khusus Ibukota Jakarta 14150	-6.0968037	106.9588842	Jakarta Utara	2025-11-25 18:50:09.458563	2025-11-25 18:50:09.458563
9	Taman Marga Satwa Ragunan	Jl. Harsono Rm Dalam No.1, Ragunan, Ps. Minggu, Kota Jakarta Selatan, Daerah Khusus Ibukota Jakarta 12550	-6.3045974	106.8210269	Jakarta Selatan	2025-11-25 18:50:09.458563	2025-11-25 18:50:09.458563
10	Museum Prasasti	Jl. Tanah Abang I No.1, RT.11/RW.8, Petojo Selatan, Kecamatan Gambir, Kota Jakarta Pusat, Daerah Khusus Ibukota Jakarta 10160	-6.1722280	106.8191788	Jakarta Pusat	2025-11-25 18:50:09.458563	2025-11-25 18:50:09.458563
11	Museum Sumpah Pemuda	Jl. Kramat Raya No.106, RT.2/RW.9, Kwitang, Kec. Senen, Kota Jakarta Pusat, Daerah Khusus Ibukota Jakarta 10420	-6.1836041	106.8430829	Jakarta Pusat	2025-11-25 18:50:09.458563	2025-11-25 18:50:09.458563
12	Ruang Terbuka Hijau Tebet Eco Park	Jl. Tebet Barat Raya, RT.1/RW.10, Tebet Barat, Kec. Tebet, Kota Jakarta Selatan, Daerah Khusus Ibukota Jakarta 12820	-6.2372102	106.8534290	Jakarta Selatan	2025-11-25 18:50:09.458563	2025-11-25 18:50:09.458563
13	Kepulauan Seribu	Pulau Pramuka, Pulau Panggang, Kepulauan Seribu Utara, Kab. Administrasi Kepulauan Seribu, Daerah Khusus Ibukota Jakarta 14530	-5.7452702	106.6156112	Kepulauan Seribu	2025-11-25 18:50:09.458563	2025-11-25 18:50:09.458563
14	Museum Kebangkitan Nasional	Jl. Abdul Rachman Saleh No.26, Senen, Kec. Senen, Kota Jakarta Pusat, Daerah Khusus Ibukota Jakarta 10410	-6.1785723	106.8379842	Jakarta Pusat	2025-11-25 18:50:09.458563	2025-11-25 18:50:09.458563
15	Museum Bahari	Jl. Pasar Ikan No.1, RT.11/RW.4, Penjaringan, Kec. Penjaringan, Jakarta Utara, Daerah Khusus Ibukota Jakarta 14440	-6.1264949	106.8082563	Jakarta Utara	2025-11-25 18:50:09.458563	2025-11-25 18:50:09.458563
16	Museum Satria Mandala	Jl. Gatot Subroto No.14, RT.6/RW.1, Kuningan Barat, Kec. Mampang Prapatan, Kota Jakarta Selatan, Daerah Khusus Ibukota Jakarta 12710	-6.2316899	106.8192872	Jakarta Selatan	2025-11-25 18:50:09.458563	2025-11-25 18:50:09.458563
17	Museum Mohammad Hoesni Thamrin	Jl. Kenari 2 No.15, RW.4, Kenari, Kec. Senen, Kota Jakarta Pusat, Daerah Khusus Ibukota Jakarta 10430	-6.1937697	106.8456782	Jakarta Pusat	2025-11-25 18:50:09.458563	2025-11-25 18:50:09.458563
18	Taman Impian Jaya Ancol	Jl. Lodan Timur No.7, RT.14/RW.10, Ancol, Kec. Pademangan, Jakarta Utara, Daerah Khusus Ibukota Jakarta 14430	-6.1226706	106.8331808	Jakarta Utara	2025-11-25 18:50:09.458563	2025-11-25 18:50:09.458563
19	Monumen Nasional	Merdeka Square, Jalan Lapangan Monas, Gambir, Kecamatan Gambir, Kota Jakarta Pusat, Daerah Khusus Ibukota Jakarta 10110	-6.1751897	106.8273888	Jakarta Pusat	2025-11-25 18:50:09.458563	2025-11-25 18:50:09.458563
20	Museum Wayang	Jalan Pintu Besar Utara No.27 Pinangsia, RT.3/RW.6, Kota Tua, Kec. Taman Sari, Kota Jakarta Barat, Daerah Khusus Ibukota Jakarta 11110	-6.1347258	106.8131962	Jakarta Barat	2025-11-25 18:50:09.458563	2025-11-25 18:50:09.458563
21	Perkampungan Budaya Betawi Setu Babakan	Jl. Situ Babakan No.18 13, RT.13/RW.8, Srengseng Sawah, Kec. Jagakarsa, Kota Jakarta Selatan, Daerah Khusus Ibukota Jakarta 12630	-6.3392553	106.8250668	Jakarta Selatan	2025-11-25 18:50:09.458563	2025-11-25 18:50:09.458563
22	Pelabuhan Sunda Kelapa	Ancol, Kec. Pademangan, Jakarta Utara, Daerah Khusus Ibukota Jakarta	-6.1188442	106.8122886	Jakarta Utara	2025-11-25 18:50:09.458563	2025-11-25 18:50:09.458563
23	Museum Seni Rupa dan Keramik	Jl. Pos Kota No.2 9, RT.9/RW.7, Pinangsia, Kec. Taman Sari, Kota Jakarta Barat, Daerah Khusus Ibukota Jakarta 11110	-6.1342491	106.8149060	Jakarta Barat	2025-11-25 18:50:09.458563	2025-11-25 18:50:09.458563
24	Museum Arkeologi Onrust	Pulau Onrust, Kec. Kepulauan Seribu Selatan, Kab. Administrasi Kepulauan Seribu, Daerah Khusus Ibukota Jakarta 14510	-6.0341906	106.7355295	Kepulauan Seribu	2025-11-25 18:50:09.458563	2025-11-25 18:50:09.458563
25	Pos Bloc	RRJM+4W5, Pasar Baru, Kecamatan Sawah Besar, Kota Jakarta Pusat, Daerah Khusus Ibukota Jakarta 10710	-6.1661029	106.8361441	Jakarta Pusat	2025-11-25 18:50:09.458563	2025-11-25 18:50:09.458563
26	Old Shanghai	Cakung Barat, Kec. Cakung, Kota Jakarta Timur, Daerah Khusus Ibukota Jakarta	-6.1645270	106.9245255	Jakarta Timur	2025-11-25 18:50:09.458563	2025-11-25 18:50:09.458563
27	Planetarium	Jalan Cikini Raya No.73, RT.8/RW.2, Cikini, Kec. Menteng, Kota Jakarta Pusat, Daerah Khusus Ibukota Jakarta 10330	-6.1901946	106.8389179	Jakarta Pusat	2025-11-25 18:50:09.458563	2025-11-25 18:50:09.458563
28	Museum Sejarah Jakarta	Taman Fatahillah No.1, Pinangsia, Kec. Taman Sari, Kota Jakarta Barat, Daerah Khusus Ibukota Jakarta 11110	-6.1349760	106.8142870	Jakarta Barat	2025-11-25 18:50:09.458563	2025-11-25 18:50:09.458563
29	Museum Tekstil	No 2-4, Jl. K.S. Tubun, Kota Bambu Selatan, Kec. Palmerah, Kota Jakarta Barat, Daerah Khusus Ibukota Jakarta 11420	-6.1880837	106.8107302	Jakarta Barat	2025-11-25 18:50:09.458563	2025-11-25 18:50:09.458563
\.


--
-- TOC entry 5132 (class 0 OID 17284)
-- Dependencies: 223
-- Data for Name: dim_price; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dim_price (price_id, objek_wisata_id, harga_tiket_dewasa, harga_tiket_anak, mata_uang, sumber_platform, tanggal_update, created_at) FROM stdin;
1	4	0	0	IDR	Survey Manual	2025-10-19	2025-12-02 10:46:04.450029
2	13	0	0	IDR	Survey Manual	2025-10-19	2025-12-02 10:46:04.450029
3	19	20000	10000	IDR	Website Resmi	2025-10-19	2025-12-02 10:46:04.450029
4	15	5000	3000	IDR	Website Museum Jakarta	2025-10-19	2025-12-02 10:46:04.450029
5	3	10000	5000	IDR	Website Museum Jakarta	2025-10-19	2025-12-02 10:46:04.450029
6	1	2000	1000	IDR	Website Museum Jakarta	2025-10-19	2025-12-02 10:46:04.450029
7	14	5000	2000	IDR	Website Museum Jakarta	2025-10-19	2025-12-02 10:46:04.450029
8	17	0	0	IDR	Website Museum Jakarta	2025-10-19	2025-12-02 10:46:04.450029
9	2	10000	5000	IDR	Website Museum Jakarta	2025-10-19	2025-12-02 10:46:04.450029
10	5	0	0	IDR	Website Museum Jakarta	2025-10-19	2025-12-02 10:46:04.450029
11	10	5000	3000	IDR	Website Museum Jakarta	2025-10-19	2025-12-02 10:46:04.450029
12	16	5000	2000	IDR	Website Museum Jakarta	2025-10-19	2025-12-02 10:46:04.450029
13	28	5000	3000	IDR	Website Museum Jakarta	2025-10-19	2025-12-02 10:46:04.450029
14	23	5000	3000	IDR	Website Museum Jakarta	2025-10-19	2025-12-02 10:46:04.450029
15	11	5000	2000	IDR	Website Museum Jakarta	2025-10-19	2025-12-02 10:46:04.450029
16	29	5000	3000	IDR	Website Museum Jakarta	2025-10-19	2025-12-02 10:46:04.450029
17	20	5000	3000	IDR	Website Museum Jakarta	2025-10-19	2025-12-02 10:46:04.450029
18	26	0	0	IDR	Survey Manual	2025-10-19	2025-12-02 10:46:04.450029
19	22	5000	3000	IDR	Survey Manual	2025-10-19	2025-12-02 10:46:04.450029
20	21	0	0	IDR	Survey Manual	2025-10-19	2025-12-02 10:46:04.450029
21	27	12000	7000	IDR	Website Resmi	2025-10-19	2025-12-02 10:46:04.450029
22	25	0	0	IDR	Survey Manual	2025-10-19	2025-12-02 10:46:04.450029
23	12	0	0	IDR	Survey Manual	2025-10-19	2025-12-02 10:46:04.450029
24	8	0	0	IDR	Survey Manual	2025-10-19	2025-12-02 10:46:04.450029
25	18	25000	25000	IDR	Website Resmi Pengelola	2025-10-19	2025-12-02 10:46:04.450029
26	6	0	0	IDR	Website Resmi Pengelola	2025-10-19	2025-12-02 10:46:04.450029
27	9	4000	3000	IDR	Website Resmi Pengelola	2025-10-19	2025-12-02 10:46:04.450029
28	7	15000	10000	IDR	Website Resmi Pengelola	2025-10-19	2025-12-02 10:46:04.450029
\.


--
-- TOC entry 5134 (class 0 OID 17294)
-- Dependencies: 225
-- Data for Name: dim_time; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dim_time (time_id, periode_data, bulan, tahun, kuartal, created_at) FROM stdin;
1	202506	6	2025	2	2025-11-25 18:50:09.437978
2	202502	2	2025	1	2025-11-25 18:50:09.437978
3	202503	3	2025	1	2025-11-25 18:50:09.437978
4	202505	5	2025	2	2025-11-25 18:50:09.437978
5	202504	4	2025	2	2025-11-25 18:50:09.437978
6	202507	7	2025	3	2025-11-25 18:50:09.437978
7	202508	8	2025	3	2025-11-25 18:50:09.437978
8	202501	1	2025	1	2025-11-25 18:50:09.437978
\.


--
-- TOC entry 5136 (class 0 OID 17303)
-- Dependencies: 227
-- Data for Name: dim_wisatawan; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dim_wisatawan (wisatawan_id, jenis_wisatawan, kode_jenis, created_at) FROM stdin;
1	Wisatawan Nusantara	NUS	2025-11-25 18:49:29.11001
2	Wisatawan Mancanegara	MAN	2025-11-25 18:49:29.11001
\.


--
-- TOC entry 5138 (class 0 OID 17309)
-- Dependencies: 229
-- Data for Name: fact_kunjungan; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fact_kunjungan (kunjungan_id, time_id, objek_wisata_id, wisatawan_id, price_id, jumlah_kunjungan, created_at, updated_at) FROM stdin;
343	1	23	2	\N	489	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
232	1	24	1	\N	1382	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
334	1	24	2	\N	4	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
52	1	25	1	\N	0	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
50	1	26	1	\N	49184	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
382	1	27	1	\N	0	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
95	1	27	2	\N	0	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
319	1	28	1	\N	18052	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
348	1	28	2	\N	1204	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
353	1	29	1	\N	1816	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
347	1	29	2	\N	98	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
337	2	1	1	\N	1032	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
68	2	1	2	\N	5	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
132	2	2	1	\N	59454	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
224	2	2	2	\N	5674	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
87	2	3	1	\N	1006	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
190	2	3	2	\N	6	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
189	2	4	1	\N	186237	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
69	2	4	2	\N	4086	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
34	2	5	1	\N	1994	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
272	2	5	2	\N	74	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
38	2	6	1	\N	25457	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
135	2	7	1	\N	291801	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
352	2	8	1	\N	673	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
158	2	9	1	\N	237150	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
302	2	9	2	\N	282	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
340	2	10	1	\N	330	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
344	2	10	2	\N	9	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
110	2	11	1	\N	1096	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
309	2	11	2	\N	2	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
365	2	12	1	\N	0	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
148	2	13	1	\N	16773	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
328	2	13	2	\N	1031	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
250	2	14	1	\N	5156	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
332	2	14	2	\N	18	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
53	2	15	1	\N	3256	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
263	2	15	2	\N	174	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
355	2	16	1	\N	1950	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
358	2	17	1	\N	269	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
29	1	1	1	\N	739	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
108	1	1	2	\N	27	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
30	1	2	1	\N	63798	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
260	1	2	2	\N	4279	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
308	1	3	1	\N	442	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
285	1	3	2	\N	3	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
393	1	4	1	\N	211916	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
96	1	4	2	\N	5705	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
80	1	5	1	\N	759	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
103	1	5	2	\N	43	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
63	1	6	1	\N	45582	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
333	1	7	1	\N	248533	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
321	1	8	1	\N	1105	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
11	1	9	1	\N	417950	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
264	1	9	2	\N	97	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
378	1	10	1	\N	378	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
300	1	10	2	\N	6	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
314	1	11	1	\N	754	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
280	1	11	2	\N	1	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
400	1	12	1	\N	88770	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
209	1	13	1	\N	41191	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
284	1	13	2	\N	1157	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
375	1	14	1	\N	2881	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
74	1	14	2	\N	19	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
162	1	15	1	\N	4447	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
213	1	15	2	\N	240	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
62	1	16	1	\N	2240	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
78	1	17	1	\N	290	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
351	1	17	2	\N	0	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
161	1	18	1	\N	776476	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
98	1	19	1	\N	483014	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
184	1	19	2	\N	5902	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
150	1	20	1	\N	36867	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
32	1	20	2	\N	1169	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
1	1	21	1	\N	26071	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
307	1	21	2	\N	7	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
210	1	22	1	\N	0	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
174	1	22	2	\N	0	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
195	1	23	1	\N	14871	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
257	2	17	2	\N	3	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
208	2	18	1	\N	934260	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
73	2	19	1	\N	324043	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
100	2	19	2	\N	4963	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
386	2	20	1	\N	35227	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
26	2	20	2	\N	1290	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
97	2	21	1	\N	26088	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
33	2	21	2	\N	21	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
130	2	22	1	\N	0	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
399	2	22	2	\N	0	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
370	2	23	1	\N	12878	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
141	2	23	2	\N	388	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
316	2	24	1	\N	398	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
304	2	24	2	\N	28	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
8	2	25	1	\N	39051	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
65	2	26	1	\N	58800	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
384	2	27	1	\N	0	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
244	2	27	2	\N	0	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
94	2	28	1	\N	28763	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
219	2	28	2	\N	1260	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
193	2	29	1	\N	3442	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
259	2	29	2	\N	135	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
146	3	1	1	\N	147	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
82	3	1	2	\N	8	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
85	3	2	1	\N	21990	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
357	3	2	2	\N	3828	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
226	3	3	1	\N	129	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
327	3	3	2	\N	2	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
10	3	4	1	\N	94469	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
92	3	4	2	\N	4466	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
335	3	5	1	\N	575	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
200	3	5	2	\N	62	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
269	3	6	1	\N	15393	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
152	3	7	1	\N	114553	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
367	3	8	1	\N	176	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
89	3	9	1	\N	37287	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
21	3	9	2	\N	118	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
236	3	10	1	\N	183	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
329	3	10	2	\N	12	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
350	3	11	1	\N	327	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
156	3	11	2	\N	1	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
101	3	12	1	\N	28182	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
58	3	13	1	\N	10719	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
229	3	13	2	\N	1229	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
295	3	14	1	\N	779	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
252	3	14	2	\N	19	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
254	3	15	1	\N	861	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
42	3	15	2	\N	221	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
387	3	16	1	\N	1420	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
199	3	17	1	\N	54	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
241	3	17	2	\N	0	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
75	3	18	1	\N	568580	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
390	3	19	1	\N	64083	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
310	3	19	2	\N	2655	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
230	3	20	1	\N	6236	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
129	3	20	2	\N	1065	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
56	3	21	1	\N	8210	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
266	3	21	2	\N	42	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
165	3	22	1	\N	0	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
128	3	22	2	\N	0	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
27	3	23	1	\N	2073	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
376	3	23	2	\N	216	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
255	3	24	1	\N	316	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
294	3	24	2	\N	2	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
361	3	25	1	\N	55088	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
356	3	26	1	\N	73223	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
289	3	27	1	\N	0	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
127	3	27	2	\N	0	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
28	3	28	1	\N	4515	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
105	3	28	2	\N	912	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
72	3	29	1	\N	791	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
114	3	29	2	\N	142	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
171	4	1	1	\N	1166	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
366	4	1	2	\N	6	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
81	4	2	1	\N	84273	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
31	4	2	2	\N	1143	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
341	4	3	1	\N	668	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
172	4	3	2	\N	3	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
59	4	4	1	\N	177784	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
12	4	4	2	\N	3360	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
317	4	5	1	\N	1863	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
233	4	5	2	\N	63	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
140	4	6	1	\N	21727	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
315	4	7	1	\N	258260	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
222	4	8	1	\N	990	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
267	4	9	1	\N	463797	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
265	4	9	2	\N	216	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
270	4	10	1	\N	477	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
385	4	10	2	\N	26	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
256	4	11	1	\N	1090	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
124	4	11	2	\N	1	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
99	4	12	1	\N	125091	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
157	4	13	1	\N	51667	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
183	4	13	2	\N	1431	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
170	4	14	1	\N	4404	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
46	4	14	2	\N	28	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
218	4	15	1	\N	3537	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
281	4	15	2	\N	354	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
71	4	16	1	\N	2020	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
64	4	17	1	\N	715	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
275	4	17	2	\N	1	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
131	4	18	1	\N	732626	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
35	4	19	1	\N	351648	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
298	4	19	2	\N	5313	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
20	4	20	1	\N	35328	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
181	4	20	2	\N	769	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
186	4	21	1	\N	37363	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
178	4	21	2	\N	16	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
383	4	22	1	\N	1900	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
299	4	22	2	\N	407	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
36	4	23	1	\N	11424	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
303	4	23	2	\N	464	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
206	4	24	1	\N	1308	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
90	4	24	2	\N	0	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
205	4	25	1	\N	45511	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
107	4	26	1	\N	0	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
115	4	27	1	\N	0	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
7	4	27	2	\N	0	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
296	4	28	1	\N	37267	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
204	4	28	2	\N	2393	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
9	4	29	1	\N	2333	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
145	4	29	2	\N	120	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
396	5	1	1	\N	592	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
57	5	1	2	\N	1	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
320	5	2	1	\N	85000	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
40	5	2	2	\N	4920	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
25	5	3	1	\N	287	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
143	5	3	2	\N	4	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
180	5	4	1	\N	741745	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
242	5	4	2	\N	18604	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
169	5	5	1	\N	1289	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
118	5	5	2	\N	61	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
381	5	6	1	\N	15360	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
77	5	7	1	\N	353954	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
339	5	8	1	\N	1940	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
51	5	9	1	\N	806612	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
18	5	9	2	\N	247	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
67	5	10	1	\N	424	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
360	5	10	2	\N	7	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
39	5	11	1	\N	769	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
111	5	11	2	\N	0	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
324	5	12	1	\N	0	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
192	5	13	1	\N	63936	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
196	5	13	2	\N	1217	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
144	5	14	1	\N	3922	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
164	5	14	2	\N	0	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
41	5	15	1	\N	4048	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
202	5	15	2	\N	320	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
188	5	16	1	\N	1630	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
261	5	17	1	\N	95	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
23	5	17	2	\N	3	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
119	5	18	1	\N	914254	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
216	5	19	1	\N	760112	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
22	5	19	2	\N	6753	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
48	5	20	1	\N	41637	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
83	5	20	2	\N	1364	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
283	5	21	1	\N	36170	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
318	5	21	2	\N	18	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
345	5	22	1	\N	0	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
311	5	22	2	\N	0	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
167	5	23	1	\N	14191	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
102	5	23	2	\N	400	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
133	5	24	1	\N	2007	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
231	5	24	2	\N	1	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
125	5	25	1	\N	34689	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
44	5	26	1	\N	97323	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
61	5	27	1	\N	0	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
5	5	27	2	\N	0	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
237	5	28	1	\N	37584	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
142	5	28	2	\N	1613	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
177	5	29	1	\N	2627	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
211	5	29	2	\N	72	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
79	6	1	1	\N	321	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
134	6	1	2	\N	19	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
371	6	2	1	\N	67125	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
246	6	2	2	\N	6722	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
372	6	3	1	\N	324	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
397	6	3	2	\N	16	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
243	6	4	1	\N	231247	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
147	6	4	2	\N	6523	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
66	6	5	1	\N	499	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
15	6	5	2	\N	72	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
228	6	6	1	\N	22439	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
249	6	7	1	\N	260449	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
122	6	8	1	\N	902	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
388	6	9	1	\N	468655	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
379	6	9	2	\N	87	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
163	6	10	1	\N	317	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
37	6	10	2	\N	26	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
373	6	11	1	\N	338	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
151	6	11	2	\N	7	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
227	6	12	1	\N	0	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
121	6	13	1	\N	37744	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
279	6	13	2	\N	1672	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
389	6	14	1	\N	3421	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
112	6	14	2	\N	0	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
330	6	15	1	\N	3099	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
70	6	15	2	\N	402	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
342	6	16	1	\N	2180	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
138	6	17	1	\N	65	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
278	6	17	2	\N	3	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
176	6	18	1	\N	793791	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
262	6	19	1	\N	483014	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
313	6	19	2	\N	5902	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
312	6	20	1	\N	32710	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
349	6	20	2	\N	1368	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
221	6	21	1	\N	22495	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
293	6	21	2	\N	18	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
6	6	22	1	\N	0	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
19	6	22	2	\N	0	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
248	6	23	1	\N	13957	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
4	6	23	2	\N	662	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
240	6	24	1	\N	2013	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
288	6	24	2	\N	0	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
245	6	25	1	\N	71137	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
326	6	26	1	\N	0	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
173	6	27	1	\N	0	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
258	6	27	2	\N	0	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
154	6	28	1	\N	37931	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
215	6	28	2	\N	3304	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
136	6	29	1	\N	1645	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
139	6	29	2	\N	300	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
76	7	1	1	\N	760	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
60	7	1	2	\N	16	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
225	7	2	1	\N	35353	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
197	7	2	2	\N	7098	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
109	7	3	1	\N	296	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
354	7	3	2	\N	12	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
207	7	4	1	\N	174862	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
203	7	4	2	\N	6545	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
191	7	5	1	\N	3771	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
47	7	5	2	\N	40	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
362	7	6	1	\N	0	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
380	7	7	1	\N	182893	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
271	7	8	1	\N	1310	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
84	7	9	1	\N	269418	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
253	7	9	2	\N	264	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
166	7	10	1	\N	233	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
120	7	10	2	\N	21	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
223	7	11	1	\N	798	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
198	7	11	2	\N	7	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
251	7	12	1	\N	0	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
185	8	6	1	\N	0	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
292	8	7	1	\N	351588	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
43	8	8	1	\N	1057	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
201	8	9	1	\N	563393	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
159	8	9	2	\N	277	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
13	8	10	1	\N	400	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
153	8	10	2	\N	17	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
338	8	11	1	\N	1787	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
214	8	11	2	\N	3	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
392	8	12	1	\N	74824	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
149	8	13	1	\N	24712	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
268	8	13	2	\N	1208	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
398	8	14	1	\N	3012	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
49	8	14	2	\N	26	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
2	8	15	1	\N	2186	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
331	8	15	2	\N	190	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
187	8	16	1	\N	2059	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
217	8	17	1	\N	106	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
297	8	17	2	\N	3	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
322	8	18	1	\N	760497	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
212	8	19	1	\N	5372	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
235	8	19	2	\N	360209	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
86	8	20	1	\N	23526	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
277	8	20	2	\N	559	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
287	8	21	1	\N	31806	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
363	8	21	2	\N	4	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
17	8	22	1	\N	0	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
106	8	22	2	\N	0	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
104	8	23	1	\N	15154	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
117	8	23	2	\N	368	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
395	8	24	1	\N	877	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
168	8	24	2	\N	7	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
3	8	25	1	\N	38007	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
374	8	26	1	\N	69748	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
291	8	27	1	\N	0	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
369	8	27	2	\N	0	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
88	8	28	1	\N	36478	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
346	7	13	1	\N	30953	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
16	7	13	2	\N	1826	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
377	7	14	1	\N	2788	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
336	7	14	2	\N	0	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
238	7	15	1	\N	4720	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
54	7	15	2	\N	548	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
116	7	16	1	\N	2685	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
45	7	17	1	\N	206	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
220	7	17	2	\N	0	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
391	7	18	1	\N	717446	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
234	7	19	1	\N	579917	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
282	7	19	2	\N	7849	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
137	7	20	1	\N	15216	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
286	7	20	2	\N	1631	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
91	7	21	1	\N	27228	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
323	7	21	2	\N	19	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
93	7	22	1	\N	0	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
364	7	22	2	\N	0	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
14	7	23	1	\N	7419	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
325	7	23	2	\N	842	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
113	7	24	1	\N	1908	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
24	7	24	2	\N	17	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
194	7	25	1	\N	39578	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
306	7	26	1	\N	50178	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
182	7	27	1	\N	0	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
394	7	27	2	\N	0	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
290	7	28	1	\N	19175	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
274	7	28	2	\N	2878	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
160	7	29	1	\N	2067	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
55	7	29	2	\N	267	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
368	8	1	1	\N	738	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
123	8	1	2	\N	5	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
276	8	2	1	\N	83451	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
359	8	2	2	\N	4170	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
175	8	3	1	\N	599	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
305	8	3	2	\N	2	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
179	8	4	1	\N	202461	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
273	8	4	2	\N	4602	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
247	8	5	1	\N	1720	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
155	8	5	2	\N	70	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
301	8	28	2	\N	1371	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
126	8	29	1	\N	2152	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
239	8	29	2	\N	78	2025-11-26 04:14:23.499892	2025-12-02 10:46:04.511316
\.


--
-- TOC entry 5140 (class 0 OID 17320)
-- Dependencies: 231
-- Data for Name: staging_harga_tiket_raw; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.staging_harga_tiket_raw (id, nama_objek_wisata, harga_dewasa, harga_anak, gratis, tanggal_update, raw_data, is_processed, created_at) FROM stdin;
\.


--
-- TOC entry 5142 (class 0 OID 17329)
-- Dependencies: 233
-- Data for Name: staging_kunjungan_raw; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.staging_kunjungan_raw (id, periode_data, nama_objek_wisata, alamat, longitude, latitude, jenis_wisatawan, jumlah_pengunjung, raw_data, is_processed, created_at) FROM stdin;
\.


--
-- TOC entry 5144 (class 0 OID 17338)
-- Dependencies: 235
-- Data for Name: user_journey_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_journey_log (journey_id, session_id, stage, "timestamp", duration_seconds, completed) FROM stdin;
1	a27b428e-04c9-4171-8279-3a9d3ece87ac	landing	2025-11-25 21:50:47.985154	\N	t
2	a27b428e-04c9-4171-8279-3a9d3ece87ac	view_kpis	2025-11-25 21:50:48.060675	\N	t
3	a27b428e-04c9-4171-8279-3a9d3ece87ac	analyze_charts	2025-11-25 21:50:48.131225	\N	t
4	a27b428e-04c9-4171-8279-3a9d3ece87ac	apply_filters	2025-11-25 21:52:06.125974	\N	t
5	a27b428e-04c9-4171-8279-3a9d3ece87ac	download_data	2025-11-25 21:58:13.184128	\N	t
6	07bd79b4-21e7-4040-a316-44690e8c95dc	landing	2025-11-25 21:58:19.192561	\N	t
7	07bd79b4-21e7-4040-a316-44690e8c95dc	view_kpis	2025-11-25 21:58:19.220541	\N	t
8	07bd79b4-21e7-4040-a316-44690e8c95dc	analyze_charts	2025-11-25 21:58:19.267066	\N	t
9	cf22800d-5ee4-48a5-9aca-02cf99cd4e0b	landing	2025-11-25 21:58:24.353166	\N	t
10	cf22800d-5ee4-48a5-9aca-02cf99cd4e0b	view_kpis	2025-11-25 21:58:24.384706	\N	t
11	cf22800d-5ee4-48a5-9aca-02cf99cd4e0b	analyze_charts	2025-11-25 21:58:24.437697	\N	t
12	b35a4ae0-9c69-4376-aeb1-a08a82c50a0b	landing	2025-11-25 21:59:46.809402	\N	t
13	b35a4ae0-9c69-4376-aeb1-a08a82c50a0b	view_kpis	2025-11-25 21:59:46.838396	\N	t
14	b35a4ae0-9c69-4376-aeb1-a08a82c50a0b	analyze_charts	2025-11-25 21:59:46.890406	\N	t
15	07bd6758-da30-49a4-a46c-ae0d105eff99	landing	2025-11-25 21:59:53.253238	\N	t
16	07bd6758-da30-49a4-a46c-ae0d105eff99	view_kpis	2025-11-25 21:59:53.282238	\N	t
17	07bd6758-da30-49a4-a46c-ae0d105eff99	analyze_charts	2025-11-25 21:59:53.344696	\N	t
18	54f80cfe-8a42-4b42-9f80-2628b0e10822	landing	2025-11-25 22:00:15.295889	\N	t
19	54f80cfe-8a42-4b42-9f80-2628b0e10822	view_kpis	2025-11-25 22:00:15.326919	\N	t
20	54f80cfe-8a42-4b42-9f80-2628b0e10822	analyze_charts	2025-11-25 22:00:15.375486	\N	t
21	fa7f1b55-5178-4ef1-8cee-60fb89041b09	landing	2025-11-25 22:01:08.620362	\N	t
22	fa7f1b55-5178-4ef1-8cee-60fb89041b09	view_kpis	2025-11-25 22:01:08.665484	\N	t
23	fa7f1b55-5178-4ef1-8cee-60fb89041b09	analyze_charts	2025-11-25 22:01:08.723475	\N	t
24	fa7f1b55-5178-4ef1-8cee-60fb89041b09	apply_filters	2025-11-25 22:01:35.867478	\N	t
25	6d99802a-25e2-4136-b983-c194ccce5178	landing	2025-11-25 22:01:50.621937	\N	t
26	6d99802a-25e2-4136-b983-c194ccce5178	view_kpis	2025-11-25 22:01:50.649502	\N	t
27	6d99802a-25e2-4136-b983-c194ccce5178	analyze_charts	2025-11-25 22:01:50.703504	\N	t
28	b0db5e26-0d50-4eed-879a-5c714e744444	landing	2025-11-25 22:03:52.973915	\N	t
29	b0db5e26-0d50-4eed-879a-5c714e744444	view_kpis	2025-11-25 22:03:53.00047	\N	t
30	b0db5e26-0d50-4eed-879a-5c714e744444	analyze_charts	2025-11-25 22:03:53.05446	\N	t
31	05662ac3-569c-48b1-9b18-597b8ca64240	landing	2025-11-25 22:06:07.961238	\N	t
32	05662ac3-569c-48b1-9b18-597b8ca64240	view_kpis	2025-11-25 22:06:07.996252	\N	t
33	05662ac3-569c-48b1-9b18-597b8ca64240	analyze_charts	2025-11-25 22:06:08.070801	\N	t
34	bd642457-0e39-4907-a860-5ebf82bfa5c0	landing	2025-11-25 22:06:51.425888	\N	t
35	bd642457-0e39-4907-a860-5ebf82bfa5c0	view_kpis	2025-11-25 22:06:51.541424	\N	t
36	bd642457-0e39-4907-a860-5ebf82bfa5c0	analyze_charts	2025-11-25 22:06:51.740537	\N	t
37	459c6aa9-99da-4f87-a4a6-7983843fb6dc	landing	2025-11-25 22:21:08.854325	\N	t
38	459c6aa9-99da-4f87-a4a6-7983843fb6dc	view_kpis	2025-11-25 22:21:08.922238	\N	t
39	459c6aa9-99da-4f87-a4a6-7983843fb6dc	analyze_charts	2025-11-25 22:21:08.959238	\N	t
40	459c6aa9-99da-4f87-a4a6-7983843fb6dc	apply_filters	2025-11-25 22:21:21.500038	\N	t
41	25bad5bf-5380-46fa-b3e0-6bc10192c3b1	landing	2025-11-25 22:21:49.127219	\N	t
42	25bad5bf-5380-46fa-b3e0-6bc10192c3b1	view_kpis	2025-11-25 22:21:49.151224	\N	t
43	25bad5bf-5380-46fa-b3e0-6bc10192c3b1	analyze_charts	2025-11-25 22:21:49.178462	\N	t
44	25bad5bf-5380-46fa-b3e0-6bc10192c3b1	download_data	2025-11-25 22:22:17.244296	\N	t
45	25bad5bf-5380-46fa-b3e0-6bc10192c3b1	apply_filters	2025-11-25 22:22:44.679494	\N	t
46	3e5bfb74-65f4-446e-a954-ef47465b2d52	landing	2025-11-25 22:28:13.318827	\N	t
47	3e5bfb74-65f4-446e-a954-ef47465b2d52	view_kpis	2025-11-25 22:28:13.350347	\N	t
48	3e5bfb74-65f4-446e-a954-ef47465b2d52	analyze_charts	2025-11-25 22:28:13.382346	\N	t
49	7ec80fe8-941f-47d0-b4ae-d43e1b63f0d7	landing	2025-11-25 22:29:42.119987	\N	t
50	7ec80fe8-941f-47d0-b4ae-d43e1b63f0d7	view_kpis	2025-11-25 22:29:42.162014	\N	t
51	7ec80fe8-941f-47d0-b4ae-d43e1b63f0d7	analyze_charts	2025-11-25 22:29:42.240557	\N	t
52	45069881-b7f6-4344-ba36-65a9ddf48fe9	landing	2025-11-25 22:30:00.297627	\N	t
53	45069881-b7f6-4344-ba36-65a9ddf48fe9	view_kpis	2025-11-25 22:30:00.332161	\N	t
54	45069881-b7f6-4344-ba36-65a9ddf48fe9	analyze_charts	2025-11-25 22:30:00.40217	\N	t
55	1a516357-b9f4-4233-a767-d35d86e44aa9	landing	2025-11-25 22:31:10.386756	\N	t
56	1a516357-b9f4-4233-a767-d35d86e44aa9	view_kpis	2025-11-25 22:31:10.447283	\N	t
57	1a516357-b9f4-4233-a767-d35d86e44aa9	analyze_charts	2025-11-25 22:31:10.524287	\N	t
58	1a516357-b9f4-4233-a767-d35d86e44aa9	download_data	2025-11-25 22:31:11.012902	\N	t
59	dfface28-549c-4a01-93dd-500fd0a077a9	landing	2025-11-25 22:31:43.200263	\N	t
60	dfface28-549c-4a01-93dd-500fd0a077a9	view_kpis	2025-11-25 22:31:43.225263	\N	t
61	dfface28-549c-4a01-93dd-500fd0a077a9	analyze_charts	2025-11-25 22:31:43.276587	\N	t
62	dfface28-549c-4a01-93dd-500fd0a077a9	download_data	2025-11-25 22:31:51.267621	\N	t
63	01941dee-8db4-4f28-902f-c92dc2efa457	landing	2025-11-25 22:31:54.435476	\N	t
64	01941dee-8db4-4f28-902f-c92dc2efa457	view_kpis	2025-11-25 22:31:54.46046	\N	t
65	01941dee-8db4-4f28-902f-c92dc2efa457	analyze_charts	2025-11-25 22:31:54.522024	\N	t
66	45069881-b7f6-4344-ba36-65a9ddf48fe9	apply_filters	2025-11-25 22:32:36.598506	\N	t
67	d500f22e-c8c5-40fb-94d8-cf3661d711e3	landing	2025-11-25 22:32:56.795435	\N	t
68	d500f22e-c8c5-40fb-94d8-cf3661d711e3	view_kpis	2025-11-25 22:32:56.826477	\N	t
69	d500f22e-c8c5-40fb-94d8-cf3661d711e3	analyze_charts	2025-11-25 22:32:56.89348	\N	t
70	d500f22e-c8c5-40fb-94d8-cf3661d711e3	apply_filters	2025-11-25 22:33:08.071011	\N	t
71	d4b63ea4-8624-4f1a-bc36-ab0d4937e85d	landing	2025-11-25 22:33:21.267231	\N	t
72	d4b63ea4-8624-4f1a-bc36-ab0d4937e85d	view_kpis	2025-11-25 22:33:21.29023	\N	t
73	d4b63ea4-8624-4f1a-bc36-ab0d4937e85d	analyze_charts	2025-11-25 22:33:21.341272	\N	t
74	490bc1ae-f4b5-463b-8392-79da7a170aac	landing	2025-11-25 22:34:02.416822	\N	t
75	490bc1ae-f4b5-463b-8392-79da7a170aac	view_kpis	2025-11-25 22:34:02.442823	\N	t
76	490bc1ae-f4b5-463b-8392-79da7a170aac	analyze_charts	2025-11-25 22:34:02.503839	\N	t
77	490bc1ae-f4b5-463b-8392-79da7a170aac	apply_filters	2025-11-25 22:34:22.099204	\N	t
78	84e0b91f-f4db-415e-985f-6f76cc31b000	landing	2025-11-25 22:35:00.555453	\N	t
79	84e0b91f-f4db-415e-985f-6f76cc31b000	view_kpis	2025-11-25 22:35:00.590458	\N	t
80	84e0b91f-f4db-415e-985f-6f76cc31b000	analyze_charts	2025-11-25 22:35:00.639981	\N	t
81	84e0b91f-f4db-415e-985f-6f76cc31b000	apply_filters	2025-11-25 22:35:06.284747	\N	t
82	dfb158f1-bf95-49eb-b195-34f0cfa6cd9e	landing	2025-11-25 22:37:10.484921	\N	t
83	dfb158f1-bf95-49eb-b195-34f0cfa6cd9e	view_kpis	2025-11-25 22:37:10.554936	\N	t
84	dfb158f1-bf95-49eb-b195-34f0cfa6cd9e	analyze_charts	2025-11-25 22:37:10.631464	\N	t
85	dfb158f1-bf95-49eb-b195-34f0cfa6cd9e	apply_filters	2025-11-25 22:37:14.833565	\N	t
86	3c8bfe38-3b2c-402d-bc6a-776985ab8226	landing	2025-11-25 22:42:45.360672	\N	t
87	3c8bfe38-3b2c-402d-bc6a-776985ab8226	view_kpis	2025-11-25 22:42:45.385671	\N	t
88	3c8bfe38-3b2c-402d-bc6a-776985ab8226	analyze_charts	2025-11-25 22:42:45.414683	\N	t
89	fd42b57a-bebf-4e10-85c5-c0656fc4be69	landing	2025-11-25 22:44:58.142772	\N	t
90	fd42b57a-bebf-4e10-85c5-c0656fc4be69	view_kpis	2025-11-25 22:44:58.179814	\N	t
91	fd42b57a-bebf-4e10-85c5-c0656fc4be69	analyze_charts	2025-11-25 22:44:58.255326	\N	t
92	fd42b57a-bebf-4e10-85c5-c0656fc4be69	apply_filters	2025-11-25 22:45:07.000082	\N	t
93	fd42b57a-bebf-4e10-85c5-c0656fc4be69	apply_filters	2025-11-25 22:45:14.496927	\N	t
94	fd42b57a-bebf-4e10-85c5-c0656fc4be69	apply_filters	2025-11-25 22:45:17.147399	\N	t
95	fd42b57a-bebf-4e10-85c5-c0656fc4be69	apply_filters	2025-11-25 22:45:19.613046	\N	t
96	fd42b57a-bebf-4e10-85c5-c0656fc4be69	apply_filters	2025-11-25 22:45:20.916357	\N	t
97	d232db0d-bac5-4924-8e66-810cf650394d	landing	2025-11-25 22:45:22.669822	\N	t
98	d232db0d-bac5-4924-8e66-810cf650394d	view_kpis	2025-11-25 22:45:22.688818	\N	t
99	d232db0d-bac5-4924-8e66-810cf650394d	analyze_charts	2025-11-25 22:45:22.732383	\N	t
100	d232db0d-bac5-4924-8e66-810cf650394d	apply_filters	2025-11-25 22:45:28.686871	\N	t
101	d232db0d-bac5-4924-8e66-810cf650394d	apply_filters	2025-11-25 22:45:31.037921	\N	t
102	d232db0d-bac5-4924-8e66-810cf650394d	apply_filters	2025-11-25 22:45:36.258057	\N	t
103	d232db0d-bac5-4924-8e66-810cf650394d	apply_filters	2025-11-25 22:45:40.309007	\N	t
104	d232db0d-bac5-4924-8e66-810cf650394d	apply_filters	2025-11-25 22:45:42.16578	\N	t
105	d232db0d-bac5-4924-8e66-810cf650394d	apply_filters	2025-11-25 22:45:43.098005	\N	t
106	d232db0d-bac5-4924-8e66-810cf650394d	apply_filters	2025-11-25 22:45:43.831202	\N	t
107	d232db0d-bac5-4924-8e66-810cf650394d	apply_filters	2025-11-25 22:45:45.865559	\N	t
108	d232db0d-bac5-4924-8e66-810cf650394d	apply_filters	2025-11-25 22:45:46.640681	\N	t
109	d232db0d-bac5-4924-8e66-810cf650394d	apply_filters	2025-11-25 22:45:48.024369	\N	t
110	d232db0d-bac5-4924-8e66-810cf650394d	apply_filters	2025-11-25 22:45:49.79084	\N	t
111	672b224b-754c-4409-9ad0-88739520f7fd	landing	2025-11-25 22:45:54.037037	\N	t
112	672b224b-754c-4409-9ad0-88739520f7fd	view_kpis	2025-11-25 22:45:54.061037	\N	t
113	672b224b-754c-4409-9ad0-88739520f7fd	analyze_charts	2025-11-25 22:45:54.104203	\N	t
114	672b224b-754c-4409-9ad0-88739520f7fd	apply_filters	2025-11-25 22:45:57.911618	\N	t
115	672b224b-754c-4409-9ad0-88739520f7fd	apply_filters	2025-11-25 22:46:03.182351	\N	t
116	5ed07629-1275-4dfe-a51c-49fb0a5eef92	landing	2025-11-25 22:46:33.638414	\N	t
117	5ed07629-1275-4dfe-a51c-49fb0a5eef92	view_kpis	2025-11-25 22:46:33.678945	\N	t
118	5ed07629-1275-4dfe-a51c-49fb0a5eef92	analyze_charts	2025-11-25 22:46:33.751995	\N	t
119	5ed07629-1275-4dfe-a51c-49fb0a5eef92	apply_filters	2025-11-25 22:46:37.1158	\N	t
120	5ed07629-1275-4dfe-a51c-49fb0a5eef92	apply_filters	2025-11-25 22:46:38.737277	\N	t
121	5ed07629-1275-4dfe-a51c-49fb0a5eef92	apply_filters	2025-11-25 22:46:40.907739	\N	t
122	5ed07629-1275-4dfe-a51c-49fb0a5eef92	apply_filters	2025-11-25 22:46:46.119588	\N	t
123	6a5a7c66-0b0d-4490-bf76-7956e2be0dd9	landing	2025-11-25 22:52:23.966678	\N	t
124	6a5a7c66-0b0d-4490-bf76-7956e2be0dd9	view_kpis	2025-11-25 22:52:24.014676	\N	t
125	6a5a7c66-0b0d-4490-bf76-7956e2be0dd9	analyze_charts	2025-11-25 22:52:24.068254	\N	t
126	6a5a7c66-0b0d-4490-bf76-7956e2be0dd9	apply_filters	2025-11-25 22:52:28.289271	\N	t
127	6a5a7c66-0b0d-4490-bf76-7956e2be0dd9	apply_filters	2025-11-25 22:52:31.347449	\N	t
128	6a5a7c66-0b0d-4490-bf76-7956e2be0dd9	apply_filters	2025-11-25 22:52:36.164731	\N	t
129	6a5a7c66-0b0d-4490-bf76-7956e2be0dd9	apply_filters	2025-11-25 22:52:38.249174	\N	t
130	6a5a7c66-0b0d-4490-bf76-7956e2be0dd9	apply_filters	2025-11-25 22:52:39.294751	\N	t
131	6a5a7c66-0b0d-4490-bf76-7956e2be0dd9	apply_filters	2025-11-25 22:52:40.595082	\N	t
132	6a5a7c66-0b0d-4490-bf76-7956e2be0dd9	apply_filters	2025-11-25 22:52:41.324278	\N	t
133	bdf35fc2-aa86-473c-b9d0-76928d8d2b26	landing	2025-11-25 22:52:44.154816	\N	t
134	bdf35fc2-aa86-473c-b9d0-76928d8d2b26	view_kpis	2025-11-25 22:52:44.183841	\N	t
135	bdf35fc2-aa86-473c-b9d0-76928d8d2b26	analyze_charts	2025-11-25 22:52:44.222045	\N	t
136	bdf35fc2-aa86-473c-b9d0-76928d8d2b26	apply_filters	2025-11-25 22:52:50.482169	\N	t
137	bdf35fc2-aa86-473c-b9d0-76928d8d2b26	apply_filters	2025-11-25 22:52:51.637042	\N	t
138	bdf35fc2-aa86-473c-b9d0-76928d8d2b26	apply_filters	2025-11-25 22:52:52.97564	\N	t
139	bdf35fc2-aa86-473c-b9d0-76928d8d2b26	apply_filters	2025-11-25 22:52:54.917804	\N	t
140	bdf35fc2-aa86-473c-b9d0-76928d8d2b26	apply_filters	2025-11-25 22:52:57.138028	\N	t
141	bdf35fc2-aa86-473c-b9d0-76928d8d2b26	apply_filters	2025-11-25 22:52:57.856329	\N	t
142	bdf35fc2-aa86-473c-b9d0-76928d8d2b26	apply_filters	2025-11-25 22:52:59.471494	\N	t
143	bdf35fc2-aa86-473c-b9d0-76928d8d2b26	apply_filters	2025-11-25 22:53:08.4901	\N	t
144	21cd727c-cffb-4e98-a34c-b5bcaa6baf30	landing	2025-11-25 22:57:29.29674	\N	t
145	21cd727c-cffb-4e98-a34c-b5bcaa6baf30	view_kpis	2025-11-25 22:57:29.32474	\N	t
146	21cd727c-cffb-4e98-a34c-b5bcaa6baf30	analyze_charts	2025-11-25 22:57:29.371723	\N	t
147	21cd727c-cffb-4e98-a34c-b5bcaa6baf30	apply_filters	2025-11-25 22:57:43.178675	\N	t
148	21cd727c-cffb-4e98-a34c-b5bcaa6baf30	apply_filters	2025-11-25 22:57:46.085145	\N	t
149	21cd727c-cffb-4e98-a34c-b5bcaa6baf30	apply_filters	2025-11-25 22:57:48.273825	\N	t
150	21cd727c-cffb-4e98-a34c-b5bcaa6baf30	apply_filters	2025-11-25 22:57:51.582343	\N	t
151	21cd727c-cffb-4e98-a34c-b5bcaa6baf30	apply_filters	2025-11-25 22:57:52.932733	\N	t
152	21cd727c-cffb-4e98-a34c-b5bcaa6baf30	apply_filters	2025-11-25 22:57:53.449941	\N	t
153	21cd727c-cffb-4e98-a34c-b5bcaa6baf30	apply_filters	2025-11-25 22:57:53.956063	\N	t
154	21cd727c-cffb-4e98-a34c-b5bcaa6baf30	apply_filters	2025-11-25 22:57:54.843051	\N	t
155	51931684-d6f8-413f-8075-79c17ef2f4b4	landing	2025-11-25 22:57:56.349534	\N	t
156	51931684-d6f8-413f-8075-79c17ef2f4b4	view_kpis	2025-11-25 22:57:56.376541	\N	t
157	51931684-d6f8-413f-8075-79c17ef2f4b4	analyze_charts	2025-11-25 22:57:56.433594	\N	t
158	51931684-d6f8-413f-8075-79c17ef2f4b4	apply_filters	2025-11-25 22:58:01.632104	\N	t
159	51931684-d6f8-413f-8075-79c17ef2f4b4	apply_filters	2025-11-25 22:58:03.205881	\N	t
160	51931684-d6f8-413f-8075-79c17ef2f4b4	apply_filters	2025-11-25 22:58:05.741846	\N	t
161	51931684-d6f8-413f-8075-79c17ef2f4b4	apply_filters	2025-11-25 22:58:08.21718	\N	t
162	51931684-d6f8-413f-8075-79c17ef2f4b4	download_data	2025-11-25 22:58:39.353918	\N	t
163	c1a4261f-929e-48af-95c5-dbb1331de456	landing	2025-11-25 22:58:47.907257	\N	t
164	c1a4261f-929e-48af-95c5-dbb1331de456	view_kpis	2025-11-25 22:58:47.989184	\N	t
165	c1a4261f-929e-48af-95c5-dbb1331de456	analyze_charts	2025-11-25 22:58:48.122714	\N	t
166	c1a4261f-929e-48af-95c5-dbb1331de456	download_data	2025-11-25 22:58:59.209698	\N	t
167	cf415d4f-2e19-440f-afe3-4886d57aa1f1	landing	2025-11-25 22:59:06.270971	\N	t
168	cf415d4f-2e19-440f-afe3-4886d57aa1f1	view_kpis	2025-11-25 22:59:06.28997	\N	t
169	cf415d4f-2e19-440f-afe3-4886d57aa1f1	analyze_charts	2025-11-25 22:59:06.332977	\N	t
170	25629465-4e08-4f0d-9235-38b370805dfc	landing	2025-11-25 22:59:15.91624	\N	t
171	25629465-4e08-4f0d-9235-38b370805dfc	view_kpis	2025-11-25 22:59:15.935238	\N	t
172	25629465-4e08-4f0d-9235-38b370805dfc	analyze_charts	2025-11-25 22:59:15.986793	\N	t
173	25629465-4e08-4f0d-9235-38b370805dfc	download_data	2025-11-25 22:59:39.338054	\N	t
174	25629465-4e08-4f0d-9235-38b370805dfc	download_data	2025-11-25 22:59:43.097381	\N	t
175	25629465-4e08-4f0d-9235-38b370805dfc	apply_filters	2025-11-25 22:59:44.560963	\N	t
176	25629465-4e08-4f0d-9235-38b370805dfc	apply_filters	2025-11-25 22:59:46.606003	\N	t
177	a3050833-695c-469a-864f-82be7145ee01	landing	2025-11-25 23:00:15.143126	\N	t
178	a3050833-695c-469a-864f-82be7145ee01	view_kpis	2025-11-25 23:00:15.175123	\N	t
179	a3050833-695c-469a-864f-82be7145ee01	analyze_charts	2025-11-25 23:00:15.227173	\N	t
180	e28d49af-3b3a-4691-9e08-9bb60dc1b9e3	landing	2025-11-25 23:01:05.037346	\N	t
181	e28d49af-3b3a-4691-9e08-9bb60dc1b9e3	view_kpis	2025-11-25 23:01:05.061346	\N	t
182	e28d49af-3b3a-4691-9e08-9bb60dc1b9e3	analyze_charts	2025-11-25 23:01:05.105868	\N	t
183	e28d49af-3b3a-4691-9e08-9bb60dc1b9e3	apply_filters	2025-11-25 23:01:46.721956	\N	t
184	a67cad4c-9ffc-47c9-9ca4-7fb2b8e7ccc9	landing	2025-11-25 23:05:47.421611	\N	t
185	a67cad4c-9ffc-47c9-9ca4-7fb2b8e7ccc9	view_kpis	2025-11-25 23:05:47.485163	\N	t
186	a67cad4c-9ffc-47c9-9ca4-7fb2b8e7ccc9	analyze_charts	2025-11-25 23:05:47.544148	\N	t
187	a67cad4c-9ffc-47c9-9ca4-7fb2b8e7ccc9	apply_filters	2025-11-25 23:06:01.572054	\N	t
188	a67cad4c-9ffc-47c9-9ca4-7fb2b8e7ccc9	apply_filters	2025-11-25 23:06:07.693584	\N	t
189	a67cad4c-9ffc-47c9-9ca4-7fb2b8e7ccc9	apply_filters	2025-11-25 23:06:14.774966	\N	t
190	a67cad4c-9ffc-47c9-9ca4-7fb2b8e7ccc9	apply_filters	2025-11-25 23:06:42.068017	\N	t
191	a67cad4c-9ffc-47c9-9ca4-7fb2b8e7ccc9	apply_filters	2025-11-25 23:06:45.08665	\N	t
192	a67cad4c-9ffc-47c9-9ca4-7fb2b8e7ccc9	apply_filters	2025-11-25 23:06:47.479264	\N	t
193	a67cad4c-9ffc-47c9-9ca4-7fb2b8e7ccc9	apply_filters	2025-11-25 23:06:51.859095	\N	t
194	a67cad4c-9ffc-47c9-9ca4-7fb2b8e7ccc9	apply_filters	2025-11-25 23:06:55.61092	\N	t
195	a67cad4c-9ffc-47c9-9ca4-7fb2b8e7ccc9	apply_filters	2025-11-25 23:06:59.016972	\N	t
196	a67cad4c-9ffc-47c9-9ca4-7fb2b8e7ccc9	apply_filters	2025-11-25 23:09:38.106583	\N	t
197	a67cad4c-9ffc-47c9-9ca4-7fb2b8e7ccc9	apply_filters	2025-11-25 23:09:44.571418	\N	t
198	a67cad4c-9ffc-47c9-9ca4-7fb2b8e7ccc9	apply_filters	2025-11-25 23:09:46.450769	\N	t
199	59fc3512-14c9-42ff-a5af-bc7d647f2ca7	landing	2025-11-25 23:13:28.614648	\N	t
200	59fc3512-14c9-42ff-a5af-bc7d647f2ca7	view_kpis	2025-11-25 23:13:28.642647	\N	t
201	59fc3512-14c9-42ff-a5af-bc7d647f2ca7	analyze_charts	2025-11-25 23:13:28.694764	\N	t
202	c45d3d79-55ba-4ffa-b48c-8bf594fee42b	landing	2025-11-25 23:13:50.043708	\N	t
203	c45d3d79-55ba-4ffa-b48c-8bf594fee42b	view_kpis	2025-11-25 23:13:50.073712	\N	t
204	c45d3d79-55ba-4ffa-b48c-8bf594fee42b	analyze_charts	2025-11-25 23:13:50.126709	\N	t
205	c45d3d79-55ba-4ffa-b48c-8bf594fee42b	apply_filters	2025-11-25 23:13:55.779601	\N	t
206	c45d3d79-55ba-4ffa-b48c-8bf594fee42b	apply_filters	2025-11-25 23:13:58.297922	\N	t
207	c45d3d79-55ba-4ffa-b48c-8bf594fee42b	apply_filters	2025-11-25 23:14:01.124912	\N	t
208	f1dd29cf-2322-4dbb-ae52-89c992e1be71	landing	2025-11-26 03:07:20.514326	\N	t
209	f1dd29cf-2322-4dbb-ae52-89c992e1be71	view_kpis	2025-11-26 03:07:20.681209	\N	t
210	f1dd29cf-2322-4dbb-ae52-89c992e1be71	analyze_charts	2025-11-26 03:07:20.880885	\N	t
211	f1dd29cf-2322-4dbb-ae52-89c992e1be71	apply_filters	2025-11-26 03:07:44.003371	\N	t
212	f1dd29cf-2322-4dbb-ae52-89c992e1be71	apply_filters	2025-11-26 03:07:53.861665	\N	t
213	f1dd29cf-2322-4dbb-ae52-89c992e1be71	apply_filters	2025-11-26 03:07:55.962353	\N	t
214	f1dd29cf-2322-4dbb-ae52-89c992e1be71	apply_filters	2025-11-26 03:07:56.944226	\N	t
215	f1dd29cf-2322-4dbb-ae52-89c992e1be71	apply_filters	2025-11-26 03:07:58.945775	\N	t
216	f1dd29cf-2322-4dbb-ae52-89c992e1be71	apply_filters	2025-11-26 03:08:01.022064	\N	t
217	1f8d4edf-5bdb-4879-8983-7aeba415413e	landing	2025-11-26 04:25:26.080802	\N	t
218	1f8d4edf-5bdb-4879-8983-7aeba415413e	view_kpis	2025-11-26 04:25:26.178168	\N	t
219	1f8d4edf-5bdb-4879-8983-7aeba415413e	analyze_charts	2025-11-26 04:25:26.295386	\N	t
220	1f8d4edf-5bdb-4879-8983-7aeba415413e	apply_filters	2025-11-26 04:26:00.569262	\N	t
221	1f8d4edf-5bdb-4879-8983-7aeba415413e	apply_filters	2025-11-26 04:28:19.78665	\N	t
222	1f8d4edf-5bdb-4879-8983-7aeba415413e	apply_filters	2025-11-26 04:28:21.642226	\N	t
223	1f8d4edf-5bdb-4879-8983-7aeba415413e	apply_filters	2025-11-26 04:28:52.140754	\N	t
224	1f8d4edf-5bdb-4879-8983-7aeba415413e	apply_filters	2025-11-26 06:23:25.830725	\N	t
225	0cf99808-e90d-47db-bad0-9753a066b78c	landing	2025-11-26 07:55:54.073342	\N	t
226	0cf99808-e90d-47db-bad0-9753a066b78c	view_kpis	2025-11-26 07:55:54.130111	\N	t
227	0cf99808-e90d-47db-bad0-9753a066b78c	analyze_charts	2025-11-26 07:55:54.174132	\N	t
228	2712291e-0391-469e-a2ef-f3ac866f345a	landing	2025-11-26 07:58:00.555436	\N	t
229	2712291e-0391-469e-a2ef-f3ac866f345a	view_kpis	2025-11-26 07:58:00.588595	\N	t
230	2712291e-0391-469e-a2ef-f3ac866f345a	analyze_charts	2025-11-26 07:58:00.641582	\N	t
231	f891b3d8-3ab8-4eba-940f-281288036ebb	landing	2025-11-26 07:59:37.579373	\N	t
232	f891b3d8-3ab8-4eba-940f-281288036ebb	view_kpis	2025-11-26 07:59:37.622435	\N	t
233	f891b3d8-3ab8-4eba-940f-281288036ebb	analyze_charts	2025-11-26 07:59:37.688459	\N	t
234	9b7b7ba8-fb5b-433d-9960-c68d6556cba8	landing	2025-11-26 08:01:52.007378	\N	t
235	9b7b7ba8-fb5b-433d-9960-c68d6556cba8	view_kpis	2025-11-26 08:01:52.043476	\N	t
236	9b7b7ba8-fb5b-433d-9960-c68d6556cba8	analyze_charts	2025-11-26 08:01:52.094488	\N	t
237	9b7b7ba8-fb5b-433d-9960-c68d6556cba8	apply_filters	2025-11-26 08:03:03.461494	\N	t
238	9b7b7ba8-fb5b-433d-9960-c68d6556cba8	apply_filters	2025-11-26 08:03:06.293996	\N	t
239	9b7b7ba8-fb5b-433d-9960-c68d6556cba8	apply_filters	2025-11-26 08:03:08.631911	\N	t
240	9b7b7ba8-fb5b-433d-9960-c68d6556cba8	apply_filters	2025-11-26 08:03:11.758693	\N	t
241	90da418e-63c3-4525-8958-dbb31c85ca91	landing	2025-11-26 08:08:16.162537	\N	t
242	90da418e-63c3-4525-8958-dbb31c85ca91	view_kpis	2025-11-26 08:08:16.193579	\N	t
243	90da418e-63c3-4525-8958-dbb31c85ca91	analyze_charts	2025-11-26 08:08:16.236131	\N	t
244	001cccf2-5956-419f-9f5a-dc078e75e5b0	landing	2025-11-26 08:09:35.89706	\N	t
245	001cccf2-5956-419f-9f5a-dc078e75e5b0	view_kpis	2025-11-26 08:09:35.923059	\N	t
246	001cccf2-5956-419f-9f5a-dc078e75e5b0	analyze_charts	2025-11-26 08:09:35.978616	\N	t
247	75fc45a3-34a9-4650-bcad-7c538f5c6086	landing	2025-11-26 08:13:55.77841	\N	t
248	75fc45a3-34a9-4650-bcad-7c538f5c6086	view_kpis	2025-11-26 08:13:55.821926	\N	t
249	75fc45a3-34a9-4650-bcad-7c538f5c6086	analyze_charts	2025-11-26 08:13:55.86993	\N	t
250	75fc45a3-34a9-4650-bcad-7c538f5c6086	apply_filters	2025-11-26 08:14:57.283597	\N	t
251	75fc45a3-34a9-4650-bcad-7c538f5c6086	apply_filters	2025-11-26 08:15:01.36163	\N	t
252	9cb0dea0-8259-433d-b717-bcad0feabe5a	landing	2025-11-26 13:57:06.648208	\N	t
253	9cb0dea0-8259-433d-b717-bcad0feabe5a	view_kpis	2025-11-26 13:57:06.688199	\N	t
254	9cb0dea0-8259-433d-b717-bcad0feabe5a	analyze_charts	2025-11-26 13:57:06.740204	\N	t
255	9cb0dea0-8259-433d-b717-bcad0feabe5a	apply_filters	2025-11-26 13:57:28.784918	\N	t
256	9cb0dea0-8259-433d-b717-bcad0feabe5a	apply_filters	2025-11-26 13:57:34.266713	\N	t
257	9cb0dea0-8259-433d-b717-bcad0feabe5a	apply_filters	2025-11-26 13:58:55.280481	\N	t
258	9cb0dea0-8259-433d-b717-bcad0feabe5a	apply_filters	2025-11-26 13:58:59.802172	\N	t
259	9cb0dea0-8259-433d-b717-bcad0feabe5a	apply_filters	2025-11-26 14:00:24.370701	\N	t
260	9cb0dea0-8259-433d-b717-bcad0feabe5a	apply_filters	2025-11-26 14:00:37.896577	\N	t
261	ebdf9cff-2fa2-481e-87b3-06d2b29614d3	landing	2025-11-26 14:03:35.194805	\N	t
262	ebdf9cff-2fa2-481e-87b3-06d2b29614d3	view_kpis	2025-11-26 14:03:35.290547	\N	t
263	ebdf9cff-2fa2-481e-87b3-06d2b29614d3	analyze_charts	2025-11-26 14:03:35.472551	\N	t
264	ebdf9cff-2fa2-481e-87b3-06d2b29614d3	apply_filters	2025-11-26 14:04:50.033682	\N	t
265	ebdf9cff-2fa2-481e-87b3-06d2b29614d3	apply_filters	2025-11-26 14:05:03.877934	\N	t
266	ebdf9cff-2fa2-481e-87b3-06d2b29614d3	apply_filters	2025-11-26 14:05:32.770486	\N	t
267	ebdf9cff-2fa2-481e-87b3-06d2b29614d3	apply_filters	2025-11-26 14:05:35.643019	\N	t
268	7c90068b-9d26-4afc-b92f-1ec48ad3dbbb	landing	2025-11-26 14:06:48.772887	\N	t
269	7c90068b-9d26-4afc-b92f-1ec48ad3dbbb	view_kpis	2025-11-26 14:06:48.80088	\N	t
270	7c90068b-9d26-4afc-b92f-1ec48ad3dbbb	analyze_charts	2025-11-26 14:06:48.852889	\N	t
271	953df163-1ba8-4cc1-8f6b-186c81f3b10b	landing	2025-11-26 14:24:59.636544	\N	t
272	953df163-1ba8-4cc1-8f6b-186c81f3b10b	view_kpis	2025-11-26 14:24:59.687723	\N	t
273	953df163-1ba8-4cc1-8f6b-186c81f3b10b	analyze_charts	2025-11-26 14:24:59.747318	\N	t
274	953df163-1ba8-4cc1-8f6b-186c81f3b10b	apply_filters	2025-11-26 14:25:35.602591	\N	t
275	e4ebbec8-7355-4b32-ada8-7c19074713cc	landing	2025-11-26 14:25:47.308446	\N	t
276	e4ebbec8-7355-4b32-ada8-7c19074713cc	view_kpis	2025-11-26 14:25:47.335875	\N	t
277	e4ebbec8-7355-4b32-ada8-7c19074713cc	analyze_charts	2025-11-26 14:25:47.392299	\N	t
278	e4ebbec8-7355-4b32-ada8-7c19074713cc	download_data	2025-11-26 14:25:56.764206	\N	t
279	144384b2-24b0-431c-8899-6e6149291ca4	landing	2025-11-26 14:25:59.649412	\N	t
280	144384b2-24b0-431c-8899-6e6149291ca4	view_kpis	2025-11-26 14:25:59.671705	\N	t
281	144384b2-24b0-431c-8899-6e6149291ca4	analyze_charts	2025-11-26 14:25:59.740559	\N	t
282	f0f4d6a8-3605-4ff0-8154-7ed12e6f0efb	landing	2025-11-26 14:30:41.009105	\N	t
283	f0f4d6a8-3605-4ff0-8154-7ed12e6f0efb	view_kpis	2025-11-26 14:30:41.037176	\N	t
284	f0f4d6a8-3605-4ff0-8154-7ed12e6f0efb	analyze_charts	2025-11-26 14:30:41.083336	\N	t
285	f0f4d6a8-3605-4ff0-8154-7ed12e6f0efb	download_data	2025-11-26 14:30:41.877729	\N	t
286	f0f4d6a8-3605-4ff0-8154-7ed12e6f0efb	download_data	2025-11-26 14:30:57.77287	\N	t
287	5658a3b6-ae93-44d4-a81e-dfb15257a572	landing	2025-11-26 14:31:05.663991	\N	t
288	5658a3b6-ae93-44d4-a81e-dfb15257a572	view_kpis	2025-11-26 14:31:05.686646	\N	t
289	5658a3b6-ae93-44d4-a81e-dfb15257a572	analyze_charts	2025-11-26 14:31:05.741779	\N	t
290	5658a3b6-ae93-44d4-a81e-dfb15257a572	download_data	2025-11-26 14:31:06.461543	\N	t
291	5658a3b6-ae93-44d4-a81e-dfb15257a572	download_data	2025-11-26 14:31:14.116653	\N	t
292	5658a3b6-ae93-44d4-a81e-dfb15257a572	download_data	2025-11-26 14:31:14.321161	\N	t
293	5658a3b6-ae93-44d4-a81e-dfb15257a572	download_data	2025-11-26 14:31:23.786016	\N	t
294	e62ee2a6-3dc9-4a05-bc33-5b81a488ef1f	landing	2025-11-26 14:31:26.757747	\N	t
295	e62ee2a6-3dc9-4a05-bc33-5b81a488ef1f	view_kpis	2025-11-26 14:31:26.796642	\N	t
296	e62ee2a6-3dc9-4a05-bc33-5b81a488ef1f	analyze_charts	2025-11-26 14:31:26.844873	\N	t
297	e62ee2a6-3dc9-4a05-bc33-5b81a488ef1f	download_data	2025-11-26 14:31:27.354777	\N	t
298	e62ee2a6-3dc9-4a05-bc33-5b81a488ef1f	download_data	2025-11-26 14:31:33.992953	\N	t
299	240fd587-b85f-4b1a-8d00-7ffd44bd246e	landing	2025-11-26 15:05:22.382989	\N	t
300	240fd587-b85f-4b1a-8d00-7ffd44bd246e	view_kpis	2025-11-26 15:05:22.429837	\N	t
301	240fd587-b85f-4b1a-8d00-7ffd44bd246e	analyze_charts	2025-11-26 15:05:22.479184	\N	t
302	240fd587-b85f-4b1a-8d00-7ffd44bd246e	download_data	2025-11-26 15:05:23.011493	\N	t
303	fa414813-f230-4b8b-bbcf-a7631d430721	landing	2025-11-26 15:15:23.141078	\N	t
304	fa414813-f230-4b8b-bbcf-a7631d430721	view_kpis	2025-11-26 15:15:23.217367	\N	t
305	fa414813-f230-4b8b-bbcf-a7631d430721	analyze_charts	2025-11-26 15:15:23.287735	\N	t
306	fa414813-f230-4b8b-bbcf-a7631d430721	download_data	2025-11-26 15:15:23.871265	\N	t
307	4910394d-7c6c-4f80-a9de-7741d19118d6	landing	2025-11-26 15:15:28.263565	\N	t
308	4910394d-7c6c-4f80-a9de-7741d19118d6	view_kpis	2025-11-26 15:15:28.28981	\N	t
309	4910394d-7c6c-4f80-a9de-7741d19118d6	analyze_charts	2025-11-26 15:15:28.342321	\N	t
310	4910394d-7c6c-4f80-a9de-7741d19118d6	download_data	2025-11-26 15:15:28.878085	\N	t
311	160ad7e8-ef8a-4c64-972e-42eb6af9d140	landing	2025-11-26 15:15:31.193219	\N	t
312	160ad7e8-ef8a-4c64-972e-42eb6af9d140	view_kpis	2025-11-26 15:15:31.226532	\N	t
313	160ad7e8-ef8a-4c64-972e-42eb6af9d140	analyze_charts	2025-11-26 15:15:31.309901	\N	t
314	160ad7e8-ef8a-4c64-972e-42eb6af9d140	download_data	2025-11-26 15:15:31.913665	\N	t
315	b3ea3bfa-0dba-41c2-bdf5-e14d679cb6fb	landing	2025-11-27 22:25:35.693069	\N	t
316	b3ea3bfa-0dba-41c2-bdf5-e14d679cb6fb	view_kpis	2025-11-27 22:25:35.838056	\N	t
317	b3ea3bfa-0dba-41c2-bdf5-e14d679cb6fb	analyze_charts	2025-11-27 22:25:35.97809	\N	t
318	b3ea3bfa-0dba-41c2-bdf5-e14d679cb6fb	download_data	2025-11-27 22:25:37.167048	\N	t
319	cf6ae4f3-e9b1-4771-abf7-872d8268a56f	landing	2025-11-28 06:57:11.255138	\N	t
320	cf6ae4f3-e9b1-4771-abf7-872d8268a56f	view_kpis	2025-11-28 06:57:11.353253	\N	t
321	cf6ae4f3-e9b1-4771-abf7-872d8268a56f	analyze_charts	2025-11-28 06:57:11.475306	\N	t
322	cf6ae4f3-e9b1-4771-abf7-872d8268a56f	download_data	2025-11-28 06:57:12.954532	\N	t
323	07944def-bb1d-4f0c-b343-aca02ff03e85	landing	2025-12-01 01:35:57.393266	\N	t
324	07944def-bb1d-4f0c-b343-aca02ff03e85	view_kpis	2025-12-01 01:35:57.533076	\N	t
325	07944def-bb1d-4f0c-b343-aca02ff03e85	analyze_charts	2025-12-01 01:35:57.640617	\N	t
326	07944def-bb1d-4f0c-b343-aca02ff03e85	download_data	2025-12-01 01:35:59.343118	\N	t
327	07944def-bb1d-4f0c-b343-aca02ff03e85	apply_filters	2025-12-01 02:36:18.875355	\N	t
328	07944def-bb1d-4f0c-b343-aca02ff03e85	download_data	2025-12-01 02:36:19.657903	\N	t
329	642597ea-f606-4e8e-992d-8e86ec015854	landing	2025-12-01 02:58:47.479535	\N	t
330	642597ea-f606-4e8e-992d-8e86ec015854	view_kpis	2025-12-01 02:58:47.594113	\N	t
331	642597ea-f606-4e8e-992d-8e86ec015854	analyze_charts	2025-12-01 02:58:47.644358	\N	t
332	642597ea-f606-4e8e-992d-8e86ec015854	download_data	2025-12-01 02:58:48.14541	\N	t
333	ad2279e3-212f-4c3b-bfd2-eb9de6209a28	landing	2025-12-01 03:02:35.682047	\N	t
334	ad2279e3-212f-4c3b-bfd2-eb9de6209a28	view_kpis	2025-12-01 03:02:35.70458	\N	t
335	ad2279e3-212f-4c3b-bfd2-eb9de6209a28	analyze_charts	2025-12-01 03:02:35.742153	\N	t
336	ad2279e3-212f-4c3b-bfd2-eb9de6209a28	download_data	2025-12-01 03:02:36.271743	\N	t
337	09d3a87f-7b7d-44c9-bda1-91140191a74f	landing	2025-12-01 03:02:41.437618	\N	t
338	09d3a87f-7b7d-44c9-bda1-91140191a74f	view_kpis	2025-12-01 03:02:41.464748	\N	t
339	09d3a87f-7b7d-44c9-bda1-91140191a74f	analyze_charts	2025-12-01 03:02:41.518068	\N	t
340	09d3a87f-7b7d-44c9-bda1-91140191a74f	download_data	2025-12-01 03:02:42.109545	\N	t
341	89a7a344-f348-446a-a59a-a5dab46ff85c	landing	2025-12-01 03:04:53.909919	\N	t
342	89a7a344-f348-446a-a59a-a5dab46ff85c	view_kpis	2025-12-01 03:04:53.937863	\N	t
343	89a7a344-f348-446a-a59a-a5dab46ff85c	analyze_charts	2025-12-01 03:04:53.983247	\N	t
344	89a7a344-f348-446a-a59a-a5dab46ff85c	download_data	2025-12-01 03:04:54.618153	\N	t
345	90bfc721-c76c-4d0e-9db3-991ef11fdc39	landing	2025-12-01 03:05:17.124666	\N	t
346	90bfc721-c76c-4d0e-9db3-991ef11fdc39	view_kpis	2025-12-01 03:05:17.165174	\N	t
347	90bfc721-c76c-4d0e-9db3-991ef11fdc39	analyze_charts	2025-12-01 03:05:17.226302	\N	t
348	90bfc721-c76c-4d0e-9db3-991ef11fdc39	download_data	2025-12-01 03:05:18.049826	\N	t
349	7ee23c88-1585-4448-9131-2ecd7c4778ff	landing	2025-12-01 03:11:01.471586	\N	t
350	7ee23c88-1585-4448-9131-2ecd7c4778ff	view_kpis	2025-12-01 03:11:01.520586	\N	t
351	7ee23c88-1585-4448-9131-2ecd7c4778ff	analyze_charts	2025-12-01 03:11:01.567137	\N	t
352	7ee23c88-1585-4448-9131-2ecd7c4778ff	download_data	2025-12-01 03:11:02.076985	\N	t
353	0e762549-eedb-46e7-b88c-37998e07945a	landing	2025-12-01 03:11:31.787543	\N	t
354	0e762549-eedb-46e7-b88c-37998e07945a	view_kpis	2025-12-01 03:11:31.807537	\N	t
355	0e762549-eedb-46e7-b88c-37998e07945a	analyze_charts	2025-12-01 03:11:31.854079	\N	t
356	0e762549-eedb-46e7-b88c-37998e07945a	download_data	2025-12-01 03:11:32.309743	\N	t
357	14e923df-5604-485f-97a8-61456a68bb61	landing	2025-12-01 03:11:59.764084	\N	t
358	14e923df-5604-485f-97a8-61456a68bb61	view_kpis	2025-12-01 03:11:59.787086	\N	t
359	14e923df-5604-485f-97a8-61456a68bb61	analyze_charts	2025-12-01 03:11:59.832622	\N	t
360	14e923df-5604-485f-97a8-61456a68bb61	download_data	2025-12-01 03:12:00.303731	\N	t
361	2518ef08-0b8d-4af7-af28-cd43363221e8	landing	2025-12-01 03:12:20.784527	\N	t
362	2518ef08-0b8d-4af7-af28-cd43363221e8	view_kpis	2025-12-01 03:12:20.818521	\N	t
363	2518ef08-0b8d-4af7-af28-cd43363221e8	analyze_charts	2025-12-01 03:12:20.914108	\N	t
364	2518ef08-0b8d-4af7-af28-cd43363221e8	download_data	2025-12-01 03:12:21.438158	\N	t
365	8293cc48-8a9a-40d6-84b5-078eb9868a1a	landing	2025-12-01 20:10:23.336885	\N	t
366	8293cc48-8a9a-40d6-84b5-078eb9868a1a	view_kpis	2025-12-01 20:10:23.429467	\N	t
367	8293cc48-8a9a-40d6-84b5-078eb9868a1a	analyze_charts	2025-12-01 20:10:23.515086	\N	t
368	8293cc48-8a9a-40d6-84b5-078eb9868a1a	download_data	2025-12-01 20:10:25.108242	\N	t
369	8f69a9d8-a1bc-4bf6-b065-66a4ccd36dd1	landing	2025-12-01 21:05:29.501581	\N	t
370	8f69a9d8-a1bc-4bf6-b065-66a4ccd36dd1	view_kpis	2025-12-01 21:05:29.553882	\N	t
371	8f69a9d8-a1bc-4bf6-b065-66a4ccd36dd1	analyze_charts	2025-12-01 21:05:29.651884	\N	t
372	8f69a9d8-a1bc-4bf6-b065-66a4ccd36dd1	download_data	2025-12-01 21:05:30.472158	\N	t
373	8f69a9d8-a1bc-4bf6-b065-66a4ccd36dd1	apply_filters	2025-12-01 21:05:39.257342	\N	t
374	8f69a9d8-a1bc-4bf6-b065-66a4ccd36dd1	download_data	2025-12-01 21:05:40.144339	\N	t
375	8f69a9d8-a1bc-4bf6-b065-66a4ccd36dd1	apply_filters	2025-12-01 21:05:43.030691	\N	t
376	8f69a9d8-a1bc-4bf6-b065-66a4ccd36dd1	download_data	2025-12-01 21:05:43.967693	\N	t
377	fbea683a-483a-4902-8ece-7c533db5d1b0	landing	2025-12-01 21:11:47.190567	\N	t
378	fbea683a-483a-4902-8ece-7c533db5d1b0	view_kpis	2025-12-01 21:11:47.238566	\N	t
379	fbea683a-483a-4902-8ece-7c533db5d1b0	analyze_charts	2025-12-01 21:11:47.3168	\N	t
380	fbea683a-483a-4902-8ece-7c533db5d1b0	download_data	2025-12-01 21:11:48.198878	\N	t
381	4ecba3d0-f914-41c0-a398-0f021fabed0d	landing	2025-12-01 21:12:38.699539	\N	t
382	4ecba3d0-f914-41c0-a398-0f021fabed0d	view_kpis	2025-12-01 21:12:38.766528	\N	t
383	4ecba3d0-f914-41c0-a398-0f021fabed0d	analyze_charts	2025-12-01 21:12:38.841523	\N	t
384	4ecba3d0-f914-41c0-a398-0f021fabed0d	download_data	2025-12-01 21:12:39.688969	\N	t
385	47e61d98-7ea4-474e-b4ce-4c182e66885d	landing	2025-12-01 21:13:25.941822	\N	t
386	47e61d98-7ea4-474e-b4ce-4c182e66885d	view_kpis	2025-12-01 21:13:25.971829	\N	t
387	47e61d98-7ea4-474e-b4ce-4c182e66885d	analyze_charts	2025-12-01 21:13:26.048823	\N	t
388	47e61d98-7ea4-474e-b4ce-4c182e66885d	download_data	2025-12-01 21:13:26.887031	\N	t
389	db2d05bd-b196-46f2-a036-6f05882404ee	landing	2025-12-01 21:13:42.700678	\N	t
390	db2d05bd-b196-46f2-a036-6f05882404ee	view_kpis	2025-12-01 21:13:42.730679	\N	t
391	db2d05bd-b196-46f2-a036-6f05882404ee	analyze_charts	2025-12-01 21:13:42.795677	\N	t
392	db2d05bd-b196-46f2-a036-6f05882404ee	download_data	2025-12-01 21:13:43.680972	\N	t
393	db2d05bd-b196-46f2-a036-6f05882404ee	apply_filters	2025-12-01 22:19:32.876475	\N	t
394	db2d05bd-b196-46f2-a036-6f05882404ee	download_data	2025-12-01 22:19:34.685581	\N	t
395	db2d05bd-b196-46f2-a036-6f05882404ee	apply_filters	2025-12-01 22:19:36.368338	\N	t
396	db2d05bd-b196-46f2-a036-6f05882404ee	download_data	2025-12-01 22:19:37.19224	\N	t
397	748095dc-bca7-47af-993d-5441a4960de6	landing	2025-12-01 22:32:36.38297	\N	t
398	748095dc-bca7-47af-993d-5441a4960de6	view_kpis	2025-12-01 22:32:36.44797	\N	t
399	748095dc-bca7-47af-993d-5441a4960de6	analyze_charts	2025-12-01 22:32:36.592975	\N	t
400	748095dc-bca7-47af-993d-5441a4960de6	apply_filters	2025-12-01 22:32:48.970699	\N	t
401	748095dc-bca7-47af-993d-5441a4960de6	apply_filters	2025-12-01 22:32:53.414691	\N	t
402	1781a831-9e12-44bc-8b54-08bf5902ca63	landing	2025-12-01 22:33:08.606264	\N	t
403	1781a831-9e12-44bc-8b54-08bf5902ca63	view_kpis	2025-12-01 22:33:08.648202	\N	t
404	1781a831-9e12-44bc-8b54-08bf5902ca63	analyze_charts	2025-12-01 22:33:08.700221	\N	t
405	1781a831-9e12-44bc-8b54-08bf5902ca63	download_data	2025-12-01 22:33:09.292218	\N	t
406	1781a831-9e12-44bc-8b54-08bf5902ca63	apply_filters	2025-12-01 22:33:16.137922	\N	t
407	1781a831-9e12-44bc-8b54-08bf5902ca63	download_data	2025-12-01 22:33:16.942965	\N	t
408	1781a831-9e12-44bc-8b54-08bf5902ca63	apply_filters	2025-12-01 22:33:17.662797	\N	t
409	1781a831-9e12-44bc-8b54-08bf5902ca63	download_data	2025-12-01 22:33:18.508142	\N	t
410	1781a831-9e12-44bc-8b54-08bf5902ca63	download_data	2025-12-01 22:33:32.147324	\N	t
411	2b7d7982-a099-4a28-9ec6-56805aa838b3	landing	2025-12-01 22:37:51.032565	\N	t
412	2b7d7982-a099-4a28-9ec6-56805aa838b3	view_kpis	2025-12-01 22:37:51.055569	\N	t
413	2b7d7982-a099-4a28-9ec6-56805aa838b3	analyze_charts	2025-12-01 22:37:51.098567	\N	t
414	2b7d7982-a099-4a28-9ec6-56805aa838b3	download_data	2025-12-01 22:37:51.671626	\N	t
415	2b7d7982-a099-4a28-9ec6-56805aa838b3	apply_filters	2025-12-01 23:21:03.204149	\N	t
416	2b7d7982-a099-4a28-9ec6-56805aa838b3	download_data	2025-12-01 23:21:03.73824	\N	t
417	2b7d7982-a099-4a28-9ec6-56805aa838b3	apply_filters	2025-12-01 23:21:06.883242	\N	t
418	2b7d7982-a099-4a28-9ec6-56805aa838b3	download_data	2025-12-01 23:21:07.591366	\N	t
419	2b7d7982-a099-4a28-9ec6-56805aa838b3	apply_filters	2025-12-01 23:21:15.151325	\N	t
420	2b7d7982-a099-4a28-9ec6-56805aa838b3	download_data	2025-12-01 23:21:15.683403	\N	t
421	2b7d7982-a099-4a28-9ec6-56805aa838b3	apply_filters	2025-12-01 23:21:17.730924	\N	t
422	2b7d7982-a099-4a28-9ec6-56805aa838b3	download_data	2025-12-01 23:21:18.24401	\N	t
423	2b7d7982-a099-4a28-9ec6-56805aa838b3	apply_filters	2025-12-01 23:21:26.596125	\N	t
424	2b7d7982-a099-4a28-9ec6-56805aa838b3	apply_filters	2025-12-01 23:21:27.3883	\N	t
425	2b7d7982-a099-4a28-9ec6-56805aa838b3	download_data	2025-12-01 23:21:27.911906	\N	t
426	2b7d7982-a099-4a28-9ec6-56805aa838b3	apply_filters	2025-12-01 23:21:28.436995	\N	t
427	2b7d7982-a099-4a28-9ec6-56805aa838b3	download_data	2025-12-01 23:21:29.071086	\N	t
428	2b7d7982-a099-4a28-9ec6-56805aa838b3	apply_filters	2025-12-01 23:21:29.755851	\N	t
429	2b7d7982-a099-4a28-9ec6-56805aa838b3	download_data	2025-12-01 23:21:30.514207	\N	t
430	2b7d7982-a099-4a28-9ec6-56805aa838b3	download_data	2025-12-01 23:26:40.349802	\N	t
431	6c8849a6-f305-4ee3-8ff3-dcd963012436	landing	2025-12-01 23:48:33.131055	\N	t
432	6c8849a6-f305-4ee3-8ff3-dcd963012436	view_kpis	2025-12-01 23:48:33.238073	\N	t
433	6c8849a6-f305-4ee3-8ff3-dcd963012436	analyze_charts	2025-12-01 23:48:33.301073	\N	t
434	175624e7-0881-484c-9e39-80324b836fb7	landing	2025-12-01 23:50:48.135413	\N	t
435	175624e7-0881-484c-9e39-80324b836fb7	view_kpis	2025-12-01 23:50:48.169416	\N	t
436	175624e7-0881-484c-9e39-80324b836fb7	analyze_charts	2025-12-01 23:50:48.230421	\N	t
437	175624e7-0881-484c-9e39-80324b836fb7	download_data	2025-12-01 23:50:48.875478	\N	t
438	f04d04a3-93ab-4b18-9ddd-3bac5f034120	landing	2025-12-01 23:56:55.781023	\N	t
439	f04d04a3-93ab-4b18-9ddd-3bac5f034120	view_kpis	2025-12-01 23:56:55.815235	\N	t
440	f04d04a3-93ab-4b18-9ddd-3bac5f034120	analyze_charts	2025-12-01 23:56:55.860475	\N	t
441	f04d04a3-93ab-4b18-9ddd-3bac5f034120	download_data	2025-12-01 23:56:56.547974	\N	t
442	54682119-41ff-4c10-b9fa-1f43d7ee327d	landing	2025-12-02 00:01:36.614676	\N	t
443	54682119-41ff-4c10-b9fa-1f43d7ee327d	view_kpis	2025-12-02 00:01:36.656408	\N	t
444	54682119-41ff-4c10-b9fa-1f43d7ee327d	analyze_charts	2025-12-02 00:01:36.707795	\N	t
445	54682119-41ff-4c10-b9fa-1f43d7ee327d	download_data	2025-12-02 00:01:37.284847	\N	t
446	878db2c8-6c06-4508-ac69-53c71fed8319	landing	2025-12-02 00:07:21.23071	\N	t
447	878db2c8-6c06-4508-ac69-53c71fed8319	view_kpis	2025-12-02 00:07:21.250712	\N	t
448	878db2c8-6c06-4508-ac69-53c71fed8319	analyze_charts	2025-12-02 00:07:21.290715	\N	t
449	878db2c8-6c06-4508-ac69-53c71fed8319	download_data	2025-12-02 00:07:21.792745	\N	t
450	1f41c0cf-5336-4b5c-9367-c277826108d2	landing	2025-12-02 00:13:32.34157	\N	t
451	1f41c0cf-5336-4b5c-9367-c277826108d2	view_kpis	2025-12-02 00:13:32.401579	\N	t
452	1f41c0cf-5336-4b5c-9367-c277826108d2	analyze_charts	2025-12-02 00:13:32.457573	\N	t
453	1f41c0cf-5336-4b5c-9367-c277826108d2	download_data	2025-12-02 00:13:33.008609	\N	t
454	4869d041-69de-40a2-8d0c-f89b327964bf	landing	2025-12-02 00:14:50.460889	\N	t
455	4869d041-69de-40a2-8d0c-f89b327964bf	view_kpis	2025-12-02 00:14:50.49089	\N	t
456	4869d041-69de-40a2-8d0c-f89b327964bf	analyze_charts	2025-12-02 00:14:50.559892	\N	t
457	4869d041-69de-40a2-8d0c-f89b327964bf	download_data	2025-12-02 00:14:51.101476	\N	t
458	c4ef630f-ac87-4dfb-b63b-20775489d046	landing	2025-12-02 00:15:20.333124	\N	t
459	c4ef630f-ac87-4dfb-b63b-20775489d046	view_kpis	2025-12-02 00:15:20.354128	\N	t
460	c4ef630f-ac87-4dfb-b63b-20775489d046	analyze_charts	2025-12-02 00:15:20.40915	\N	t
461	c4ef630f-ac87-4dfb-b63b-20775489d046	download_data	2025-12-02 00:15:21.043629	\N	t
462	0a6c587a-22fa-47dc-8e01-2822d7c041e8	landing	2025-12-02 00:18:43.092653	\N	t
463	0a6c587a-22fa-47dc-8e01-2822d7c041e8	view_kpis	2025-12-02 00:18:43.117677	\N	t
464	0a6c587a-22fa-47dc-8e01-2822d7c041e8	analyze_charts	2025-12-02 00:18:43.172666	\N	t
465	0a6c587a-22fa-47dc-8e01-2822d7c041e8	download_data	2025-12-02 00:18:43.7227	\N	t
466	fae49036-d1f2-4a76-a164-003ea6b4bbaf	landing	2025-12-02 00:19:41.396485	\N	t
467	fae49036-d1f2-4a76-a164-003ea6b4bbaf	view_kpis	2025-12-02 00:19:41.413503	\N	t
468	fae49036-d1f2-4a76-a164-003ea6b4bbaf	analyze_charts	2025-12-02 00:19:41.468493	\N	t
469	fae49036-d1f2-4a76-a164-003ea6b4bbaf	download_data	2025-12-02 00:19:42.142549	\N	t
470	714929df-6aa9-41ae-af2b-0848c1dcbe9a	landing	2025-12-02 00:20:13.667245	\N	t
471	714929df-6aa9-41ae-af2b-0848c1dcbe9a	view_kpis	2025-12-02 00:20:13.699242	\N	t
472	714929df-6aa9-41ae-af2b-0848c1dcbe9a	analyze_charts	2025-12-02 00:20:13.759262	\N	t
473	714929df-6aa9-41ae-af2b-0848c1dcbe9a	download_data	2025-12-02 00:20:14.524302	\N	t
474	51bfd1e0-4976-4e74-b56a-2504dfe5ed9e	landing	2025-12-02 00:21:46.671253	\N	t
475	51bfd1e0-4976-4e74-b56a-2504dfe5ed9e	view_kpis	2025-12-02 00:21:46.697251	\N	t
476	51bfd1e0-4976-4e74-b56a-2504dfe5ed9e	analyze_charts	2025-12-02 00:21:46.743265	\N	t
477	51bfd1e0-4976-4e74-b56a-2504dfe5ed9e	download_data	2025-12-02 00:21:47.4083	\N	t
478	1e51b506-d328-4314-97a1-22bf8947cae4	landing	2025-12-02 00:26:07.813342	\N	t
479	1e51b506-d328-4314-97a1-22bf8947cae4	view_kpis	2025-12-02 00:26:07.861344	\N	t
480	1e51b506-d328-4314-97a1-22bf8947cae4	analyze_charts	2025-12-02 00:26:07.912347	\N	t
481	1e51b506-d328-4314-97a1-22bf8947cae4	download_data	2025-12-02 00:26:08.460206	\N	t
482	a99924d6-ce04-4ea9-9898-69bcbf34ea03	landing	2025-12-02 00:26:59.489066	\N	t
483	a99924d6-ce04-4ea9-9898-69bcbf34ea03	view_kpis	2025-12-02 00:26:59.511067	\N	t
484	a99924d6-ce04-4ea9-9898-69bcbf34ea03	analyze_charts	2025-12-02 00:26:59.575083	\N	t
485	a99924d6-ce04-4ea9-9898-69bcbf34ea03	download_data	2025-12-02 00:27:00.148107	\N	t
486	95abaa3a-e8e2-48bf-9610-1ce9d46d6db3	landing	2025-12-02 00:29:25.871913	\N	t
487	95abaa3a-e8e2-48bf-9610-1ce9d46d6db3	view_kpis	2025-12-02 00:29:25.905928	\N	t
488	95abaa3a-e8e2-48bf-9610-1ce9d46d6db3	analyze_charts	2025-12-02 00:29:25.954918	\N	t
489	95abaa3a-e8e2-48bf-9610-1ce9d46d6db3	download_data	2025-12-02 00:29:26.573945	\N	t
490	5aacee66-50c8-46c8-8d9a-f1be60722f87	landing	2025-12-02 00:30:56.46674	\N	t
491	5aacee66-50c8-46c8-8d9a-f1be60722f87	view_kpis	2025-12-02 00:30:56.494731	\N	t
492	5aacee66-50c8-46c8-8d9a-f1be60722f87	analyze_charts	2025-12-02 00:30:56.538998	\N	t
493	5aacee66-50c8-46c8-8d9a-f1be60722f87	download_data	2025-12-02 00:30:57.145022	\N	t
494	706821bb-5e5c-47a8-aec6-8a591b658845	landing	2025-12-02 00:31:15.794223	\N	t
495	706821bb-5e5c-47a8-aec6-8a591b658845	view_kpis	2025-12-02 00:31:15.818224	\N	t
496	706821bb-5e5c-47a8-aec6-8a591b658845	analyze_charts	2025-12-02 00:31:15.874227	\N	t
497	706821bb-5e5c-47a8-aec6-8a591b658845	download_data	2025-12-02 00:31:16.476252	\N	t
498	e41982b6-96ab-4519-9685-ae056ca93052	landing	2025-12-02 00:31:41.60247	\N	t
499	e41982b6-96ab-4519-9685-ae056ca93052	view_kpis	2025-12-02 00:31:41.634456	\N	t
500	e41982b6-96ab-4519-9685-ae056ca93052	analyze_charts	2025-12-02 00:31:41.684457	\N	t
501	e41982b6-96ab-4519-9685-ae056ca93052	download_data	2025-12-02 00:31:42.190971	\N	t
502	de57a20d-d9cf-47fc-8ca6-79d79ad8dd8b	landing	2025-12-02 00:32:18.940622	\N	t
503	de57a20d-d9cf-47fc-8ca6-79d79ad8dd8b	view_kpis	2025-12-02 00:32:18.968626	\N	t
504	de57a20d-d9cf-47fc-8ca6-79d79ad8dd8b	analyze_charts	2025-12-02 00:32:19.011046	\N	t
505	de57a20d-d9cf-47fc-8ca6-79d79ad8dd8b	download_data	2025-12-02 00:32:19.537493	\N	t
506	08d35c9d-1ef5-4b80-984f-4024bf1850cf	landing	2025-12-02 00:33:17.514333	\N	t
507	08d35c9d-1ef5-4b80-984f-4024bf1850cf	view_kpis	2025-12-02 00:33:17.56432	\N	t
508	08d35c9d-1ef5-4b80-984f-4024bf1850cf	analyze_charts	2025-12-02 00:33:17.649216	\N	t
509	08d35c9d-1ef5-4b80-984f-4024bf1850cf	download_data	2025-12-02 00:33:18.214254	\N	t
510	d2444149-b80c-4f12-8e3e-7bb4a79d5d16	landing	2025-12-02 00:33:30.621576	\N	t
511	d2444149-b80c-4f12-8e3e-7bb4a79d5d16	view_kpis	2025-12-02 00:33:30.649136	\N	t
512	d2444149-b80c-4f12-8e3e-7bb4a79d5d16	analyze_charts	2025-12-02 00:33:30.709017	\N	t
513	d2444149-b80c-4f12-8e3e-7bb4a79d5d16	download_data	2025-12-02 00:33:31.234756	\N	t
514	bb6ccab2-3823-4db4-b969-3c1e8eccdd41	landing	2025-12-02 00:34:23.870314	\N	t
515	bb6ccab2-3823-4db4-b969-3c1e8eccdd41	view_kpis	2025-12-02 00:34:23.904304	\N	t
516	bb6ccab2-3823-4db4-b969-3c1e8eccdd41	analyze_charts	2025-12-02 00:34:23.980306	\N	t
517	bb6ccab2-3823-4db4-b969-3c1e8eccdd41	download_data	2025-12-02 00:34:24.46034	\N	t
518	8287ecdb-2108-4ef3-8ff4-9737f28dc0c4	landing	2025-12-02 00:35:02.728873	\N	t
519	8287ecdb-2108-4ef3-8ff4-9737f28dc0c4	view_kpis	2025-12-02 00:35:02.7549	\N	t
520	8287ecdb-2108-4ef3-8ff4-9737f28dc0c4	analyze_charts	2025-12-02 00:35:02.807188	\N	t
521	8287ecdb-2108-4ef3-8ff4-9737f28dc0c4	download_data	2025-12-02 00:35:03.363226	\N	t
522	dab9d67c-3142-4e82-972f-d0e7f9a8d9bc	landing	2025-12-02 00:39:42.903077	\N	t
523	dab9d67c-3142-4e82-972f-d0e7f9a8d9bc	view_kpis	2025-12-02 00:39:42.943966	\N	t
524	dab9d67c-3142-4e82-972f-d0e7f9a8d9bc	analyze_charts	2025-12-02 00:39:42.992968	\N	t
525	dab9d67c-3142-4e82-972f-d0e7f9a8d9bc	download_data	2025-12-02 00:39:43.725005	\N	t
526	dab9d67c-3142-4e82-972f-d0e7f9a8d9bc	apply_filters	2025-12-02 01:20:54.259439	\N	t
527	dab9d67c-3142-4e82-972f-d0e7f9a8d9bc	download_data	2025-12-02 01:20:54.817447	\N	t
528	dab9d67c-3142-4e82-972f-d0e7f9a8d9bc	apply_filters	2025-12-02 02:59:36.688014	\N	t
529	dab9d67c-3142-4e82-972f-d0e7f9a8d9bc	download_data	2025-12-02 02:59:37.667558	\N	t
530	dab9d67c-3142-4e82-972f-d0e7f9a8d9bc	apply_filters	2025-12-02 02:59:39.834364	\N	t
531	dab9d67c-3142-4e82-972f-d0e7f9a8d9bc	download_data	2025-12-02 02:59:40.482276	\N	t
532	dab9d67c-3142-4e82-972f-d0e7f9a8d9bc	apply_filters	2025-12-02 02:59:42.38728	\N	t
533	dab9d67c-3142-4e82-972f-d0e7f9a8d9bc	download_data	2025-12-02 02:59:43.096288	\N	t
534	b5f13916-5893-417b-82ec-2c8ee29fa795	landing	2025-12-02 05:46:44.106145	\N	t
535	b5f13916-5893-417b-82ec-2c8ee29fa795	view_kpis	2025-12-02 05:46:44.183775	\N	t
536	b5f13916-5893-417b-82ec-2c8ee29fa795	analyze_charts	2025-12-02 05:46:44.463949	\N	t
537	b5f13916-5893-417b-82ec-2c8ee29fa795	download_data	2025-12-02 05:46:46.357842	\N	t
\.


--
-- TOC entry 5164 (class 0 OID 0)
-- Dependencies: 220
-- Name: dashboard_performance_log_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dashboard_performance_log_log_id_seq', 317, true);


--
-- TOC entry 5165 (class 0 OID 0)
-- Dependencies: 222
-- Name: dim_objek_wisata_objek_wisata_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dim_objek_wisata_objek_wisata_id_seq', 29, true);


--
-- TOC entry 5166 (class 0 OID 0)
-- Dependencies: 224
-- Name: dim_price_price_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dim_price_price_id_seq', 28, true);


--
-- TOC entry 5167 (class 0 OID 0)
-- Dependencies: 226
-- Name: dim_time_time_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dim_time_time_id_seq', 64, true);


--
-- TOC entry 5168 (class 0 OID 0)
-- Dependencies: 228
-- Name: dim_wisatawan_wisatawan_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dim_wisatawan_wisatawan_id_seq', 2, true);


--
-- TOC entry 5169 (class 0 OID 0)
-- Dependencies: 230
-- Name: fact_kunjungan_kunjungan_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.fact_kunjungan_kunjungan_id_seq', 2800, true);


--
-- TOC entry 5170 (class 0 OID 0)
-- Dependencies: 232
-- Name: staging_harga_tiket_raw_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.staging_harga_tiket_raw_id_seq', 1, false);


--
-- TOC entry 5171 (class 0 OID 0)
-- Dependencies: 234
-- Name: staging_kunjungan_raw_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.staging_kunjungan_raw_id_seq', 3200, true);


--
-- TOC entry 5172 (class 0 OID 0)
-- Dependencies: 236
-- Name: user_journey_log_journey_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_journey_log_journey_id_seq', 537, true);


--
-- TOC entry 4938 (class 2606 OID 17370)
-- Name: dashboard_performance_log dashboard_performance_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard_performance_log
    ADD CONSTRAINT dashboard_performance_log_pkey PRIMARY KEY (log_id);


--
-- TOC entry 4943 (class 2606 OID 17372)
-- Name: dim_objek_wisata dim_objek_wisata_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dim_objek_wisata
    ADD CONSTRAINT dim_objek_wisata_pkey PRIMARY KEY (objek_wisata_id);


--
-- TOC entry 4946 (class 2606 OID 17374)
-- Name: dim_price dim_price_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dim_price
    ADD CONSTRAINT dim_price_pkey PRIMARY KEY (price_id);


--
-- TOC entry 4951 (class 2606 OID 17376)
-- Name: dim_time dim_time_periode_data_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dim_time
    ADD CONSTRAINT dim_time_periode_data_key UNIQUE (periode_data);


--
-- TOC entry 4953 (class 2606 OID 17378)
-- Name: dim_time dim_time_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dim_time
    ADD CONSTRAINT dim_time_pkey PRIMARY KEY (time_id);


--
-- TOC entry 4956 (class 2606 OID 17380)
-- Name: dim_wisatawan dim_wisatawan_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dim_wisatawan
    ADD CONSTRAINT dim_wisatawan_pkey PRIMARY KEY (wisatawan_id);


--
-- TOC entry 4958 (class 2606 OID 17382)
-- Name: fact_kunjungan fact_kunjungan_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fact_kunjungan
    ADD CONSTRAINT fact_kunjungan_pkey PRIMARY KEY (kunjungan_id);


--
-- TOC entry 4960 (class 2606 OID 17384)
-- Name: fact_kunjungan fact_kunjungan_time_id_objek_wisata_id_wisatawan_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fact_kunjungan
    ADD CONSTRAINT fact_kunjungan_time_id_objek_wisata_id_wisatawan_id_key UNIQUE (time_id, objek_wisata_id, wisatawan_id);


--
-- TOC entry 4966 (class 2606 OID 17386)
-- Name: staging_harga_tiket_raw staging_harga_tiket_raw_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staging_harga_tiket_raw
    ADD CONSTRAINT staging_harga_tiket_raw_pkey PRIMARY KEY (id);


--
-- TOC entry 4968 (class 2606 OID 17388)
-- Name: staging_kunjungan_raw staging_kunjungan_raw_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staging_kunjungan_raw
    ADD CONSTRAINT staging_kunjungan_raw_pkey PRIMARY KEY (id);


--
-- TOC entry 4949 (class 2606 OID 17390)
-- Name: dim_price unique_objek_price; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dim_price
    ADD CONSTRAINT unique_objek_price UNIQUE (objek_wisata_id);


--
-- TOC entry 4973 (class 2606 OID 17392)
-- Name: user_journey_log user_journey_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_journey_log
    ADD CONSTRAINT user_journey_log_pkey PRIMARY KEY (journey_id);


--
-- TOC entry 4944 (class 1259 OID 17393)
-- Name: idx_dim_objek_nama; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_dim_objek_nama ON public.dim_objek_wisata USING btree (nama_objek);


--
-- TOC entry 4954 (class 1259 OID 17394)
-- Name: idx_dim_time_periode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_dim_time_periode ON public.dim_time USING btree (periode_data);


--
-- TOC entry 4961 (class 1259 OID 17395)
-- Name: idx_fact_objek; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fact_objek ON public.fact_kunjungan USING btree (objek_wisata_id);


--
-- TOC entry 4962 (class 1259 OID 17396)
-- Name: idx_fact_price; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fact_price ON public.fact_kunjungan USING btree (price_id);


--
-- TOC entry 4963 (class 1259 OID 17397)
-- Name: idx_fact_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fact_time ON public.fact_kunjungan USING btree (time_id);


--
-- TOC entry 4964 (class 1259 OID 17398)
-- Name: idx_fact_wisatawan; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fact_wisatawan ON public.fact_kunjungan USING btree (wisatawan_id);


--
-- TOC entry 4969 (class 1259 OID 17399)
-- Name: idx_journey_session; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_journey_session ON public.user_journey_log USING btree (session_id);


--
-- TOC entry 4970 (class 1259 OID 17400)
-- Name: idx_journey_stage; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_journey_stage ON public.user_journey_log USING btree (stage);


--
-- TOC entry 4971 (class 1259 OID 17401)
-- Name: idx_journey_timestamp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_journey_timestamp ON public.user_journey_log USING btree ("timestamp");


--
-- TOC entry 4939 (class 1259 OID 17402)
-- Name: idx_perf_session; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_perf_session ON public.dashboard_performance_log USING btree (session_id);


--
-- TOC entry 4940 (class 1259 OID 17403)
-- Name: idx_perf_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_perf_status ON public.dashboard_performance_log USING btree (status);


--
-- TOC entry 4941 (class 1259 OID 17404)
-- Name: idx_perf_timestamp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_perf_timestamp ON public.dashboard_performance_log USING btree ("timestamp");


--
-- TOC entry 4947 (class 1259 OID 17405)
-- Name: idx_price_objek; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_price_objek ON public.dim_price USING btree (objek_wisata_id);


--
-- TOC entry 4975 (class 2606 OID 17406)
-- Name: fact_kunjungan fact_kunjungan_objek_wisata_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fact_kunjungan
    ADD CONSTRAINT fact_kunjungan_objek_wisata_id_fkey FOREIGN KEY (objek_wisata_id) REFERENCES public.dim_objek_wisata(objek_wisata_id);


--
-- TOC entry 4976 (class 2606 OID 17411)
-- Name: fact_kunjungan fact_kunjungan_time_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fact_kunjungan
    ADD CONSTRAINT fact_kunjungan_time_id_fkey FOREIGN KEY (time_id) REFERENCES public.dim_time(time_id);


--
-- TOC entry 4977 (class 2606 OID 17416)
-- Name: fact_kunjungan fact_kunjungan_wisatawan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fact_kunjungan
    ADD CONSTRAINT fact_kunjungan_wisatawan_id_fkey FOREIGN KEY (wisatawan_id) REFERENCES public.dim_wisatawan(wisatawan_id);


--
-- TOC entry 4974 (class 2606 OID 17421)
-- Name: dim_price fk_objek_wisata; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dim_price
    ADD CONSTRAINT fk_objek_wisata FOREIGN KEY (objek_wisata_id) REFERENCES public.dim_objek_wisata(objek_wisata_id) ON DELETE CASCADE;


-- Completed on 2025-12-02 10:54:59

--
-- PostgreSQL database dump complete
--

\unrestrict fKRdkBzwZeVziStD3cfIVdMUqzxBgkmIVI0Fqz1bVpApSzm26tHyr0tmozHpU50

