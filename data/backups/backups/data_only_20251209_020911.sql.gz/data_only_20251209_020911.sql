--
-- PostgreSQL database dump
--

\restrict iu63RspRcbdhwl4k9d0YIaeZlqlzZM9DORwqQUQd73F8hiT8jlaojjLHBhnWV2q

-- Dumped from database version 18.1
-- Dumped by pg_dump version 18.1 (Debian 18.1-1.pgdg13+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: dashboard_performance_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dashboard_performance_log (log_id, session_id, "timestamp", load_time_seconds, query_time_seconds, render_time_seconds, page_views, interactions_count, dwell_time_seconds, error_occurred, error_message, user_agent, screen_width, screen_height, filters_applied, status, created_at) FROM stdin;
\.


--
-- Data for Name: dim_objek_wisata; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dim_objek_wisata (objek_wisata_id, nama_objek, alamat, longitude, latitude, wilayah, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: dim_price; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dim_price (price_id, objek_wisata_id, harga_tiket_dewasa, harga_tiket_anak, mata_uang, sumber_platform, tanggal_update, created_at) FROM stdin;
\.


--
-- Data for Name: dim_time; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dim_time (time_id, periode, bulan, tahun, kuartal, created_at) FROM stdin;
\.


--
-- Data for Name: dim_wisatawan; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dim_wisatawan (wisatawan_id, jenis_wisatawan, kode_jenis, created_at) FROM stdin;
1	Wisatawan Nusantara	WNI	2025-12-09 02:08:54.233948
2	Wisatawan Mancanegara	WNA	2025-12-09 02:08:54.233948
\.


--
-- Data for Name: fact_kunjungan; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fact_kunjungan (fact_id, time_id, objek_wisata_id, wisatawan_id, jumlah_kunjungan, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_journey_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_journey_log (journey_id, session_id, stage, "timestamp", duration_seconds, completed) FROM stdin;
\.


--
-- Name: dashboard_performance_log_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dashboard_performance_log_log_id_seq', 1, false);


--
-- Name: dim_objek_wisata_objek_wisata_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dim_objek_wisata_objek_wisata_id_seq', 1, false);


--
-- Name: dim_price_price_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dim_price_price_id_seq', 1, false);


--
-- Name: dim_time_time_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dim_time_time_id_seq', 1, false);


--
-- Name: dim_wisatawan_wisatawan_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dim_wisatawan_wisatawan_id_seq', 2, true);


--
-- Name: fact_kunjungan_fact_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.fact_kunjungan_fact_id_seq', 1, false);


--
-- Name: user_journey_log_journey_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_journey_log_journey_id_seq', 1, false);


--
-- PostgreSQL database dump complete
--

\unrestrict iu63RspRcbdhwl4k9d0YIaeZlqlzZM9DORwqQUQd73F8hiT8jlaojjLHBhnWV2q

