--
-- PostgreSQL database dump
--

\restrict iutdEdDkws3IH1xkbWH4ykHqlaHiXGO03aRL7WP3K9sUvphaMwHeCGJFZo2vvb2

-- Dumped from database version 18.1
-- Dumped by pg_dump version 18.1 (Debian 18.1-1.pgdg13+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: dashboard_performance_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dashboard_performance_log (log_id, session_id, "timestamp", load_time_seconds, query_time_seconds, render_time_seconds, page_views, interactions_count, dwell_time_seconds, error_occurred, error_message, user_agent, screen_width, screen_height, filters_applied, status, created_at) FROM stdin;
1	67d0bbcb-e7d9-4eb9-a8c5-f0308e1c3f6d	2025-12-09 02:09:35.264998	0.05	0.04	0.32	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 02:09:35.264998
2	67d0bbcb-e7d9-4eb9-a8c5-f0308e1c3f6d	2025-12-09 02:10:22.799805	0.00	0.04	0.02	2	1	48	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 02:10:22.799805
3	67d0bbcb-e7d9-4eb9-a8c5-f0308e1c3f6d	2025-12-09 02:10:26.152926	0.00	0.04	0.02	3	2	51	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 02:10:26.152926
4	7769505b-794a-49f8-b6ac-1ae73fb2a680	2025-12-09 02:10:27.477416	0.00	0.04	0.02	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 02:10:27.477416
5	7769505b-794a-49f8-b6ac-1ae73fb2a680	2025-12-09 02:10:32.95877	0.01	0.04	0.03	2	1	5	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara"]}	success	2025-12-09 02:10:32.95877
6	7769505b-794a-49f8-b6ac-1ae73fb2a680	2025-12-09 02:10:34.826004	0.00	0.04	0.02	3	2	7	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 02:10:34.826004
7	7769505b-794a-49f8-b6ac-1ae73fb2a680	2025-12-09 02:10:38.182829	0.00	0.04	0.01	4	2	10	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 02:10:38.182829
8	994dae3e-b022-41dc-9a9e-18301fecf7c7	2025-12-09 02:10:43.138853	0.00	0.04	0.02	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 02:10:43.138853
9	994dae3e-b022-41dc-9a9e-18301fecf7c7	2025-12-09 02:10:50.398655	0.00	0.04	0.02	2	1	7	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 02:10:50.398655
10	994dae3e-b022-41dc-9a9e-18301fecf7c7	2025-12-09 02:10:52.315812	0.00	0.04	0.03	3	2	9	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 02:10:52.315812
11	1853eef8-f5dd-4503-837a-6677bcb21fa3	2025-12-09 02:10:54.536569	0.00	0.04	0.02	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 02:10:54.536569
12	b721753c-6d1c-4f60-a548-100855df32c9	2025-12-09 02:10:55.817806	0.00	0.04	0.02	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 02:10:55.817806
13	b721753c-6d1c-4f60-a548-100855df32c9	2025-12-09 02:11:44.938481	0.00	0.04	0.02	2	1	49	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 02:11:44.938481
14	b721753c-6d1c-4f60-a548-100855df32c9	2025-12-09 02:11:47.87802	0.00	0.04	0.02	3	2	52	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 02:11:47.87802
15	b721753c-6d1c-4f60-a548-100855df32c9	2025-12-09 02:11:57.212167	0.00	0.04	0.02	4	2	61	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 02:11:57.212167
16	c737ac54-60ef-43f9-a6a3-a31cdc3ec9a6	2025-12-09 02:11:58.617683	0.00	0.04	0.02	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 02:11:58.617683
17	3ead2969-b3c6-4e8d-82b1-e1a94e38adf9	2025-12-09 02:12:03.580904	0.00	0.04	0.02	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 02:12:03.580904
18	3ead2969-b3c6-4e8d-82b1-e1a94e38adf9	2025-12-09 02:12:09.591619	0.00	0.04	0.01	2	1	6	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 02:12:09.591619
19	3ead2969-b3c6-4e8d-82b1-e1a94e38adf9	2025-12-09 02:12:24.770177	0.00	0.04	0.02	3	1	21	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 02:12:24.770177
20	11442bc9-b334-46bc-9870-6c5cec0ffb93	2025-12-09 02:12:27.465544	0.00	0.04	0.02	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 02:12:27.465544
21	11442bc9-b334-46bc-9870-6c5cec0ffb93	2025-12-09 02:59:07.814029	0.03	0.02	0.05	2	1	2800	f	\N	\N	\N	\N	{"year": "2025", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 02:59:07.814029
22	4d33f9ef-0170-4279-992b-97c65a5fd6ff	2025-12-09 03:04:20.19407	0.00	0.02	0.02	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 03:04:20.19407
23	a1bf21b9-354e-409c-bab5-ee9c4e425ce1	2025-12-09 03:45:03.091082	0.02	0.01	0.04	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 03:45:03.091082
24	4d33f9ef-0170-4279-992b-97c65a5fd6ff	2025-12-09 03:45:53.171251	0.00	0.01	0.02	2	1	2493	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 03:45:53.171251
25	55e319fc-0f15-498d-a428-b25e05360c5e	2025-12-09 06:30:16.096736	0.16	0.13	0.29	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 06:30:16.096736
26	77979e84-4e02-48a1-8038-07fa9a9e29cf	2025-12-09 06:33:36.527292	0.01	0.13	0.04	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 06:33:36.527292
27	77979e84-4e02-48a1-8038-07fa9a9e29cf	2025-12-09 06:41:25.488674	0.01	0.13	0.04	2	0	469	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 06:41:25.488674
28	55e319fc-0f15-498d-a428-b25e05360c5e	2025-12-09 06:41:25.665564	0.02	0.13	0.10	2	0	670	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 06:41:25.665564
29	77979e84-4e02-48a1-8038-07fa9a9e29cf	2025-12-09 07:04:13.853286	0.02	0.01	0.03	3	0	1837	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 07:04:13.853286
30	77979e84-4e02-48a1-8038-07fa9a9e29cf	2025-12-09 07:12:33.360929	0.01	0.01	0.02	4	0	2336	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 07:12:33.360929
31	77979e84-4e02-48a1-8038-07fa9a9e29cf	2025-12-09 07:23:01.943331	0.03	0.02	0.06	5	1	2965	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 5, 6, 7], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 07:23:01.943331
32	77979e84-4e02-48a1-8038-07fa9a9e29cf	2025-12-09 07:23:04.937279	0.02	0.02	0.04	6	2	2968	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 5, 6, 7, 4], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 07:23:04.937279
33	77979e84-4e02-48a1-8038-07fa9a9e29cf	2025-12-09 07:23:06.226633	0.00	0.02	0.03	7	3	2969	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 5, 6, 7, 4, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 07:23:06.226633
34	77979e84-4e02-48a1-8038-07fa9a9e29cf	2025-12-09 07:49:47.465292	0.02	0.01	0.03	8	3	4570	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 5, 6, 7, 4, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 07:49:47.465292
35	77979e84-4e02-48a1-8038-07fa9a9e29cf	2025-12-09 13:53:59.405425	0.03	0.01	0.04	9	3	26422	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 5, 6, 7, 4, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 13:53:59.405425
36	77979e84-4e02-48a1-8038-07fa9a9e29cf	2025-12-09 14:29:41.837929	0.03	0.01	0.04	10	3	28565	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 5, 6, 7, 4, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 14:29:41.837929
37	38a90d35-b7c7-41d8-a14e-1fb7584d782b	2025-12-09 14:30:19.687787	0.01	0.01	0.05	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 14:30:19.687787
38	d172adb2-978b-43be-a8da-283c98a8608e	2025-12-09 14:32:55.632389	0.08	0.06	0.23	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 14:32:55.632389
39	cb2cb0c5-af14-4532-8e65-4609df6c99e9	2025-12-09 14:33:42.36706	0.05	0.04	0.32	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 14:33:42.36706
40	b6880fbc-f576-4e5b-998f-917c9658dfee	2025-12-09 14:33:42.367913	0.00	0.04	0.04	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 14:33:42.367913
41	841df00d-b17f-43de-8c8e-cd6d02f029bf	2025-12-09 14:34:42.417938	0.06	0.05	0.29	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 14:34:42.417938
42	2b484e2f-1f40-4354-92b9-fcfe5cf40ba6	2025-12-09 14:34:53.925356	0.00	0.05	0.03	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 14:34:53.925356
43	7d593bc5-9dbe-45f2-a444-a4b4028e4307	2025-12-09 14:35:16.440979	0.01	0.05	0.04	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 14:35:16.440979
44	7d593bc5-9dbe-45f2-a444-a4b4028e4307	2025-12-09 15:23:14.165954	0.03	0.02	0.05	2	0	2877	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 15:23:14.165954
45	0bf0cd12-e087-470d-8243-746e9d842b83	2025-12-09 15:23:38.650043	0.00	0.02	0.03	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 15:23:38.650043
46	0bf0cd12-e087-470d-8243-746e9d842b83	2025-12-09 18:33:45.126504	0.17	0.13	0.20	2	0	11406	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 18:33:45.126504
47	0bf0cd12-e087-470d-8243-746e9d842b83	2025-12-09 18:33:49.785729	0.00	0.13	0.02	3	1	11411	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 18:33:49.785729
48	0bf0cd12-e087-470d-8243-746e9d842b83	2025-12-09 18:33:52.276536	0.00	0.13	0.03	4	2	11413	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 18:33:52.276536
49	4a1f081d-1eef-4877-b7f2-dc9b2035f226	2025-12-09 18:42:13.110211	0.01	0.13	0.04	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 18:42:13.110211
50	e5f70ad8-5f45-4ec6-9474-70e7000d7a1e	2025-12-09 18:45:35.696076	0.02	0.01	0.05	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 18:45:35.696076
51	2d199208-5be1-4f95-b43a-791b71b9cc6e	2025-12-09 18:46:44.870164	0.01	0.01	0.08	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 18:46:44.870164
52	ba64c2f7-e108-49d8-a399-202491c780e9	2025-12-09 18:47:31.123207	0.00	0.01	0.04	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 18:47:31.123207
53	d9531051-5726-4aa3-9035-55bfb822d9de	2025-12-09 18:48:54.415864	0.01	0.01	0.04	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 18:48:54.415864
54	6e0ba51d-dcad-4b25-aaf1-9ebb048352c9	2025-12-09 18:49:43.203357	0.00	0.01	0.03	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 18:49:43.203357
55	d2bcff96-8345-4663-82d0-eeb8e0c3eeb0	2025-12-09 18:49:53.518007	0.00	0.01	0.03	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 18:49:53.518007
56	e95e65d5-b480-408c-aba9-2863d3a58a34	2025-12-09 18:50:41.98079	0.06	0.04	0.30	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 18:50:41.98079
57	848ed285-0955-4b1f-a397-ee9496d37935	2025-12-09 18:50:42.0033	0.05	0.04	0.10	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 18:50:42.0033
58	bab7f8e8-abd5-4e8e-8b52-7b00e34d83bd	2025-12-09 18:50:42.539561	0.00	0.04	0.04	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 18:50:42.539561
59	d3e04485-0f04-4715-b40d-b820dc3a49e8	2025-12-09 18:55:19.71914	0.01	0.04	0.04	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 18:55:19.71914
60	9c605443-4a75-4dce-91f7-ce5ea4538d9f	2025-12-09 18:55:43.354667	0.00	0.04	0.03	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 18:55:43.354667
61	dc11edd2-fb36-4370-91d4-f1b81c6ab49e	2025-12-09 18:55:43.363116	0.05	0.04	0.26	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 18:55:43.363116
62	361f700e-f14e-4d95-aef7-6d3a072e003a	2025-12-09 18:55:44.60203	0.00	0.04	0.05	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 18:55:44.60203
63	73950bb8-fad0-41f2-b680-bea7581253a5	2025-12-09 18:56:13.497543	0.01	0.04	0.03	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 18:56:13.497543
64	051aa330-923c-4d16-8fad-c18d768f57df	2025-12-09 18:56:29.414581	0.00	0.04	0.03	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 18:56:29.414581
65	ab4e95de-8974-4871-be97-5ba24c077033	2025-12-09 19:00:40.777364	0.06	0.05	0.27	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 19:00:40.777364
66	ab4e95de-8974-4871-be97-5ba24c077033	2025-12-09 19:01:05.3578	0.01	0.05	0.03	2	1	24	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 19:01:05.3578
67	ab4e95de-8974-4871-be97-5ba24c077033	2025-12-09 19:01:08.487425	0.00	0.05	0.03	3	2	28	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 19:01:08.487425
68	79a866d7-5b5b-4dac-b1b1-dbeaaf84429b	2025-12-09 19:01:13.70773	0.00	0.05	0.03	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 19:01:13.70773
69	ff34dbe4-c948-4233-83ec-23e2cf074804	2025-12-09 19:02:14.10882	0.01	0.05	0.04	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 19:02:14.10882
70	ff34dbe4-c948-4233-83ec-23e2cf074804	2025-12-09 19:06:14.551802	0.01	0.05	0.02	2	0	240	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-09 19:06:14.551802
71	0202aa3a-3fea-4b1e-bd83-f110dbd0803b	2025-12-09 19:11:44.22323	0.05	0.04	0.24	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-09 19:11:44.22323
72	aab0eb38-d69a-40d9-8208-ac938d3516c4	2025-12-09 19:12:06.70762	0.01	0.04	0.05	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-09 19:12:06.70762
73	cca5aed7-8341-4c6f-9278-2c706b55979f	2025-12-09 19:12:28.150809	0.00	0.04	0.03	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-09 19:12:28.150809
74	b31fc00a-f491-4df2-95a2-350596c576a0	2025-12-09 19:12:59.237328	0.00	0.04	0.05	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-09 19:12:59.237328
75	65198f5d-1d71-4fd3-b813-05cbb11f0418	2025-12-09 19:26:59.855359	0.05	0.03	0.10	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-09 19:26:59.855359
76	65198f5d-1d71-4fd3-b813-05cbb11f0418	2025-12-10 00:23:26.406538	0.00	0.03	0.01	2	0	17786	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Nusantara", "Wisatawan Mancanegara"]}	success	2025-12-10 00:23:26.406538
77	795df948-9898-42c6-8f0a-40bfedbf943f	2025-12-10 00:33:26.488198	0.03	0.02	0.05	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-10 00:33:26.488198
78	ac171518-6c60-4d51-8295-afeedf218d24	2025-12-10 01:36:12.732494	0.08	0.06	0.16	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-10 01:36:12.732494
79	f8641cf2-e820-4e43-8780-a24acc173a8e	2025-12-10 02:16:26.13132	0.16	0.13	0.27	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-10 02:16:26.13132
80	38307ec2-50a3-4783-aeda-7f5cf04f4254	2025-12-10 02:16:37.582912	0.01	0.13	0.05	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-10 02:16:37.582912
81	afbcf741-21d2-4d61-971a-8e0399ecf374	2025-12-10 02:20:45.092964	0.07	0.06	0.26	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-10 02:20:45.092964
82	f78977a6-a406-47d9-80ac-775328f4ca6e	2025-12-10 02:48:26.058632	0.10	0.08	0.42	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-10 02:48:26.058632
83	7f4d6280-9d94-4c2b-b398-2f4ccd2ac4ca	2025-12-10 02:58:36.463309	0.04	0.03	0.24	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-10 02:58:36.463309
84	82b88440-9f22-48de-ad01-734dc7449f34	2025-12-10 04:09:16.738418	0.09	0.06	0.15	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-10 04:09:16.738418
85	b182178f-35e6-4b55-899d-64d4e6636e45	2025-12-10 04:10:31.477371	0.01	0.06	0.03	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-10 04:10:31.477371
86	b182178f-35e6-4b55-899d-64d4e6636e45	2025-12-10 04:20:35.439903	0.03	0.02	0.05	2	1	604	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-10 04:20:35.439903
87	b182178f-35e6-4b55-899d-64d4e6636e45	2025-12-10 04:20:38.677033	0.00	0.02	0.03	3	2	607	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-10 04:20:38.677033
88	9702d079-888c-4971-a421-7393152f0f26	2025-12-10 04:21:06.650584	0.00	0.02	0.03	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-10 04:21:06.650584
89	ee7569b9-2ab3-4dd3-a999-b41dd01f2c14	2025-12-10 04:21:26.398086	0.01	0.02	0.04	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-10 04:21:26.398086
90	efbc4652-11b1-4f03-a498-de41c86c2d35	2025-12-10 05:34:06.631445	0.19	0.13	0.32	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-10 05:34:06.631445
91	efbc4652-11b1-4f03-a498-de41c86c2d35	2025-12-10 05:44:57.069797	0.03	0.02	0.05	2	1	650	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-10 05:44:57.069797
92	efbc4652-11b1-4f03-a498-de41c86c2d35	2025-12-10 05:45:00.114202	0.01	0.02	0.02	3	2	653	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-10 05:45:00.114202
93	8a095d53-5ff6-4ce1-b7ed-b7345419f702	2025-12-10 07:23:43.438636	0.23	0.18	0.39	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-10 07:23:43.438636
94	8a095d53-5ff6-4ce1-b7ed-b7345419f702	2025-12-10 07:36:23.700968	0.08	0.06	0.13	2	1	760	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-10 07:36:23.700968
95	4010089d-619a-4102-897c-cf5fbed4e1e6	2025-12-10 17:44:23.352959	0.07	0.05	0.13	1	0	0	f	\N	\N	\N	\N	{"year": "Semua", "months": [1, 2, 3, 4, 5, 6, 7, 8], "wilayah": ["Jakarta Barat", "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara", "Kepulauan Seribu"], "wisatawan": ["Wisatawan Mancanegara", "Wisatawan Nusantara"]}	success	2025-12-10 17:44:23.352959
\.


--
-- Data for Name: dim_objek_wisata; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dim_objek_wisata (objek_wisata_id, nama_objek, alamat, longitude, latitude, wilayah, created_at, updated_at) FROM stdin;
1	Kepulauan Seribu	Pulau Pramuka, Pulau Panggang, Kepulauan Seribu Utara, Kab. Administrasi Kepulauan Seribu, Daerah Khusus Ibukota Jakarta 14530	-5.7452702	106.6156112	Kepulauan Seribu	2025-12-09 02:09:15.462392	2025-12-09 02:09:15.462392
2	Taman Marga Satwa Ragunan	Jl. Harsono Rm Dalam No.1, Ragunan, Ps. Minggu, Kota Jakarta Selatan, Daerah Khusus Ibukota Jakarta 12550	-6.3045974	106.8210269	Jakarta Selatan	2025-12-09 02:09:15.462392	2025-12-09 02:09:15.462392
3	Museum Prasasti	Jl. Tanah Abang I No.1, RT.11/RW.8, Petojo Selatan, Kecamatan Gambir, Kota Jakarta Pusat, Daerah Khusus Ibukota Jakarta 10160	-6.1722280	106.8191788	Jakarta Pusat	2025-12-09 02:09:15.462392	2025-12-09 02:09:15.462392
4	Perkampungan Budaya Betawi Setu Babakan	Jl. Situ Babakan No.18 13, RT.13/RW.8, Srengseng Sawah, Kec. Jagakarsa, Kota Jakarta Selatan, Daerah Khusus Ibukota Jakarta 12630	-6.3392553	106.8250668	Jakarta Selatan	2025-12-09 02:09:15.462392	2025-12-09 02:09:15.462392
5	Pelabuhan Sunda Kelapa	Ancol, Kec. Pademangan, Jakarta Utara, Daerah Khusus Ibukota Jakarta	-6.1188442	106.8122886	Jakarta Utara	2025-12-09 02:09:15.462392	2025-12-09 02:09:15.462392
6	Museum Kebangkitan Nasional	Jl. Abdul Rachman Saleh No.26, Senen, Kec. Senen, Kota Jakarta Pusat, Daerah Khusus Ibukota Jakarta 10410	-6.1785723	106.8379842	Jakarta Pusat	2025-12-09 02:09:15.462392	2025-12-09 02:09:15.462392
7	Museum Joang '45	Jl. Menteng Raya No.31 1, RT.1/RW.10, Kebon Sirih, Kec. Menteng, Kota Jakarta Pusat, Daerah Khusus Ibukota Jakarta 10340	-6.1857868	106.8370903	Jakarta Pusat	2025-12-09 02:09:15.462392	2025-12-09 02:09:15.462392
8	Museum Nasional	Jl. Medan Merdeka Barat No.12, Gambir, Kecamatan Gambir, Kota Jakarta Pusat, Daerah Khusus Ibukota Jakarta 10110	-6.1761728	106.8215150	Jakarta Pusat	2025-12-09 02:09:15.462392	2025-12-09 02:09:15.462392
9	Museum Seni Rupa dan Keramik	Jl. Pos Kota No.2 9, RT.9/RW.7, Pinangsia, Kec. Taman Sari, Kota Jakarta Barat, Daerah Khusus Ibukota Jakarta 11110	-6.1342491	106.8149060	Jakarta Barat	2025-12-09 02:09:15.462392	2025-12-09 02:09:15.462392
10	Museum Basoeki Abdullah	Jl. Keuangan Raya No.19, Cilandak Barat, Kec. Cilandak, Kota Jakarta Selatan, Daerah Khusus Ibukota Jakarta 12430	-6.2897189	106.7936438	Jakarta Selatan	2025-12-09 02:09:15.462392	2025-12-09 02:09:15.462392
11	Kawasan Kota Tua	Kawasan Kota Tua, Taman Fatahillah No.1 7, RT.7/RW.7, Pinangsia, Kec. Taman Sari, Kota Jakarta Barat, Daerah Khusus Ibukota Jakarta 11110	-6.1349514	106.8146451	Jakarta Barat	2025-12-09 02:09:15.462392	2025-12-09 02:09:15.462392
12	Museum Perumusan Naskah Proklamasi	Jl. Imam Bonjol No.1, RT.9/RW.4, Menteng, Kec. Menteng, Kota Jakarta Pusat, Daerah Khusus Ibukota Jakarta 10310	-6.2002139	106.8310637	Jakarta Pusat	2025-12-09 02:09:15.462392	2025-12-09 02:09:15.462392
13	Taman Lapangan Banteng	RRJM+4W5, Pasar Baru, Kecamatan Sawah Besar, Kota Jakarta Pusat, Daerah Khusus Ibukota Jakarta 10710	-6.1703843	106.8354348	Jakarta Pusat	2025-12-09 02:09:15.462392	2025-12-09 02:09:15.462392
14	Taman Mini Indonesia Indah	Jl. Taman Mini Indonesia Indah, Ceger, Kec. Cipayung, Kota Jakarta Timur, Daerah Khusus Ibukota Jakarta 13820	-6.3019000	106.8904181	Jakarta Timur	2025-12-09 02:09:15.462392	2025-12-09 02:09:15.462392
15	Museum Arkeologi Onrust	Pulau Onrust, Kec. Kepulauan Seribu Selatan, Kab. Administrasi Kepulauan Seribu, Daerah Khusus Ibukota Jakarta 14510	-6.0341906	106.7355295	Kepulauan Seribu	2025-12-09 02:09:15.462392	2025-12-09 02:09:15.462392
16	Pos Bloc	RRJM+4W5, Pasar Baru, Kecamatan Sawah Besar, Kota Jakarta Pusat, Daerah Khusus Ibukota Jakarta 10710	-6.1661029	106.8361441	Jakarta Pusat	2025-12-09 02:09:15.462392	2025-12-09 02:09:15.462392
17	Museum Bahari	Jl. Pasar Ikan No.1, RT.11/RW.4, Penjaringan, Kec. Penjaringan, Jakarta Utara, Daerah Khusus Ibukota Jakarta 14440	-6.1264949	106.8082563	Jakarta Utara	2025-12-09 02:09:15.462392	2025-12-09 02:09:15.462392
18	Museum Satria Mandala	Jl. Gatot Subroto No.14, RT.6/RW.1, Kuningan Barat, Kec. Mampang Prapatan, Kota Jakarta Selatan, Daerah Khusus Ibukota Jakarta 12710	-6.2316899	106.8192872	Jakarta Selatan	2025-12-09 02:09:15.462392	2025-12-09 02:09:15.462392
19	Rumah Si Pitung (Situs Marunda)	Jl. Kampung Marunda Pulo, 2, RT.2/RW.7, Marunda, Kec. Cilincing, Jakarta Utara, Daerah Khusus Ibukota Jakarta 14150	-6.0968037	106.9588842	Jakarta Utara	2025-12-09 02:09:15.462392	2025-12-09 02:09:15.462392
20	Old Shanghai	Cakung Barat, Kec. Cakung, Kota Jakarta Timur, Daerah Khusus Ibukota Jakarta	-6.1645270	106.9245255	Jakarta Timur	2025-12-09 02:09:15.462392	2025-12-09 02:09:15.462392
21	Museum Sumpah Pemuda	Jl. Kramat Raya No.106, RT.2/RW.9, Kwitang, Kec. Senen, Kota Jakarta Pusat, Daerah Khusus Ibukota Jakarta 10420	-6.1836041	106.8430829	Jakarta Pusat	2025-12-09 02:09:15.462392	2025-12-09 02:09:15.462392
22	Planetarium	Jalan Cikini Raya No.73, RT.8/RW.2, Cikini, Kec. Menteng, Kota Jakarta Pusat, Daerah Khusus Ibukota Jakarta 10330	-6.1901946	106.8389179	Jakarta Pusat	2025-12-09 02:09:15.462392	2025-12-09 02:09:15.462392
23	Ruang Terbuka Hijau Tebet Eco Park	Jl. Tebet Barat Raya, RT.1/RW.10, Tebet Barat, Kec. Tebet, Kota Jakarta Selatan, Daerah Khusus Ibukota Jakarta 12820	-6.2372102	106.8534290	Jakarta Selatan	2025-12-09 02:09:15.462392	2025-12-09 02:09:15.462392
24	Museum Mohammad Hoesni Thamrin	Jl. Kenari 2 No.15, RW.4, Kenari, Kec. Senen, Kota Jakarta Pusat, Daerah Khusus Ibukota Jakarta 10430	-6.1937697	106.8456782	Jakarta Pusat	2025-12-09 02:09:15.462392	2025-12-09 02:09:15.462392
25	Museum Sejarah Jakarta	Taman Fatahillah No.1, Pinangsia, Kec. Taman Sari, Kota Jakarta Barat, Daerah Khusus Ibukota Jakarta 11110	-6.1349760	106.8142870	Jakarta Barat	2025-12-09 02:09:15.462392	2025-12-09 02:09:15.462392
26	Taman Impian Jaya Ancol	Jl. Lodan Timur No.7, RT.14/RW.10, Ancol, Kec. Pademangan, Jakarta Utara, Daerah Khusus Ibukota Jakarta 14430	-6.1226706	106.8331808	Jakarta Utara	2025-12-09 02:09:15.462392	2025-12-09 02:09:15.462392
27	Monumen Nasional	Merdeka Square, Jalan Lapangan Monas, Gambir, Kecamatan Gambir, Kota Jakarta Pusat, Daerah Khusus Ibukota Jakarta 10110	-6.1751897	106.8273888	Jakarta Pusat	2025-12-09 02:09:15.462392	2025-12-09 02:09:15.462392
28	Museum Tekstil	No 2-4, Jl. K.S. Tubun, Kota Bambu Selatan, Kec. Palmerah, Kota Jakarta Barat, Daerah Khusus Ibukota Jakarta 11420	-6.1880837	106.8107302	Jakarta Barat	2025-12-09 02:09:15.462392	2025-12-09 02:09:15.462392
29	Museum Wayang	Jalan Pintu Besar Utara No.27 Pinangsia, RT.3/RW.6, Kota Tua, Kec. Taman Sari, Kota Jakarta Barat, Daerah Khusus Ibukota Jakarta 11110	-6.1347258	106.8131962	Jakarta Barat	2025-12-09 02:09:15.462392	2025-12-09 02:09:15.462392
\.


--
-- Data for Name: dim_price; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dim_price (price_id, objek_wisata_id, harga_tiket_dewasa, harga_tiket_anak, mata_uang, sumber_platform, tanggal_update, created_at) FROM stdin;
1	11	0	0	IDR	Survey Manual	2025-12-09	2025-12-10 02:58:29.222428
2	1	0	0	IDR	Survey Manual	2025-12-09	2025-12-10 02:58:29.222428
3	27	20000	10000	IDR	Website Resmi	2025-12-09	2025-12-10 02:58:29.222428
4	15	0	0	IDR	Website Museum Jakarta	2025-12-09	2025-12-10 02:58:29.222428
5	17	5000	3000	IDR	Website Museum Jakarta	2025-12-09	2025-12-10 02:58:29.222428
6	10	10000	5000	IDR	Website Museum Jakarta	2025-12-09	2025-12-10 02:58:29.222428
7	7	2000	1000	IDR	Website Museum Jakarta	2025-12-09	2025-12-10 02:58:29.222428
8	6	5000	2000	IDR	Website Museum Jakarta	2025-12-09	2025-12-10 02:58:29.222428
9	24	0	0	IDR	Website Museum Jakarta	2025-12-09	2025-12-10 02:58:29.222428
10	8	10000	5000	IDR	Website Museum Jakarta	2025-12-09	2025-12-10 02:58:29.222428
11	12	0	0	IDR	Website Museum Jakarta	2025-12-09	2025-12-10 02:58:29.222428
12	3	5000	3000	IDR	Website Museum Jakarta	2025-12-09	2025-12-10 02:58:29.222428
13	18	5000	2000	IDR	Website Museum Jakarta	2025-12-09	2025-12-10 02:58:29.222428
14	25	5000	3000	IDR	Website Museum Jakarta	2025-12-09	2025-12-10 02:58:29.222428
15	9	5000	3000	IDR	Website Museum Jakarta	2025-12-09	2025-12-10 02:58:29.222428
16	21	5000	2000	IDR	Website Museum Jakarta	2025-12-09	2025-12-10 02:58:29.222428
17	28	5000	3000	IDR	Website Museum Jakarta	2025-12-09	2025-12-10 02:58:29.222428
18	29	5000	3000	IDR	Website Museum Jakarta	2025-12-09	2025-12-10 02:58:29.222428
19	20	0	0	IDR	Survey Manual	2025-12-09	2025-12-10 02:58:29.222428
20	5	5000	3000	IDR	Survey Manual	2025-12-09	2025-12-10 02:58:29.222428
21	4	0	0	IDR	Survey Manual	2025-12-09	2025-12-10 02:58:29.222428
22	22	12000	7000	IDR	Website Resmi	2025-12-09	2025-12-10 02:58:29.222428
23	16	0	0	IDR	Survey Manual	2025-12-09	2025-12-10 02:58:29.222428
24	23	0	0	IDR	Survey Manual	2025-12-09	2025-12-10 02:58:29.222428
25	19	0	0	IDR	Survey Manual	2025-12-09	2025-12-10 02:58:29.222428
26	26	25000	25000	IDR	Website Resmi Pengelola	2025-12-09	2025-12-10 02:58:29.222428
27	13	0	0	IDR	Website Resmi Pengelola	2025-12-09	2025-12-10 02:58:29.222428
28	2	4000	3000	IDR	Website Resmi Pengelola	2025-12-09	2025-12-10 02:58:29.222428
29	14	15000	10000	IDR	Website Resmi Pengelola	2025-12-09	2025-12-10 02:58:29.222428
\.


--
-- Data for Name: dim_time; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dim_time (time_id, periode, bulan, tahun, kuartal, created_at) FROM stdin;
1	202507	7	2025	3	2025-12-09 02:09:15.442241
2	202502	2	2025	1	2025-12-09 02:09:15.442241
3	202505	5	2025	2	2025-12-09 02:09:15.442241
4	202504	4	2025	2	2025-12-09 02:09:15.442241
5	202508	8	2025	3	2025-12-09 02:09:15.442241
6	202501	1	2025	1	2025-12-09 02:09:15.442241
7	202503	3	2025	1	2025-12-09 02:09:15.442241
8	202506	6	2025	2	2025-12-09 02:09:15.442241
\.


--
-- Data for Name: dim_wisatawan; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dim_wisatawan (wisatawan_id, jenis_wisatawan, kode_jenis, created_at) FROM stdin;
1	Wisatawan Nusantara	WNI	2025-12-09 02:08:54.233948
2	Wisatawan Mancanegara	WNA	2025-12-09 02:08:54.233948
\.


--
-- Data for Name: fact_kunjungan; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fact_kunjungan (fact_id, time_id, objek_wisata_id, wisatawan_id, jumlah_kunjungan, created_at, updated_at) FROM stdin;
358	1	24	1	65	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
309	1	24	2	3	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
104	1	25	1	37931	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
352	1	25	2	3304	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
300	1	26	1	793791	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
395	1	27	1	483014	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
367	1	27	2	5902	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
267	1	28	1	1645	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
121	1	28	2	300	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
195	1	29	1	32710	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
18	1	29	2	1368	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
136	2	1	1	16773	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
149	2	1	2	1031	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
185	2	2	1	237150	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
57	2	2	2	282	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
304	2	3	1	330	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
208	2	3	2	9	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
50	2	4	1	26088	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
338	2	4	2	21	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
3	2	5	1	0	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
227	2	5	2	0	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
332	2	6	1	5156	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
113	2	6	2	18	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
180	2	7	1	1032	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
152	2	7	2	5	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
305	2	8	1	59454	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
246	2	8	2	5674	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
382	2	9	1	12878	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
56	2	9	2	388	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
258	2	10	1	1006	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
202	2	10	2	6	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
175	2	11	1	186237	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
155	2	11	2	4086	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
144	2	12	1	1994	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
379	2	12	2	74	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
35	2	13	1	25457	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
206	2	14	1	291801	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
211	2	15	1	398	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
154	2	15	2	28	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
366	1	1	1	37744	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
48	1	1	2	1672	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
243	1	2	1	468655	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
384	1	2	2	87	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
14	1	3	1	317	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
349	1	3	2	26	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
272	1	4	1	22495	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
10	1	4	2	18	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
196	1	5	1	0	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
354	1	5	2	0	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
156	1	6	1	3421	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
330	1	6	2	0	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
400	1	7	1	321	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
181	1	7	2	19	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
4	1	8	1	67125	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
39	1	8	2	6722	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
58	1	9	1	13957	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
371	1	9	2	662	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
374	1	10	1	324	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
269	1	10	2	16	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
60	1	11	1	231247	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
148	1	11	2	6523	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
166	1	12	1	499	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
222	1	12	2	72	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
205	1	13	1	22439	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
350	1	14	1	260449	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
133	1	15	1	2013	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
225	1	15	2	0	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
21	1	16	1	71137	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
161	1	17	1	3099	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
9	1	17	2	402	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
347	1	18	1	2180	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
187	1	19	1	902	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
5	1	20	1	0	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
377	1	21	1	338	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
119	1	21	2	7	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
268	1	22	1	0	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
68	1	22	2	0	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
26	1	23	1	0	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
67	7	11	1	94469	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
344	7	11	2	4466	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
129	7	12	1	575	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
262	7	12	2	62	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
362	7	13	1	15393	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
174	7	14	1	114553	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
381	7	15	1	316	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
137	7	15	2	2	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
239	7	16	1	55088	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
11	7	17	1	861	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
308	7	17	2	221	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
250	7	18	1	1420	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
69	7	19	1	176	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
16	7	20	1	73223	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
124	7	21	1	327	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
20	7	21	2	1	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
217	7	22	1	0	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
357	7	22	2	0	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
42	7	23	1	28182	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
158	7	24	1	54	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
84	7	24	2	0	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
265	7	25	1	4515	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
163	7	25	2	912	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
83	7	26	1	568580	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
54	7	27	1	64083	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
388	7	27	2	2655	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
105	7	28	1	791	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
241	7	28	2	142	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
59	7	29	1	6236	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
283	7	29	2	1065	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
160	8	1	1	41191	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
223	8	1	2	1157	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
254	8	2	1	417950	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
1	8	2	2	97	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
19	8	3	1	378	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
169	8	3	2	6	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
270	8	4	1	26071	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
370	8	4	2	7	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
188	8	5	1	0	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
279	8	5	2	0	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
173	8	28	2	98	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
112	8	29	1	36867	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
387	8	29	2	1169	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
22	2	16	1	39051	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
183	2	17	1	3256	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
64	2	17	2	174	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
373	2	18	1	1950	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
189	2	19	1	673	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
293	2	20	1	58800	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
301	2	21	1	1096	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
213	2	21	2	2	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
231	2	22	1	0	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
383	2	22	2	0	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
13	2	23	1	0	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
128	2	24	1	269	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
363	2	24	2	3	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
12	2	25	1	28763	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
240	2	25	2	1260	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
165	2	26	1	934260	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
264	2	27	1	324043	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
364	2	27	2	4963	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
89	2	28	1	3442	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
287	2	28	2	135	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
170	2	29	1	35227	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
234	2	29	2	1290	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
82	3	1	1	51667	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
108	3	1	2	1431	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
368	3	2	1	463797	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
88	3	2	2	216	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
27	3	3	1	477	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
249	3	3	2	26	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
75	3	4	1	37363	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
125	3	4	2	16	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
216	3	5	1	1900	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
204	3	5	2	407	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
103	3	6	1	4404	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
6	3	6	2	28	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
317	3	7	1	1166	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
288	3	7	2	6	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
162	3	8	1	84273	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
45	3	8	2	1143	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
95	3	9	1	11424	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
212	3	9	2	464	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
141	3	10	1	668	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
197	3	10	2	3	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
153	3	11	1	177784	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
299	3	11	2	3360	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
97	3	12	1	1863	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
348	3	12	2	63	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
38	3	13	1	21727	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
266	3	14	1	258260	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
235	3	15	1	1308	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
253	3	15	2	0	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
321	3	16	1	45511	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
245	3	17	1	3537	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
375	3	17	2	354	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
291	3	18	1	2020	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
297	3	19	1	990	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
343	3	20	1	0	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
29	3	21	1	1090	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
307	3	21	2	1	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
65	3	22	1	0	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
46	3	22	2	0	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
319	3	23	1	125091	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
263	3	24	1	715	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
118	3	24	2	1	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
157	3	25	1	37267	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
256	3	25	2	2393	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
238	3	26	1	732626	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
192	3	27	1	351648	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
193	3	27	2	5313	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
194	3	28	1	2333	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
351	3	28	2	120	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
326	3	29	1	35328	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
107	3	29	2	769	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
339	4	1	1	63936	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
316	4	1	2	1217	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
86	4	2	1	806612	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
93	4	2	2	247	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
327	4	3	1	424	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
2	4	3	2	7	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
232	4	4	1	36170	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
24	4	4	2	18	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
280	4	5	1	0	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
333	4	5	2	0	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
71	4	6	1	3922	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
271	4	6	2	0	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
85	4	7	1	592	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
80	4	7	2	1	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
53	4	8	1	85000	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
77	4	8	2	4920	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
70	4	9	1	14191	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
122	4	9	2	400	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
7	4	10	1	287	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
30	4	10	2	4	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
87	4	11	1	741745	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
143	4	11	2	18604	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
106	4	12	1	1289	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
184	4	12	2	61	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
44	4	13	1	15360	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
260	4	14	1	353954	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
132	4	15	1	2007	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
353	4	15	2	1	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
199	4	16	1	34689	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
99	4	17	1	4048	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
140	4	17	2	320	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
111	4	18	1	1630	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
276	4	19	1	1940	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
329	4	20	1	97323	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
289	4	21	1	769	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
337	4	21	2	0	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
207	4	22	1	0	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
285	4	22	2	0	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
257	4	23	1	0	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
313	4	24	1	95	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
8	4	24	2	3	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
244	4	25	1	37584	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
109	4	25	2	1613	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
92	4	26	1	914254	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
248	4	27	1	760112	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
310	4	27	2	6753	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
96	4	28	1	2627	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
360	4	28	2	72	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
115	4	29	1	41637	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
296	4	29	2	1364	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
28	5	1	1	30953	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
365	5	1	2	1826	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
320	5	2	1	269418	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
286	5	2	2	264	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
323	5	3	1	233	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
228	5	3	2	21	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
33	5	4	1	27228	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
63	5	4	2	19	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
275	5	5	1	0	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
229	5	5	2	0	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
23	5	6	1	2788	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
372	5	6	2	0	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
224	5	7	1	760	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
277	5	7	2	16	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
274	5	8	1	35353	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
394	5	8	2	7098	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
230	5	9	1	7419	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
282	5	9	2	842	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
341	5	10	1	296	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
32	5	10	2	12	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
233	5	11	1	174862	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
61	5	11	2	6545	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
17	5	12	1	3771	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
284	5	12	2	40	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
55	5	13	1	0	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
190	5	14	1	182893	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
236	5	15	1	1908	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
79	5	15	2	17	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
359	5	16	1	39578	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
102	5	17	1	4720	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
34	5	17	2	548	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
172	5	18	1	2685	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
335	5	19	1	1310	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
150	5	20	1	50178	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
215	5	21	1	798	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
72	5	21	2	7	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
138	5	22	1	0	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
318	5	22	2	0	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
324	5	23	1	0	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
90	5	24	1	206	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
210	5	24	2	0	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
25	5	25	1	19175	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
101	5	25	2	2878	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
386	5	26	1	717446	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
325	5	27	1	579917	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
294	5	27	2	7849	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
295	5	28	1	2067	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
100	5	28	2	267	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
314	5	29	1	15216	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
393	5	29	2	1631	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
242	6	1	1	24712	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
331	6	1	2	1208	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
200	6	2	1	563393	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
214	6	2	2	277	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
120	6	3	1	400	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
201	6	3	2	17	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
311	6	4	1	31806	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
292	6	4	2	4	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
110	6	5	1	0	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
186	6	5	2	0	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
298	6	6	1	3012	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
178	6	6	2	26	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
168	6	7	1	738	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
47	6	7	2	5	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
66	6	8	1	83451	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
278	6	8	2	4170	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
167	6	9	1	15154	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
123	6	9	2	368	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
255	6	10	1	599	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
389	6	10	2	2	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
380	6	11	1	202461	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
127	6	11	2	4602	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
142	6	12	1	1720	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
315	6	12	2	70	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
134	6	13	1	0	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
378	6	14	1	351588	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
177	6	15	1	877	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
139	6	15	2	7	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
151	6	16	1	38007	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
41	6	17	1	2186	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
164	6	17	2	190	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
290	6	18	1	2059	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
336	6	19	1	1057	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
182	6	20	1	69748	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
176	6	21	1	1787	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
76	6	21	2	3	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
390	6	22	1	0	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
399	6	22	2	0	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
73	6	23	1	74824	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
218	6	24	1	106	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
81	6	24	2	3	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
43	6	25	1	36478	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
261	6	25	2	1371	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
237	6	26	1	760497	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
94	6	27	1	5372	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
131	6	27	2	360209	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
259	6	28	1	2152	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
78	6	28	2	78	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
220	6	29	1	23526	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
37	6	29	2	559	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
398	7	1	1	10719	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
52	7	1	2	1229	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
281	7	2	1	37287	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
74	7	2	2	118	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
322	7	3	1	183	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
145	7	3	2	12	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
31	7	4	1	8210	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
312	7	4	2	42	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
198	7	5	1	0	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
159	7	5	2	0	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
369	7	6	1	779	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
273	7	6	2	19	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
191	7	7	1	147	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
345	7	7	2	8	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
396	7	8	1	21990	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
219	7	8	2	3828	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
342	7	9	1	2073	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
40	7	9	2	216	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
306	7	10	1	129	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
171	7	10	2	2	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
252	8	6	1	2881	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
247	8	6	2	19	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
203	8	7	1	739	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
130	8	7	2	27	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
340	8	8	1	63798	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
114	8	8	2	4279	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
116	8	9	1	14871	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
126	8	9	2	489	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
146	8	10	1	442	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
62	8	10	2	3	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
147	8	11	1	211916	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
226	8	11	2	5705	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
51	8	12	1	759	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
15	8	12	2	43	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
179	8	13	1	45582	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
391	8	14	1	248533	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
135	8	15	1	1382	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
356	8	15	2	4	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
209	8	16	1	0	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
355	8	17	1	4447	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
385	8	17	2	240	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
98	8	18	1	2240	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
49	8	19	1	1105	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
251	8	20	1	49184	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
328	8	21	1	754	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
117	8	21	2	1	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
397	8	22	1	0	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
221	8	22	2	0	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
302	8	23	1	88770	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
36	8	24	1	290	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
303	8	24	2	0	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
91	8	25	1	18052	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
346	8	25	2	1204	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
376	8	26	1	776476	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
361	8	27	1	483014	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
334	8	27	2	5902	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
392	8	28	1	1816	2025-12-09 02:09:15.556353	2025-12-10 02:58:29.324881
\.


--
-- Data for Name: user_journey_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_journey_log (journey_id, session_id, stage, "timestamp", duration_seconds, completed) FROM stdin;
1	67d0bbcb-e7d9-4eb9-a8c5-f0308e1c3f6d	landing	2025-12-09 02:09:35.186521	\N	t
2	67d0bbcb-e7d9-4eb9-a8c5-f0308e1c3f6d	view_kpis	2025-12-09 02:09:35.255169	\N	t
3	67d0bbcb-e7d9-4eb9-a8c5-f0308e1c3f6d	analyze_charts	2025-12-09 02:09:35.358258	\N	t
4	67d0bbcb-e7d9-4eb9-a8c5-f0308e1c3f6d	apply_filters	2025-12-09 02:10:22.791513	\N	t
5	67d0bbcb-e7d9-4eb9-a8c5-f0308e1c3f6d	apply_filters	2025-12-09 02:10:26.142783	\N	t
6	7769505b-794a-49f8-b6ac-1ae73fb2a680	landing	2025-12-09 02:10:27.459532	\N	t
7	7769505b-794a-49f8-b6ac-1ae73fb2a680	view_kpis	2025-12-09 02:10:27.471434	\N	t
8	7769505b-794a-49f8-b6ac-1ae73fb2a680	analyze_charts	2025-12-09 02:10:27.493507	\N	t
9	7769505b-794a-49f8-b6ac-1ae73fb2a680	apply_filters	2025-12-09 02:10:32.936667	\N	t
10	7769505b-794a-49f8-b6ac-1ae73fb2a680	apply_filters	2025-12-09 02:10:34.816516	\N	t
11	7769505b-794a-49f8-b6ac-1ae73fb2a680	download_data	2025-12-09 02:10:38.489873	\N	t
12	994dae3e-b022-41dc-9a9e-18301fecf7c7	landing	2025-12-09 02:10:43.121965	\N	t
13	994dae3e-b022-41dc-9a9e-18301fecf7c7	view_kpis	2025-12-09 02:10:43.131188	\N	t
14	994dae3e-b022-41dc-9a9e-18301fecf7c7	analyze_charts	2025-12-09 02:10:43.151074	\N	t
15	994dae3e-b022-41dc-9a9e-18301fecf7c7	apply_filters	2025-12-09 02:10:50.385585	\N	t
16	994dae3e-b022-41dc-9a9e-18301fecf7c7	apply_filters	2025-12-09 02:10:52.289512	\N	t
17	1853eef8-f5dd-4503-837a-6677bcb21fa3	landing	2025-12-09 02:10:54.513268	\N	t
18	1853eef8-f5dd-4503-837a-6677bcb21fa3	view_kpis	2025-12-09 02:10:54.530467	\N	t
19	1853eef8-f5dd-4503-837a-6677bcb21fa3	analyze_charts	2025-12-09 02:10:54.554975	\N	t
20	b721753c-6d1c-4f60-a548-100855df32c9	landing	2025-12-09 02:10:55.798434	\N	t
21	b721753c-6d1c-4f60-a548-100855df32c9	view_kpis	2025-12-09 02:10:55.810718	\N	t
22	b721753c-6d1c-4f60-a548-100855df32c9	analyze_charts	2025-12-09 02:10:55.829304	\N	t
23	b721753c-6d1c-4f60-a548-100855df32c9	apply_filters	2025-12-09 02:11:44.923876	\N	t
24	b721753c-6d1c-4f60-a548-100855df32c9	apply_filters	2025-12-09 02:11:47.865426	\N	t
25	b721753c-6d1c-4f60-a548-100855df32c9	download_data	2025-12-09 02:11:57.509154	\N	t
26	c737ac54-60ef-43f9-a6a3-a31cdc3ec9a6	landing	2025-12-09 02:11:58.597619	\N	t
27	c737ac54-60ef-43f9-a6a3-a31cdc3ec9a6	view_kpis	2025-12-09 02:11:58.610861	\N	t
28	c737ac54-60ef-43f9-a6a3-a31cdc3ec9a6	analyze_charts	2025-12-09 02:11:58.629965	\N	t
29	3ead2969-b3c6-4e8d-82b1-e1a94e38adf9	landing	2025-12-09 02:12:03.559509	\N	t
30	3ead2969-b3c6-4e8d-82b1-e1a94e38adf9	view_kpis	2025-12-09 02:12:03.574536	\N	t
31	3ead2969-b3c6-4e8d-82b1-e1a94e38adf9	analyze_charts	2025-12-09 02:12:03.59257	\N	t
32	3ead2969-b3c6-4e8d-82b1-e1a94e38adf9	apply_filters	2025-12-09 02:12:09.582054	\N	t
33	3ead2969-b3c6-4e8d-82b1-e1a94e38adf9	download_data	2025-12-09 02:12:25.126534	\N	t
34	11442bc9-b334-46bc-9870-6c5cec0ffb93	landing	2025-12-09 02:12:27.445298	\N	t
35	11442bc9-b334-46bc-9870-6c5cec0ffb93	view_kpis	2025-12-09 02:12:27.456579	\N	t
36	11442bc9-b334-46bc-9870-6c5cec0ffb93	analyze_charts	2025-12-09 02:12:27.47678	\N	t
37	11442bc9-b334-46bc-9870-6c5cec0ffb93	apply_filters	2025-12-09 02:59:07.802315	\N	t
38	4d33f9ef-0170-4279-992b-97c65a5fd6ff	landing	2025-12-09 03:04:20.174534	\N	t
39	4d33f9ef-0170-4279-992b-97c65a5fd6ff	view_kpis	2025-12-09 03:04:20.187211	\N	t
40	4d33f9ef-0170-4279-992b-97c65a5fd6ff	analyze_charts	2025-12-09 03:04:20.208198	\N	t
41	a1bf21b9-354e-409c-bab5-ee9c4e425ce1	landing	2025-12-09 03:45:03.054855	\N	t
42	a1bf21b9-354e-409c-bab5-ee9c4e425ce1	view_kpis	2025-12-09 03:45:03.085286	\N	t
43	a1bf21b9-354e-409c-bab5-ee9c4e425ce1	analyze_charts	2025-12-09 03:45:03.108409	\N	t
44	4d33f9ef-0170-4279-992b-97c65a5fd6ff	apply_filters	2025-12-09 03:45:53.15922	\N	t
45	55e319fc-0f15-498d-a428-b25e05360c5e	landing	2025-12-09 06:30:15.835225	\N	t
46	55e319fc-0f15-498d-a428-b25e05360c5e	view_kpis	2025-12-09 06:30:16.078054	\N	t
47	55e319fc-0f15-498d-a428-b25e05360c5e	analyze_charts	2025-12-09 06:30:16.18194	\N	t
48	77979e84-4e02-48a1-8038-07fa9a9e29cf	landing	2025-12-09 06:33:36.490011	\N	t
49	77979e84-4e02-48a1-8038-07fa9a9e29cf	view_kpis	2025-12-09 06:33:36.515789	\N	t
50	77979e84-4e02-48a1-8038-07fa9a9e29cf	analyze_charts	2025-12-09 06:33:36.549329	\N	t
51	77979e84-4e02-48a1-8038-07fa9a9e29cf	apply_filters	2025-12-09 07:23:01.92631	\N	t
52	77979e84-4e02-48a1-8038-07fa9a9e29cf	apply_filters	2025-12-09 07:23:04.909962	\N	t
53	77979e84-4e02-48a1-8038-07fa9a9e29cf	apply_filters	2025-12-09 07:23:06.209023	\N	t
54	38a90d35-b7c7-41d8-a14e-1fb7584d782b	landing	2025-12-09 14:30:19.640483	\N	t
55	38a90d35-b7c7-41d8-a14e-1fb7584d782b	view_kpis	2025-12-09 14:30:19.673944	\N	t
56	38a90d35-b7c7-41d8-a14e-1fb7584d782b	analyze_charts	2025-12-09 14:30:19.722943	\N	t
57	d172adb2-978b-43be-a8da-283c98a8608e	landing	2025-12-09 14:32:55.52328	\N	t
58	d172adb2-978b-43be-a8da-283c98a8608e	view_kpis	2025-12-09 14:32:55.622741	\N	t
59	d172adb2-978b-43be-a8da-283c98a8608e	analyze_charts	2025-12-09 14:32:55.673913	\N	t
60	cb2cb0c5-af14-4532-8e65-4609df6c99e9	landing	2025-12-09 14:33:42.260492	\N	t
61	b6880fbc-f576-4e5b-998f-917c9658dfee	landing	2025-12-09 14:33:42.332093	\N	t
62	cb2cb0c5-af14-4532-8e65-4609df6c99e9	view_kpis	2025-12-09 14:33:42.347748	\N	t
63	b6880fbc-f576-4e5b-998f-917c9658dfee	view_kpis	2025-12-09 14:33:42.352514	\N	t
64	b6880fbc-f576-4e5b-998f-917c9658dfee	analyze_charts	2025-12-09 14:33:42.442531	\N	t
65	cb2cb0c5-af14-4532-8e65-4609df6c99e9	analyze_charts	2025-12-09 14:33:42.443209	\N	t
66	841df00d-b17f-43de-8c8e-cd6d02f029bf	landing	2025-12-09 14:34:42.325519	\N	t
67	841df00d-b17f-43de-8c8e-cd6d02f029bf	view_kpis	2025-12-09 14:34:42.408106	\N	t
68	841df00d-b17f-43de-8c8e-cd6d02f029bf	analyze_charts	2025-12-09 14:34:42.459332	\N	t
69	2b484e2f-1f40-4354-92b9-fcfe5cf40ba6	landing	2025-12-09 14:34:53.888518	\N	t
70	2b484e2f-1f40-4354-92b9-fcfe5cf40ba6	view_kpis	2025-12-09 14:34:53.906166	\N	t
71	2b484e2f-1f40-4354-92b9-fcfe5cf40ba6	analyze_charts	2025-12-09 14:34:53.947168	\N	t
72	7d593bc5-9dbe-45f2-a444-a4b4028e4307	landing	2025-12-09 14:35:16.399656	\N	t
73	7d593bc5-9dbe-45f2-a444-a4b4028e4307	view_kpis	2025-12-09 14:35:16.427779	\N	t
74	7d593bc5-9dbe-45f2-a444-a4b4028e4307	analyze_charts	2025-12-09 14:35:16.464624	\N	t
75	0bf0cd12-e087-470d-8243-746e9d842b83	landing	2025-12-09 15:23:38.619662	\N	t
76	0bf0cd12-e087-470d-8243-746e9d842b83	view_kpis	2025-12-09 15:23:38.639969	\N	t
77	0bf0cd12-e087-470d-8243-746e9d842b83	analyze_charts	2025-12-09 15:23:38.669378	\N	t
78	0bf0cd12-e087-470d-8243-746e9d842b83	apply_filters	2025-12-09 18:33:49.770883	\N	t
79	0bf0cd12-e087-470d-8243-746e9d842b83	apply_filters	2025-12-09 18:33:52.262391	\N	t
80	4a1f081d-1eef-4877-b7f2-dc9b2035f226	landing	2025-12-09 18:42:13.075234	\N	t
81	4a1f081d-1eef-4877-b7f2-dc9b2035f226	view_kpis	2025-12-09 18:42:13.097524	\N	t
82	4a1f081d-1eef-4877-b7f2-dc9b2035f226	analyze_charts	2025-12-09 18:42:13.13974	\N	t
83	e5f70ad8-5f45-4ec6-9474-70e7000d7a1e	landing	2025-12-09 18:45:35.642645	\N	t
84	e5f70ad8-5f45-4ec6-9474-70e7000d7a1e	view_kpis	2025-12-09 18:45:35.684159	\N	t
85	e5f70ad8-5f45-4ec6-9474-70e7000d7a1e	analyze_charts	2025-12-09 18:45:35.715598	\N	t
86	2d199208-5be1-4f95-b43a-791b71b9cc6e	landing	2025-12-09 18:46:44.788921	\N	t
87	2d199208-5be1-4f95-b43a-791b71b9cc6e	view_kpis	2025-12-09 18:46:44.823117	\N	t
88	2d199208-5be1-4f95-b43a-791b71b9cc6e	analyze_charts	2025-12-09 18:46:44.902902	\N	t
89	ba64c2f7-e108-49d8-a399-202491c780e9	landing	2025-12-09 18:47:31.08237	\N	t
90	ba64c2f7-e108-49d8-a399-202491c780e9	view_kpis	2025-12-09 18:47:31.106041	\N	t
91	ba64c2f7-e108-49d8-a399-202491c780e9	analyze_charts	2025-12-09 18:47:31.172486	\N	t
92	d9531051-5726-4aa3-9035-55bfb822d9de	landing	2025-12-09 18:48:54.376793	\N	t
93	d9531051-5726-4aa3-9035-55bfb822d9de	view_kpis	2025-12-09 18:48:54.400842	\N	t
94	d9531051-5726-4aa3-9035-55bfb822d9de	analyze_charts	2025-12-09 18:48:54.445942	\N	t
95	6e0ba51d-dcad-4b25-aaf1-9ebb048352c9	landing	2025-12-09 18:49:43.172177	\N	t
96	6e0ba51d-dcad-4b25-aaf1-9ebb048352c9	view_kpis	2025-12-09 18:49:43.19308	\N	t
97	6e0ba51d-dcad-4b25-aaf1-9ebb048352c9	analyze_charts	2025-12-09 18:49:43.228416	\N	t
98	d2bcff96-8345-4663-82d0-eeb8e0c3eeb0	landing	2025-12-09 18:49:53.486858	\N	t
99	d2bcff96-8345-4663-82d0-eeb8e0c3eeb0	view_kpis	2025-12-09 18:49:53.507512	\N	t
100	d2bcff96-8345-4663-82d0-eeb8e0c3eeb0	analyze_charts	2025-12-09 18:49:53.540643	\N	t
101	e95e65d5-b480-408c-aba9-2863d3a58a34	landing	2025-12-09 18:50:41.887399	\N	t
102	848ed285-0955-4b1f-a397-ee9496d37935	landing	2025-12-09 18:50:41.898205	\N	t
103	e95e65d5-b480-408c-aba9-2863d3a58a34	view_kpis	2025-12-09 18:50:41.967462	\N	t
104	848ed285-0955-4b1f-a397-ee9496d37935	view_kpis	2025-12-09 18:50:41.98275	\N	t
105	e95e65d5-b480-408c-aba9-2863d3a58a34	analyze_charts	2025-12-09 18:50:42.061518	\N	t
106	848ed285-0955-4b1f-a397-ee9496d37935	analyze_charts	2025-12-09 18:50:42.064188	\N	t
107	bab7f8e8-abd5-4e8e-8b52-7b00e34d83bd	landing	2025-12-09 18:50:42.503632	\N	t
108	bab7f8e8-abd5-4e8e-8b52-7b00e34d83bd	view_kpis	2025-12-09 18:50:42.523867	\N	t
109	bab7f8e8-abd5-4e8e-8b52-7b00e34d83bd	analyze_charts	2025-12-09 18:50:42.558337	\N	t
110	d3e04485-0f04-4715-b40d-b820dc3a49e8	landing	2025-12-09 18:55:19.679506	\N	t
111	d3e04485-0f04-4715-b40d-b820dc3a49e8	view_kpis	2025-12-09 18:55:19.70392	\N	t
112	d3e04485-0f04-4715-b40d-b820dc3a49e8	analyze_charts	2025-12-09 18:55:19.74989	\N	t
113	dc11edd2-fb36-4370-91d4-f1b81c6ab49e	landing	2025-12-09 18:55:43.263754	\N	t
114	9c605443-4a75-4dce-91f7-ce5ea4538d9f	landing	2025-12-09 18:55:43.327628	\N	t
115	9c605443-4a75-4dce-91f7-ce5ea4538d9f	view_kpis	2025-12-09 18:55:43.344597	\N	t
116	dc11edd2-fb36-4370-91d4-f1b81c6ab49e	view_kpis	2025-12-09 18:55:43.343636	\N	t
117	9c605443-4a75-4dce-91f7-ce5ea4538d9f	analyze_charts	2025-12-09 18:55:43.424517	\N	t
118	dc11edd2-fb36-4370-91d4-f1b81c6ab49e	analyze_charts	2025-12-09 18:55:43.425128	\N	t
119	361f700e-f14e-4d95-aef7-6d3a072e003a	landing	2025-12-09 18:55:44.552744	\N	t
120	361f700e-f14e-4d95-aef7-6d3a072e003a	view_kpis	2025-12-09 18:55:44.579792	\N	t
121	361f700e-f14e-4d95-aef7-6d3a072e003a	analyze_charts	2025-12-09 18:55:44.630509	\N	t
122	73950bb8-fad0-41f2-b680-bea7581253a5	landing	2025-12-09 18:56:13.465794	\N	t
123	73950bb8-fad0-41f2-b680-bea7581253a5	view_kpis	2025-12-09 18:56:13.486941	\N	t
124	73950bb8-fad0-41f2-b680-bea7581253a5	analyze_charts	2025-12-09 18:56:13.516978	\N	t
125	051aa330-923c-4d16-8fad-c18d768f57df	landing	2025-12-09 18:56:29.386027	\N	t
126	051aa330-923c-4d16-8fad-c18d768f57df	view_kpis	2025-12-09 18:56:29.403572	\N	t
127	051aa330-923c-4d16-8fad-c18d768f57df	analyze_charts	2025-12-09 18:56:29.434147	\N	t
128	ab4e95de-8974-4871-be97-5ba24c077033	landing	2025-12-09 19:00:40.688299	\N	t
129	ab4e95de-8974-4871-be97-5ba24c077033	view_kpis	2025-12-09 19:00:40.766687	\N	t
130	ab4e95de-8974-4871-be97-5ba24c077033	analyze_charts	2025-12-09 19:00:40.830207	\N	t
131	ab4e95de-8974-4871-be97-5ba24c077033	apply_filters	2025-12-09 19:01:05.334958	\N	t
132	ab4e95de-8974-4871-be97-5ba24c077033	apply_filters	2025-12-09 19:01:08.461633	\N	t
133	79a866d7-5b5b-4dac-b1b1-dbeaaf84429b	landing	2025-12-09 19:01:13.676308	\N	t
134	79a866d7-5b5b-4dac-b1b1-dbeaaf84429b	view_kpis	2025-12-09 19:01:13.695939	\N	t
135	79a866d7-5b5b-4dac-b1b1-dbeaaf84429b	analyze_charts	2025-12-09 19:01:13.733595	\N	t
136	ff34dbe4-c948-4233-83ec-23e2cf074804	landing	2025-12-09 19:02:14.070733	\N	t
137	ff34dbe4-c948-4233-83ec-23e2cf074804	view_kpis	2025-12-09 19:02:14.096266	\N	t
138	ff34dbe4-c948-4233-83ec-23e2cf074804	analyze_charts	2025-12-09 19:02:14.1533	\N	t
139	0202aa3a-3fea-4b1e-bd83-f110dbd0803b	landing	2025-12-10 03:11:44.142948	\N	t
140	0202aa3a-3fea-4b1e-bd83-f110dbd0803b	view_kpis	2025-12-10 03:11:44.208379	\N	t
141	0202aa3a-3fea-4b1e-bd83-f110dbd0803b	analyze_charts	2025-12-10 03:11:44.265166	\N	t
142	aab0eb38-d69a-40d9-8208-ac938d3516c4	landing	2025-12-10 03:12:06.656087	\N	t
143	aab0eb38-d69a-40d9-8208-ac938d3516c4	view_kpis	2025-12-10 03:12:06.687771	\N	t
144	aab0eb38-d69a-40d9-8208-ac938d3516c4	analyze_charts	2025-12-10 03:12:06.733065	\N	t
145	cca5aed7-8341-4c6f-9278-2c706b55979f	landing	2025-12-10 03:12:28.123001	\N	t
146	cca5aed7-8341-4c6f-9278-2c706b55979f	view_kpis	2025-12-10 03:12:28.142946	\N	t
147	cca5aed7-8341-4c6f-9278-2c706b55979f	analyze_charts	2025-12-10 03:12:28.16941	\N	t
148	b31fc00a-f491-4df2-95a2-350596c576a0	landing	2025-12-10 03:12:59.18981	\N	t
149	b31fc00a-f491-4df2-95a2-350596c576a0	view_kpis	2025-12-10 03:12:59.226448	\N	t
150	b31fc00a-f491-4df2-95a2-350596c576a0	analyze_charts	2025-12-10 03:12:59.258824	\N	t
151	65198f5d-1d71-4fd3-b813-05cbb11f0418	landing	2025-12-10 03:26:59.781281	\N	t
152	65198f5d-1d71-4fd3-b813-05cbb11f0418	view_kpis	2025-12-10 03:26:59.842921	\N	t
153	65198f5d-1d71-4fd3-b813-05cbb11f0418	analyze_charts	2025-12-10 03:26:59.884177	\N	t
154	795df948-9898-42c6-8f0a-40bfedbf943f	landing	2025-12-10 08:33:26.441175	\N	t
155	795df948-9898-42c6-8f0a-40bfedbf943f	view_kpis	2025-12-10 08:33:26.478615	\N	t
156	795df948-9898-42c6-8f0a-40bfedbf943f	analyze_charts	2025-12-10 08:33:26.506432	\N	t
157	ac171518-6c60-4d51-8295-afeedf218d24	landing	2025-12-10 09:36:12.588308	\N	t
158	ac171518-6c60-4d51-8295-afeedf218d24	view_kpis	2025-12-10 09:36:12.711658	\N	t
159	ac171518-6c60-4d51-8295-afeedf218d24	analyze_charts	2025-12-10 09:36:12.768198	\N	t
160	f8641cf2-e820-4e43-8780-a24acc173a8e	landing	2025-12-10 10:16:25.872569	\N	t
161	f8641cf2-e820-4e43-8780-a24acc173a8e	view_kpis	2025-12-10 10:16:26.105734	\N	t
162	f8641cf2-e820-4e43-8780-a24acc173a8e	analyze_charts	2025-12-10 10:16:26.247259	\N	t
163	38307ec2-50a3-4783-aeda-7f5cf04f4254	landing	2025-12-10 10:16:37.530323	\N	t
164	38307ec2-50a3-4783-aeda-7f5cf04f4254	view_kpis	2025-12-10 10:16:37.572644	\N	t
165	38307ec2-50a3-4783-aeda-7f5cf04f4254	analyze_charts	2025-12-10 10:16:37.603765	\N	t
166	e40362d2-9394-4d10-bee3-6ae1d3d3c922	landing	2025-12-10 10:17:33.292387	\N	t
167	1318253d-e2ad-4e00-98ca-66e05222b779	landing	2025-12-10 10:19:00.692247	\N	t
168	b117cb8a-4d27-4f42-9d39-d7d42f2aab18	landing	2025-12-10 10:20:13.233252	\N	t
169	afbcf741-21d2-4d61-971a-8e0399ecf374	landing	2025-12-10 10:20:44.990574	\N	t
170	afbcf741-21d2-4d61-971a-8e0399ecf374	view_kpis	2025-12-10 10:20:45.078994	\N	t
171	afbcf741-21d2-4d61-971a-8e0399ecf374	analyze_charts	2025-12-10 10:20:45.16939	\N	t
172	f78977a6-a406-47d9-80ac-775328f4ca6e	landing	2025-12-10 10:48:25.912246	\N	t
173	f78977a6-a406-47d9-80ac-775328f4ca6e	view_kpis	2025-12-10 10:48:26.043973	\N	t
174	f78977a6-a406-47d9-80ac-775328f4ca6e	analyze_charts	2025-12-10 10:48:26.119593	\N	t
175	7f4d6280-9d94-4c2b-b398-2f4ccd2ac4ca	landing	2025-12-10 10:58:36.399055	\N	t
176	7f4d6280-9d94-4c2b-b398-2f4ccd2ac4ca	view_kpis	2025-12-10 10:58:36.454981	\N	t
177	7f4d6280-9d94-4c2b-b398-2f4ccd2ac4ca	analyze_charts	2025-12-10 10:58:36.507828	\N	t
178	82b88440-9f22-48de-ad01-734dc7449f34	landing	2025-12-10 12:09:16.5904	\N	t
179	82b88440-9f22-48de-ad01-734dc7449f34	view_kpis	2025-12-10 12:09:16.719463	\N	t
180	82b88440-9f22-48de-ad01-734dc7449f34	analyze_charts	2025-12-10 12:09:16.800146	\N	t
181	b182178f-35e6-4b55-899d-64d4e6636e45	landing	2025-12-10 12:10:31.445221	\N	t
182	b182178f-35e6-4b55-899d-64d4e6636e45	view_kpis	2025-12-10 12:10:31.467876	\N	t
183	b182178f-35e6-4b55-899d-64d4e6636e45	analyze_charts	2025-12-10 12:10:31.499862	\N	t
184	b182178f-35e6-4b55-899d-64d4e6636e45	apply_filters	2025-12-10 12:20:35.418547	\N	t
185	b182178f-35e6-4b55-899d-64d4e6636e45	apply_filters	2025-12-10 12:20:38.658217	\N	t
186	9702d079-888c-4971-a421-7393152f0f26	landing	2025-12-10 12:21:06.619855	\N	t
187	9702d079-888c-4971-a421-7393152f0f26	view_kpis	2025-12-10 12:21:06.638676	\N	t
188	9702d079-888c-4971-a421-7393152f0f26	analyze_charts	2025-12-10 12:21:06.705921	\N	t
189	ee7569b9-2ab3-4dd3-a999-b41dd01f2c14	landing	2025-12-10 12:21:26.361268	\N	t
190	ee7569b9-2ab3-4dd3-a999-b41dd01f2c14	view_kpis	2025-12-10 12:21:26.386532	\N	t
191	ee7569b9-2ab3-4dd3-a999-b41dd01f2c14	analyze_charts	2025-12-10 12:21:26.429637	\N	t
192	efbc4652-11b1-4f03-a498-de41c86c2d35	landing	2025-12-10 13:34:06.32636	\N	t
193	efbc4652-11b1-4f03-a498-de41c86c2d35	view_kpis	2025-12-10 13:34:06.604235	\N	t
194	efbc4652-11b1-4f03-a498-de41c86c2d35	analyze_charts	2025-12-10 13:34:06.715342	\N	t
195	efbc4652-11b1-4f03-a498-de41c86c2d35	apply_filters	2025-12-10 13:44:57.052481	\N	t
196	efbc4652-11b1-4f03-a498-de41c86c2d35	apply_filters	2025-12-10 13:45:00.100681	\N	t
197	8a095d53-5ff6-4ce1-b7ed-b7345419f702	landing	2025-12-10 15:23:43.0668	\N	t
198	8a095d53-5ff6-4ce1-b7ed-b7345419f702	view_kpis	2025-12-10 15:23:43.415921	\N	t
199	8a095d53-5ff6-4ce1-b7ed-b7345419f702	analyze_charts	2025-12-10 15:23:43.593698	\N	t
200	8a095d53-5ff6-4ce1-b7ed-b7345419f702	apply_filters	2025-12-10 15:36:23.664831	\N	t
201	4010089d-619a-4102-897c-cf5fbed4e1e6	landing	2025-12-11 01:44:23.222743	\N	t
202	4010089d-619a-4102-897c-cf5fbed4e1e6	view_kpis	2025-12-11 01:44:23.34028	\N	t
203	4010089d-619a-4102-897c-cf5fbed4e1e6	analyze_charts	2025-12-11 01:44:23.387955	\N	t
\.


--
-- Name: dashboard_performance_log_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dashboard_performance_log_log_id_seq', 95, true);


--
-- Name: dim_objek_wisata_objek_wisata_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dim_objek_wisata_objek_wisata_id_seq', 29, true);


--
-- Name: dim_price_price_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dim_price_price_id_seq', 29, true);


--
-- Name: dim_time_time_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dim_time_time_id_seq', 56, true);


--
-- Name: dim_wisatawan_wisatawan_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dim_wisatawan_wisatawan_id_seq', 2, true);


--
-- Name: fact_kunjungan_fact_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.fact_kunjungan_fact_id_seq', 2800, true);


--
-- Name: user_journey_log_journey_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_journey_log_journey_id_seq', 203, true);


--
-- PostgreSQL database dump complete
--

\unrestrict iutdEdDkws3IH1xkbWH4ykHqlaHiXGO03aRL7WP3K9sUvphaMwHeCGJFZo2vvb2

